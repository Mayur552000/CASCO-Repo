@echo off
cd /d "%~dp0"
if not exist .venv (
  echo Creating virtual environment...
  python -m venv .venv || goto :err
)
call .venv\Scripts\activate.bat
rem Install packages on first run and whenever requirements.txt changes
fc /b requirements.txt .venv\installed-requirements.txt >nul 2>&1
if errorlevel 1 (
  echo Installing required packages...
  python -m pip install --upgrade pip >nul
  pip install -r requirements.txt || goto :err
  copy /y requirements.txt .venv\installed-requirements.txt >nul
)
if not exist .env copy .env.example .env >nul
echo Starting Team Activity Tracker on http://localhost:8000
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
goto :eof
:err
echo Setup failed. Check that Python 3.10+ is installed and on PATH, and that this PC can reach pypi.org.
pause
