# Team Activity Tracker

Tracks ticket and non-ticket work for the team: who is assigned what, estimated
versus actual hours, workload, SLA performance, root causes, and management reports.
Tickets come from Freshdesk; everything is cached locally so the UI is fast and
Freshdesk rate limits are never hit by browsing.

## Run it

1. Install Python 3.10 or newer.
2. Double-click `run.bat` (first run creates `.venv` and installs packages).
3. Open http://localhost:8000 — colleagues on the network use `http://<your-pc-name>:8000`.

Manual start: `pip install -r requirements.txt` then
`python -m uvicorn app.main:app --host 0.0.0.0 --port 8000`.

### First sign-in

Administrator: `admin@casco.local` / `ChangeMe!123` (change it under Settings).

## Load your real Freshdesk data

1. Sign in as the administrator and open **Settings**.
2. Under **Freshdesk connection** enter the address and an API key, then **Connect and sync**.
   The app checks the key, removes any sample data, and starts the first sync.
   Use an administrator's API key: only those can list agents with their emails. With a
   normal agent key the app still imports agent names from the ticket form, with placeholder emails.
3. After the first sync, pick the ticket field that holds the plant/location in the same form.

Every sync (every `SYNC_INTERVAL_MINUTES`, or **Sync now**):

- adds each Freshdesk agent as a team member. They sign in with their Freshdesk email and the
  starting password `NEW_MEMBER_PASSWORD` (default `Welcome!123`) and must choose their own
  password at first sign-in;
- pulls unresolved tickets, the 500 most recently updated tickets with SLA stats, and conversations;
- creates a tracker task for each unresolved ticket owned by a team member (turn off with
  `AUTO_CREATE_TICKET_TASKS=false`) and closes it when the ticket is resolved.

Removing a team member (Settings, administrators only) blocks their sign-in and hides them
from team lists, and the sync does not add them back. Their logged hours stay in the reports.
You are asked what to do with their open work:

- **Hand it to someone** — every open task moves to the person you pick.
- **Leave it without an owner** — tasks that only mirror a Freshdesk ticket and hold no hours
  are removed, so they do not sit in the unassigned list; anything else waits in the
  "Unassigned" card on Tasks, where "Hand these over…" moves the lot to one person in one go.

In Freshdesk the tickets still belong to that agent until someone reassigns them there. Those
tickets are marked "not in the team" on the dashboard, and the Tickets tab can filter on
**Owner not in the team** so none of them is lost. If a ticket is reassigned in Freshdesk, its
task follows the new owner at the next sync.

The connection can also be set in `.env` (`FRESHDESK_BASE_URL`, `FRESHDESK_API_KEY`); values
saved in Settings take precedence and are stored in the app's database.

To try the app with sample data instead, set `SEED_DEMO_DATA=true` before the first start.

## Estimates

Only administrators and team leads can set or change a task's estimate. Team members see
it read-only. Leads can type estimates straight into the Tasks list (filter on
"No estimate" to find the gaps). Every change is recorded in the task's history.

## Completed tasks

"Done" moves a task to the Completed tab on My work, coloured green, with how it finished
against its estimate. Undo is offered for a few seconds, and any completed task can be
reopened. Reports shows tasks completed per week.

## Inside a task

Open a row on the Tasks tab (the arrow next to the task number) to see, without leaving the list:

- **Steps** — break the task into pieces and tick them off. The row then shows "2/5".
- **Hours logged** — every entry, who logged it, when, and the note, with the total against
  the estimate.

The task's owner and team leads can change the steps; anyone can read them.

## Helping on someone else's task

Logging hours on a colleague's task is allowed and encouraged: use **Log hours** on any row in
the Tasks tab. The hours are credited to whoever logged them, so each person's own total stays
right, while the task shows the full effort it took. People who helped appear as small circles
next to the task's owner, the task's history records the help, and the task appears under
**Helping** on that person's My work page. Reports lists the work more than one person touched.

## Outlook meetings

Each person can connect their own Outlook calendar under My work or Settings:
Outlook on the web, Settings, Calendar, Shared calendars, Publish a calendar, then copy
the ICS link. The app reads that link (from the PC it runs on), lists the week's meetings
and logs finished ones as meeting hours with one click, never twice for the same meeting.
Anyone holding the link can read the published calendar, so it is treated as private.
If your company has turned off calendar publishing, connecting through Microsoft 365
needs an app registration from your IT administrator.

## How the numbers are defined

- **Load** = estimated hours still to do on a person's open tasks ÷ weekly capacity.
  Over `OVERLOAD_THRESHOLD_PCT` (default 100%) is *Overloaded*, 60–100% *Balanced*, below 60% *Available*.
  Tasks without an estimate add nothing to load, so the Workload page counts them separately.
- **Utilisation** = hours logged this week ÷ weekly capacity.
- **Within estimate** = completed tasks whose logged hours are at or under the estimate
  (tasks with no estimate are excluded and counted separately).
- **Ticket versus non-ticket** = hours on tasks linked to a Freshdesk ticket versus all other tasks.
- **SLA compliance** = tickets resolved in the period on or before Freshdesk's `due_by`;
  first-response compliance uses `fr_due_by`.
- **Recurring issues** come from the root cause analysis recorded on each ticket in this app.

## Roles

- **Member**: own tasks, own hours and timer, view everything, record root causes.
- **Team lead**: also assigns work to others, logs/removes hours for others, runs a sync.
- **Admin**: also manages team members.

## Reporting assistant

Works with no key (`AI_PROVIDER=none`) using built-in reports. For free-form analysis of
tickets, conversations, root causes and activity logs, set in `.env`:

```
AI_PROVIDER=anthropic        # or openai
AI_API_KEY=...
AI_MODEL=...                 # a model your account offers
```

With a provider set, a summary of your data and the relevant tickets is sent to that
provider with each question.

## MySQL

`pip install pymysql`, create an empty database, and set
`DATABASE_URL=mysql+pymysql://user:password@host:3306/activity_tracker`. Tables are created on start.

## API

Interactive documentation at http://localhost:8000/docs. The endpoints in the Helpdesk API
document are implemented as specified (`/api/v1/sync/run`, `/sync/status`, `/tickets`,
`/dashboard/stats`, `/dashboard/agent-summary`), all with JWT bearer authentication.

## Layout

```
app/main.py              start-up, scheduler, routes
app/models.py            tables
app/services/freshdesk.py  Freshdesk sync
app/services/analytics.py  all report calculations
app/services/chatbot.py    reporting assistant
app/services/report_export.py  Excel report
app/routers/             REST API
static/                  web UI (no build step)
data/                    database (created on first run)
```
