from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..database import get_db
import json

from ..models import ROLES, ChecklistItem, Setting, Task, TaskEvent, Timer, User, utcnow
from ..security import (create_token, current_user, hash_password, require_admin,
                        verify_password)

router = APIRouter(tags=["auth"])


def user_out(u: User) -> dict:
    return {"id": u.id, "name": u.name, "email": u.email, "role": u.role,
            "freshdesk_agent_name": u.freshdesk_agent_name,
            "weekly_capacity_hours": u.weekly_capacity_hours, "is_active": u.is_active,
            "must_change_password": bool(u.must_change_password),
            "from_freshdesk": bool(u.freshdesk_agent_id),
            "calendar_connected": bool(u.calendar_url)}


class Login(BaseModel):
    email: str
    password: str


class PasswordChange(BaseModel):
    current_password: str
    new_password: str


class UserIn(BaseModel):
    name: str
    email: str
    role: str = "MEMBER"
    password: str | None = None
    freshdesk_agent_name: str | None = None
    weekly_capacity_hours: float = 40
    is_active: bool = True


@router.post("/auth/login")
def login(body: Login, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email.strip().lower()).first()
    if (not user or not user.is_active or user.deleted_at
            or not verify_password(body.password, user.password_hash)):
        raise HTTPException(401, "Email or password is incorrect")
    return {"access_token": create_token(user), "token_type": "bearer", "user": user_out(user)}


@router.get("/auth/me")
def me(user: User = Depends(current_user)):
    return user_out(user)


@router.post("/auth/change-password")
def change_password(body: PasswordChange, user: User = Depends(current_user),
                    db: Session = Depends(get_db)):
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(400, "Current password is incorrect")
    if len(body.new_password) < 8:
        raise HTTPException(400, "Use at least 8 characters")
    if body.new_password == body.current_password:
        raise HTTPException(400, "Choose a password different from the current one")
    user.password_hash = hash_password(body.new_password)
    user.must_change_password = False
    db.merge(user)
    db.commit()
    return {"ok": True}


@router.get("/users")
def list_users(include_inactive: bool = False, _: User = Depends(current_user),
               db: Session = Depends(get_db)):
    q = db.query(User).filter(User.deleted_at.is_(None))
    if not include_inactive:
        q = q.filter(User.is_active)
    return [user_out(u) for u in q.order_by(User.name)]


def _apply(u: User, body: UserIn):
    if body.role not in ROLES:
        raise HTTPException(400, f"Role must be one of {', '.join(ROLES)}")
    if not body.name.strip() or "@" not in body.email:
        raise HTTPException(400, "Enter a name and a valid email")
    u.name, u.email, u.role = body.name.strip(), body.email.strip().lower(), body.role
    u.freshdesk_agent_name = (body.freshdesk_agent_name or "").strip() or None
    u.weekly_capacity_hours = max(body.weekly_capacity_hours, 1)
    u.is_active = body.is_active
    if body.password:
        if len(body.password) < 8:
            raise HTTPException(400, "Use at least 8 characters for the password")
        u.password_hash = hash_password(body.password)


@router.post("/users")
def create_user(body: UserIn, _: User = Depends(require_admin), db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == body.email.strip().lower()).first():
        raise HTTPException(400, "A user with this email already exists")
    if not body.password:
        raise HTTPException(400, "Set an initial password")
    u = User(must_change_password=True)
    _apply(u, body)
    db.add(u)
    db.commit()
    return user_out(u)


@router.put("/users/{user_id}")
def update_user(user_id: int, body: UserIn, admin: User = Depends(require_admin),
                db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "User not found")
    other = db.query(User).filter(User.email == body.email.strip().lower(), User.id != user_id).first()
    if other:
        raise HTTPException(400, "A user with this email already exists")
    if u.id == admin.id and (body.role != "ADMIN" or not body.is_active):
        raise HTTPException(400, "You cannot remove your own administrator access")
    _apply(u, body)
    db.commit()
    return user_out(u)


@router.delete("/users/{user_id}")
def delete_user(user_id: int, handover_to: int | None = None,
                admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    """Remove a team member. Their logged hours stay in reports; a Freshdesk agent is
    remembered so the next sync does not add them back. Their open work either goes to
    the person named in handover_to, or, for tasks that only mirror a Freshdesk ticket
    and hold no hours, is dropped so it does not sit in the unassigned list for ever."""
    u = db.get(User, user_id)
    if not u or u.deleted_at:
        raise HTTPException(404, "User not found")
    if u.id == admin.id:
        raise HTTPException(400, "You cannot remove your own account")
    if u.role == "ADMIN" and db.query(User).filter(
            User.role == "ADMIN", User.deleted_at.is_(None), User.is_active, User.id != u.id).count() == 0:
        raise HTTPException(400, "At least one administrator must remain")
    successor = db.get(User, handover_to) if handover_to else None
    if handover_to and (not successor or successor.deleted_at or not successor.is_active):
        raise HTTPException(400, "Choose a team member to hand the work to")
    handed = dropped = unassigned = 0
    for task in db.query(Task).filter(Task.assignee_id == u.id, Task.status != "DONE"):
        if successor:
            task.assignee_id = successor.id
            db.add(TaskEvent(task_id=task.id, user_id=admin.id, kind="ASSIGNEE",
                             detail=f"Handed over to {successor.name} when {u.name} was removed from the team"))
            handed += 1
        elif task.auto_created and task.ticket_id and not task.logs:
            db.query(ChecklistItem).filter(ChecklistItem.task_id == task.id).delete(synchronize_session=False)
            db.query(TaskEvent).filter(TaskEvent.task_id == task.id).delete(synchronize_session=False)
            db.query(Timer).filter(Timer.task_id == task.id).delete(synchronize_session=False)
            db.delete(task)
            dropped += 1
        else:
            task.assignee_id = None
            db.add(TaskEvent(task_id=task.id, user_id=admin.id, kind="ASSIGNEE",
                             detail=f"Left unassigned when {u.name} was removed from the team"))
            unassigned += 1
    db.query(Timer).filter(Timer.user_id == u.id).delete(synchronize_session=False)
    if u.freshdesk_agent_id:
        row = db.get(Setting, "ignored_agents")
        ids = set(json.loads(row.value)) if row and row.value else set()
        ids.add(u.freshdesk_agent_id)
        db.merge(Setting(key="ignored_agents", value=json.dumps(sorted(ids))))
    u.deleted_at, u.is_active = utcnow(), False
    u.email = f"removed-{u.id}-{u.email}"[:200]   # frees the address for re-use
    u.freshdesk_agent_id = None
    db.commit()
    return {"ok": True, "handed_over": handed, "tasks_unassigned": unassigned,
            "tasks_dropped": dropped, "successor": successor.name if successor else None}
