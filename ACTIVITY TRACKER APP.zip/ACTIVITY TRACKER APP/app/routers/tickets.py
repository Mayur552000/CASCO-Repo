from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import PRIORITY_LABELS, RCA_CATEGORIES, RESOLVED_CODES, Ticket, TicketRCA, User, utcnow
from ..security import current_user
from ..services import analytics as an
from .tasks import task_out

router = APIRouter(tags=["tickets"])


class RCAIn(BaseModel):
    category: str
    root_cause: str
    resolution: str | None = None
    preventive_action: str | None = None
    is_recurring: bool = False


def ticket_out(t: Ticket, hours: dict | None = None) -> dict:
    now = utcnow()
    unresolved = t.status not in RESOLVED_CODES
    return {
        "id": t.id, "subject": t.subject, "status": t.status, "status_label": t.status_label,
        "lifecycle": t.lifecycle, "priority": t.priority,
        "priority_label": PRIORITY_LABELS.get(t.priority, "Not set"), "type": t.type,
        "group_name": t.group_name, "department": t.department, "location": t.location,
        "agent_name": t.agent_name, "created_at": an.iso(t.created_at),
        "updated_at": an.iso(t.updated_at), "due_by": an.iso(t.due_by),
        "resolved_at": an.iso(t.resolved_at), "unresolved": unresolved,
        "overdue": bool(unresolved and t.due_by and t.due_by < now),
        "age_days": (now - t.created_at).days if t.created_at else None,
        "has_rca": t.rca is not None,
        "hours_logged": an.r1((hours or {}).get(t.id)),
    }


@router.get("/tickets")
def list_tickets(group: str | None = None, location: str | None = None, agent: str | None = None,
                 priority: int | None = None, type: str | None = None,
                 status_filter: str | None = "unresolved", only_managed_agents: bool = False,
                 search: str | None = None, flag: str | None = None, limit: int = 500,
                 _: User = Depends(current_user), db: Session = Depends(get_db)):
    q = an.ticket_query(db, group, location, agent, priority, type, status_filter,
                        only_managed_agents, search, flag)
    rows = q.order_by(Ticket.updated_at.desc()).limit(min(limit, 2000)).all()
    hours = {t["ticket_id"]: t["hours"] for t in an.top_tickets(db, limit=5000)}
    return [ticket_out(t, hours) for t in rows]


@router.get("/tickets/filters")
def ticket_filters(_: User = Depends(current_user), db: Session = Depends(get_db)):
    def distinct(col):
        return sorted(v for (v,) in db.query(col).distinct() if v)
    return {"agents": distinct(Ticket.agent_name), "locations": distinct(Ticket.location),
            "types": distinct(Ticket.type)}


@router.get("/tickets/{ticket_id}")
def get_ticket(ticket_id: int, _: User = Depends(current_user), db: Session = Depends(get_db)):
    t = db.get(Ticket, ticket_id)
    if not t:
        raise HTTPException(404, "Ticket not found. It may not have been synced yet")
    logged = an.logged_by_task(db)
    out = ticket_out(t, {t.id: sum(logged.get(task.id, 0) for task in t.tasks)})
    out.update({
        "description": t.description_text, "tags": t.tags, "requester": t.requester,
        "first_responded_at": an.iso(t.first_responded_at), "fr_due_by": an.iso(t.fr_due_by),
        "conversations": [{"id": c.id, "author": c.author, "body": c.body_text, "private": c.private,
                           "incoming": c.incoming, "created_at": an.iso(c.created_at)}
                          for c in t.conversations],
        "rca": ({"category": t.rca.category, "root_cause": t.rca.root_cause,
                 "resolution": t.rca.resolution, "preventive_action": t.rca.preventive_action,
                 "is_recurring": t.rca.is_recurring, "updated_by": t.rca.updated_by,
                 "updated_at": an.iso(t.rca.updated_at)} if t.rca else None),
        "tasks": [task_out(task, logged) for task in t.tasks],
    })
    return out


@router.put("/tickets/{ticket_id}/rca")
def save_rca(ticket_id: int, body: RCAIn, user: User = Depends(current_user),
             db: Session = Depends(get_db)):
    t = db.get(Ticket, ticket_id)
    if not t:
        raise HTTPException(404, "Ticket not found")
    if body.category not in RCA_CATEGORIES:
        raise HTTPException(400, "Choose a root cause category")
    if not body.root_cause.strip():
        raise HTTPException(400, "Describe the root cause")
    rca = t.rca or TicketRCA(ticket_id=ticket_id)
    rca.category, rca.root_cause = body.category, body.root_cause.strip()
    rca.resolution, rca.preventive_action = body.resolution, body.preventive_action
    rca.is_recurring, rca.updated_by, rca.updated_at = body.is_recurring, user.name, utcnow()
    db.add(rca)
    db.commit()
    return {"ok": True}
