import json
import threading
from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..models import Setting, SyncLog, User
from ..security import current_user, require_admin, require_lead
from ..services import analytics as an
from ..services import chatbot
from ..seed import clear_demo
from ..services.freshdesk import freshdesk, get_setting, set_setting
from ..services.report_export import build_report

router = APIRouter()


@router.get("/dashboard/stats", tags=["dashboard"])
def stats(group: str | None = None, location: str | None = None, agent: str | None = None,
          priority: int | None = None, type: str | None = None,
          only_managed_agents: bool = False, _: User = Depends(current_user),
          db: Session = Depends(get_db)):
    return an.dashboard_stats(db, group=group, location=location, agent=agent, priority=priority,
                              type=type, only_managed_agents=only_managed_agents)


@router.get("/dashboard/agent-summary", tags=["dashboard"])
def agent_summary(_: User = Depends(current_user), db: Session = Depends(get_db)):
    return an.agent_summary(db)


@router.get("/reports/overview", tags=["reports"])
def overview(start: date | None = None, end: date | None = None,
             _: User = Depends(current_user), db: Session = Depends(get_db)):
    return an.overview(db, *an.default_range(start, end))


@router.get("/reports/workload", tags=["reports"])
def workload(_: User = Depends(current_user), db: Session = Depends(get_db)):
    return {"threshold_pct": settings.overload_threshold_pct, "rows": an.workload(db)}


@router.get("/reports/effort", tags=["reports"])
def effort(start: date | None = None, end: date | None = None, user_id: int | None = None,
           _: User = Depends(current_user), db: Session = Depends(get_db)):
    return an.effort(db, *an.default_range(start, end), user_id=user_id)


@router.get("/reports/shared-work", tags=["reports"])
def shared_work(start: date | None = None, end: date | None = None,
                _: User = Depends(current_user), db: Session = Depends(get_db)):
    return an.shared_work(db, *an.default_range(start, end))


@router.get("/reports/completed", tags=["reports"])
def completed(user_id: int | None = None, weeks: int = 8, _: User = Depends(current_user),
              db: Session = Depends(get_db)):
    return an.completed_by_week(db, max(1, min(weeks, 26)), user_id)


@router.get("/reports/export.xlsx", tags=["reports"])
def export(start: date | None = None, end: date | None = None,
           _: User = Depends(current_user), db: Session = Depends(get_db)):
    s, e = an.default_range(start, end)
    return Response(build_report(db, s, e),
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="activity-report-{s}-to-{e}.xlsx"'})


# ------------------------------------------------------------------- sync
def _log_out(l: SyncLog | None):
    if not l:
        return None
    return {"id": l.id, "started_at": an.iso(l.started_at), "completed_at": an.iso(l.completed_at),
            "status": l.status, "trigger": l.trigger, "tickets_processed": l.tickets_processed,
            "conversations_processed": l.conversations_processed,
            "agents_imported": l.agents_imported or 0, "error_summary": l.error_summary}


class FreshdeskConfig(BaseModel):
    base_url: str
    api_key: str | None = None      # empty keeps the saved key
    location_field: str | None = None


@router.post("/sync/run", tags=["sync"])
def run_sync(_: User = Depends(require_lead)):
    return freshdesk.sync_tickets(trigger="MANUAL")


@router.get("/sync/status", tags=["sync"])
def sync_status(_: User = Depends(current_user), db: Session = Depends(get_db)):
    logs = db.query(SyncLog).order_by(SyncLog.id.desc()).limit(10).all()
    configured = freshdesk.is_configured
    key = freshdesk.key
    return {"is_configured": configured, "base_url": freshdesk.base,
            "api_key_hint": ("ends in " + key[-4:]) if len(key) >= 8 else ("saved" if key else None),
            "interval_minutes": settings.sync_interval_minutes,
            "location_field": freshdesk.location_field,
            "custom_fields": json.loads(get_setting(db, "freshdesk_custom_fields", "[]")),
            "has_sample_data": db.query(User).filter(User.is_demo.is_(True)).count() > 0,
            "new_member_password": settings.new_member_password,
            "last_sync": _log_out(logs[0] if logs else None),
            "recent_logs": [_log_out(l) for l in logs]}


@router.put("/sync/config", tags=["sync"])
def save_config(body: FreshdeskConfig, _: User = Depends(require_admin), db: Session = Depends(get_db)):
    """Check the address and key against Freshdesk, save them, drop the sample data and
    start the first sync in the background."""
    base = body.base_url.strip().rstrip("/")
    if base and not base.startswith("http"):
        base = "https://" + base
    freshdesk.is_configured  # loads the saved values
    key = (body.api_key or "").strip() or freshdesk.key
    if not base or not key:
        raise HTTPException(400, "Enter the Freshdesk address and an API key")
    try:
        choices = freshdesk.test_connection(base, key)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    set_setting(db, "freshdesk_base_url", base)
    set_setting(db, "freshdesk_api_key", key)
    if body.location_field is not None:
        set_setting(db, "freshdesk_location_field", body.location_field.strip())
    set_setting(db, "freshdesk_custom_fields", json.dumps(choices["custom_fields"]))
    db.commit()
    removed = clear_demo(db)
    threading.Thread(target=freshdesk.sync_tickets, kwargs={"trigger": "MANUAL"}, daemon=True).start()
    return {"ok": True, "sample_data_removed": removed > 0}


@router.post("/sync/clear-sample-data", tags=["sync"])
def clear_sample(_: User = Depends(require_admin), db: Session = Depends(get_db)):
    return {"removed": clear_demo(db)}


# ------------------------------------------------------------------- chat
class ChatIn(BaseModel):
    question: str
    history: list[dict] = []


@router.get("/chat/status", tags=["assistant"])
def chat_status(_: User = Depends(current_user)):
    return {"mode": settings.ai_provider if chatbot.ai_enabled() else "built-in",
            "model": settings.ai_model if chatbot.ai_enabled() else None}


@router.post("/chat", tags=["assistant"])
def chat(body: ChatIn, _: User = Depends(current_user), db: Session = Depends(get_db)):
    question = body.question.strip()[:2000]
    if not question:
        return {"answer": "Type a question first.", "mode": "built-in", "sources": []}
    return chatbot.answer(db, question, body.history)
