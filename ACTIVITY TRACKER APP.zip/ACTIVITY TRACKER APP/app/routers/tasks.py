from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..models import (CATEGORIES, OPEN_TASK_STATUSES, RCA_CATEGORIES, RESOLVED_CODES, TASK_STATUSES,
                      ChecklistItem, Task, TaskEvent, Ticket, TimeLog, Timer, User, utcnow)
from ..security import current_user, is_lead
from ..services import analytics as an
from ..services.calendar import CalendarError, events_between

router = APIRouter(tags=["tasks"])
STATUS_NAMES = {"TODO": "To do", "IN_PROGRESS": "In progress", "ON_HOLD": "On hold", "DONE": "Done"}
MEETINGS_TITLE = "Meetings"


class TaskIn(BaseModel):
    title: str
    description: str | None = None
    category: str = "OTHER"
    ticket_id: int | None = None
    assignee_id: int | None = None
    estimated_hours: float = 0
    status: str = "TODO"
    priority: int = 2
    start_date: date | None = None
    due_date: date | None = None


class EstimateIn(BaseModel):
    estimated_hours: float


class ChecklistIn(BaseModel):
    title: str


class BulkAssignIn(BaseModel):
    task_ids: list[int]
    assignee_id: int


class ChecklistUpdate(BaseModel):
    title: str | None = None
    done: bool | None = None


class StatusIn(BaseModel):
    status: str


class LogIn(BaseModel):
    task_id: int
    work_date: date
    hours: float
    note: str | None = None
    user_id: int | None = None


class TimerStart(BaseModel):
    task_id: int


class TimerStop(BaseModel):
    note: str | None = None
    discard: bool = False


class CalendarIn(BaseModel):
    url: str | None = None


class MeetingIn(BaseModel):
    ref: str | None = None
    title: str
    date: date
    hours: float


class MeetingsIn(BaseModel):
    meetings: list[MeetingIn]


def task_out(t: Task, logged: dict, helpers: dict | None = None, steps: dict | None = None,
             ticket_agents: dict | None = None) -> dict:
    actual = logged.get(t.id, 0.0)
    people = (helpers or {}).get(t.id, [])
    done, total = (steps or {}).get(t.id, (0, 0))
    return {
        "contributors": people,
        "ticket_agent": (ticket_agents or {}).get(t.ticket_id),
        "helpers": [p for p in people if p["user_id"] != t.assignee_id],
        "steps_done": done, "steps_total": total,
        "id": t.id, "title": t.title, "description": t.description, "category": t.category,
        "ticket_id": t.ticket_id, "assignee_id": t.assignee_id,
        "assignee": t.assignee.name if t.assignee else None,
        "estimated_hours": t.estimated_hours, "actual_hours": an.r1(actual),
        "remaining_hours": an.r1(max(t.estimated_hours - actual, 0)),
        "over_estimate": t.estimated_hours > 0 and actual > t.estimated_hours,
        "progress_pct": min(an.pct(actual, t.estimated_hours), 999) if t.estimated_hours else None,
        "status": t.status, "priority": t.priority,
        "start_date": an.iso(t.start_date), "due_date": an.iso(t.due_date),
        "overdue": bool(t.due_date and t.due_date < date.today() and t.status != "DONE"),
        "completed_at": an.iso(t.completed_at), "created_at": an.iso(t.created_at),
        "auto_created": bool(t.auto_created), "standing": bool(t.standing),
    }


def log_out(l: TimeLog) -> dict:
    return {"id": l.id, "task_id": l.task_id, "task": l.task.title, "category": l.task.category,
            "ticket_id": l.task.ticket_id, "user_id": l.user_id, "user": l.user.name,
            "work_date": l.work_date.isoformat(), "hours": l.hours, "note": l.note, "source": l.source,
            "standing": bool(l.task.standing)}


def record(db: Session, task: Task, user: User | None, kind: str, detail: str) -> None:
    db.add(TaskEvent(task_id=task.id, user_id=user.id if user else None, kind=kind, detail=detail))


def _can_edit(user: User, task: Task) -> bool:
    return is_lead(user) or task.assignee_id == user.id or task.created_by == user.id


def _h(x: float) -> str:
    return f"{x:g} h" if x else "no estimate"


def _set_status(db: Session, task: Task, status: str, user: User) -> None:
    if status == task.status:
        return
    before = task.status
    task.status = status
    if status == "DONE":
        task.completed_at = utcnow()
        record(db, task, user, "STATUS", "Marked done")
    else:
        task.completed_at = None
        record(db, task, user, "STATUS", ("Reopened" if before == "DONE" else "Status changed")
               + f": {STATUS_NAMES[before]} to {STATUS_NAMES[status]}")


def _apply(task: Task, body: TaskIn, user: User, db: Session, is_new: bool):
    if not body.title.strip():
        raise HTTPException(400, "Give the task a title")
    if body.category not in CATEGORIES:
        raise HTTPException(400, "Unknown category")
    if body.status not in TASK_STATUSES:
        raise HTTPException(400, "Unknown status")
    if body.estimated_hours < 0:
        raise HTTPException(400, "Estimated hours cannot be negative")
    if body.ticket_id and not db.get(Ticket, body.ticket_id):
        raise HTTPException(400, f"Ticket #{body.ticket_id} has not been synced from Freshdesk")
    lead = is_lead(user)
    current_est = 0.0 if is_new else (task.estimated_hours or 0.0)
    if not lead and abs(body.estimated_hours - current_est) > 1e-9:
        raise HTTPException(403, "Only an administrator or team lead can set or change the estimate")
    assignee = body.assignee_id or (task.assignee_id if not is_new else None) or user.id
    if not lead and assignee != user.id:
        raise HTTPException(403, "Only team leads can assign work to other people")
    person = db.get(User, assignee)
    if not person or person.deleted_at:
        raise HTTPException(400, "Assignee not found")
    if not is_new:
        if abs(body.estimated_hours - current_est) > 1e-9:
            record(db, task, user, "ESTIMATE", f"Estimate changed from {_h(current_est)} to {_h(body.estimated_hours)}")
        if assignee != task.assignee_id:
            record(db, task, user, "ASSIGNEE", f"Assigned to {person.name}")
        if body.due_date != task.due_date:
            record(db, task, user, "DUE", f"Due date set to {body.due_date.strftime('%d %b %Y') if body.due_date else 'none'}")
    task.title, task.description = body.title.strip()[:300], body.description
    task.category = "TICKET" if body.ticket_id and body.category == "OTHER" else body.category
    task.ticket_id, task.assignee_id = body.ticket_id, assignee
    task.estimated_hours, task.priority = body.estimated_hours, body.priority
    task.start_date, task.due_date = body.start_date, body.due_date
    if is_new:
        task.status = body.status
        task.completed_at = utcnow() if body.status == "DONE" else None
    else:
        _set_status(db, task, body.status, user)


@router.get("/meta")
def meta(_: User = Depends(current_user), db: Session = Depends(get_db)):
    return {"categories": CATEGORIES, "task_statuses": TASK_STATUSES, "rca_categories": RCA_CATEGORIES,
            "open_tasks": db.query(Task).filter(Task.status.in_(OPEN_TASK_STATUSES), Task.standing.isnot(True)).count(),
            "unresolved_tickets": db.query(Ticket).filter(Ticket.status.notin_(RESOLVED_CODES)).count()}


def checklist_out(i: ChecklistItem) -> dict:
    return {"id": i.id, "task_id": i.task_id, "title": i.title, "done": bool(i.done),
            "done_at": an.iso(i.done_at)}


def steps_by_task(db: Session) -> dict[int, tuple[int, int]]:
    from sqlalchemy import case, func
    rows = (db.query(ChecklistItem.task_id, func.count(ChecklistItem.id),
                     func.sum(case((ChecklistItem.done.is_(True), 1), else_=0)))
            .group_by(ChecklistItem.task_id).all())
    return {task_id: (int(done or 0), int(total or 0)) for task_id, total, done in rows}


@router.get("/tasks")
def list_tasks(assignee_id: int | None = None, status: str | None = None, category: str | None = None,
               kind: str | None = None, ticket_id: int | None = None, search: str | None = None,
               completed_since: date | None = None, include_standing: bool = False,
               helped_by: int | None = None,
               _: User = Depends(current_user), db: Session = Depends(get_db)):
    q = db.query(Task).options(joinedload(Task.assignee))
    if helped_by:
        from sqlalchemy import or_
        helped = db.query(TimeLog.task_id).filter(TimeLog.user_id == helped_by)
        q = q.filter(Task.id.in_(helped),
                     or_(Task.assignee_id.is_(None), Task.assignee_id != helped_by))
    if not include_standing:
        q = q.filter(Task.standing.isnot(True))
    if assignee_id == 0:
        q = q.filter(Task.assignee_id.is_(None))
    elif assignee_id:
        q = q.filter(Task.assignee_id == assignee_id)
    if status == "OPEN":
        q = q.filter(Task.status.in_(OPEN_TASK_STATUSES))
    elif status:
        q = q.filter(Task.status == status)
    if completed_since:
        q = q.filter(Task.completed_at >= datetime.combine(completed_since, datetime.min.time()))
    if category:
        q = q.filter(Task.category == category)
    if kind == "ticket":
        q = q.filter(Task.ticket_id.isnot(None))
    elif kind == "non_ticket":
        q = q.filter(Task.ticket_id.is_(None))
    if ticket_id:
        q = q.filter(Task.ticket_id == ticket_id)
    if search:
        q = q.filter(Task.title.ilike(f"%{search}%"))
    logged, helpers, steps = an.logged_by_task(db), an.contributors_by_task(db), steps_by_task(db)
    agents = {tid: name for tid, name in db.query(Ticket.id, Ticket.agent_name) if name}
    if status == "DONE":
        q = q.order_by(Task.completed_at.desc())
    else:
        q = q.order_by(Task.status == "DONE", Task.due_date.is_(None), Task.due_date, Task.id.desc())
    return [task_out(t, logged, helpers, steps, agents) for t in q.limit(2000).all()]


@router.put("/tasks/bulk-assign")
def bulk_assign(body: BulkAssignIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Hand a set of tasks to one person. Used to clear the unassigned list."""
    if not is_lead(user):
        raise HTTPException(403, "Only an administrator or team lead can assign work to other people")
    person = db.get(User, body.assignee_id)
    if not person or person.deleted_at or not person.is_active:
        raise HTTPException(400, "Choose a team member")
    moved = 0
    for task in db.query(Task).filter(Task.id.in_(body.task_ids[:500]), Task.status != "DONE"):
        if task.assignee_id != person.id:
            task.assignee_id = person.id
            record(db, task, user, "ASSIGNEE", f"Assigned to {person.name}")
            moved += 1
    db.commit()
    return {"assigned": moved, "to": person.name}


@router.get("/tasks/{task_id}")
def get_task(task_id: int, _: User = Depends(current_user), db: Session = Depends(get_db)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    return task_out(task, an.logged_by_task(db))


@router.get("/tasks/{task_id}/detail")
def task_detail(task_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Everything shown when a task row is opened: its steps and every hour logged on it."""
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    logs = (db.query(TimeLog).options(joinedload(TimeLog.user), joinedload(TimeLog.task))
            .filter(TimeLog.task_id == task_id)
            .order_by(TimeLog.work_date.desc(), TimeLog.id.desc()).all())
    steps = (db.query(ChecklistItem).filter(ChecklistItem.task_id == task_id)
             .order_by(ChecklistItem.done, ChecklistItem.position, ChecklistItem.id).all())
    return {"task_id": task_id, "can_edit": _can_edit(user, task),
            "checklist": [checklist_out(i) for i in steps],
            "logs": [log_out(l) for l in logs],
            "contributors": an.contributors_by_task(db).get(task_id, [])}


@router.post("/tasks/{task_id}/checklist")
def add_step(task_id: int, body: ChecklistIn, user: User = Depends(current_user),
             db: Session = Depends(get_db)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    if not _can_edit(user, task):
        raise HTTPException(403, "You can only change steps on your own tasks")
    if not body.title.strip():
        raise HTTPException(400, "Give the step a name")
    if db.query(ChecklistItem).filter(ChecklistItem.task_id == task_id).count() >= 50:
        raise HTTPException(400, "A task can hold 50 steps")
    item = ChecklistItem(task_id=task_id, title=body.title.strip()[:300], created_by=user.id,
                         position=db.query(ChecklistItem).filter(ChecklistItem.task_id == task_id).count())
    db.add(item)
    db.commit()
    db.refresh(item)
    return checklist_out(item)


@router.put("/checklist/{item_id}")
def update_step(item_id: int, body: ChecklistUpdate, user: User = Depends(current_user),
                db: Session = Depends(get_db)):
    item = db.get(ChecklistItem, item_id)
    if not item:
        raise HTTPException(404, "Step not found")
    task = db.get(Task, item.task_id)
    if not _can_edit(user, task):
        raise HTTPException(403, "You can only change steps on your own tasks")
    if body.title is not None and body.title.strip():
        item.title = body.title.strip()[:300]
    if body.done is not None:
        item.done = body.done
        item.done_at = utcnow() if body.done else None
    db.commit()
    return checklist_out(item)


@router.delete("/checklist/{item_id}")
def delete_step(item_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    item = db.get(ChecklistItem, item_id)
    if not item:
        raise HTTPException(404, "Step not found")
    if not _can_edit(user, db.get(Task, item.task_id)):
        raise HTTPException(403, "You can only change steps on your own tasks")
    db.delete(item)
    db.commit()
    return {"ok": True}


@router.get("/tasks/{task_id}/history")
def task_history(task_id: int, _: User = Depends(current_user), db: Session = Depends(get_db)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    events = [{"at": an.iso(e.at), "who": e.user.name if e.user else "Freshdesk sync",
               "kind": e.kind, "detail": e.detail}
              for e in db.query(TaskEvent).options(joinedload(TaskEvent.user))
              .filter(TaskEvent.task_id == task_id)]
    for l in db.query(TimeLog).options(joinedload(TimeLog.user)).filter(TimeLog.task_id == task_id):
        how = {"TIMER": " with the timer", "CALENDAR": " from the calendar"}.get(l.source, "")
        events.append({"at": an.iso(l.created_at), "who": l.user.name, "kind": "HOURS",
                       "detail": f"Logged {l.hours:g} h for {l.work_date.strftime('%d %b')}{how}"
                                 + (f": {l.note}" if l.note else "")})
    creator = db.get(User, task.created_by) if task.created_by else None
    events.append({"at": an.iso(task.created_at), "who": creator.name if creator else "Freshdesk sync",
                   "kind": "CREATED", "detail": "Task created" + (" from a Freshdesk ticket" if task.auto_created else "")})
    events.sort(key=lambda e: e["at"] or "", reverse=True)
    return events


@router.post("/tasks")
def create_task(body: TaskIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    task = Task(created_by=user.id, status="TODO")
    _apply(task, body, user, db, is_new=True)
    db.add(task)
    db.commit()
    db.refresh(task)
    return task_out(task, {})


@router.put("/tasks/{task_id}")
def update_task(task_id: int, body: TaskIn, user: User = Depends(current_user),
                db: Session = Depends(get_db)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    if not _can_edit(user, task):
        raise HTTPException(403, "You can only change your own tasks")
    _apply(task, body, user, db, is_new=False)
    db.commit()
    return task_out(task, an.logged_by_task(db))


@router.put("/tasks/{task_id}/status")
def set_status(task_id: int, body: StatusIn, user: User = Depends(current_user),
               db: Session = Depends(get_db)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    if not _can_edit(user, task):
        raise HTTPException(403, "You can only change your own tasks")
    if body.status not in TASK_STATUSES:
        raise HTTPException(400, "Unknown status")
    _set_status(db, task, body.status, user)
    db.commit()
    return task_out(task, an.logged_by_task(db))


@router.put("/tasks/{task_id}/estimate")
def set_estimate(task_id: int, body: EstimateIn, user: User = Depends(current_user),
                 db: Session = Depends(get_db)):
    if not is_lead(user):
        raise HTTPException(403, "Only an administrator or team lead can set or change the estimate")
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    if not 0 <= body.estimated_hours <= 2000:
        raise HTTPException(400, "Enter an estimate between 0 and 2000 hours")
    if abs(body.estimated_hours - (task.estimated_hours or 0)) > 1e-9:
        record(db, task, user, "ESTIMATE",
               f"Estimate changed from {_h(task.estimated_hours or 0)} to {_h(body.estimated_hours)}")
        task.estimated_hours = body.estimated_hours
        db.commit()
    return task_out(task, an.logged_by_task(db))


@router.delete("/tasks/{task_id}")
def delete_task(task_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    if not _can_edit(user, task):
        raise HTTPException(403, "You can only delete your own tasks")
    if task.logs and not is_lead(user):
        raise HTTPException(400, "This task has logged hours. Ask a team lead to delete it")
    db.query(Timer).filter(Timer.task_id == task_id).delete()
    db.query(TaskEvent).filter(TaskEvent.task_id == task_id).delete()
    db.query(ChecklistItem).filter(ChecklistItem.task_id == task_id).delete()
    db.delete(task)
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------- time logs
@router.get("/timelogs")
def list_logs(user_id: int | None = None, task_id: int | None = None, start: date | None = None,
              end: date | None = None, _: User = Depends(current_user), db: Session = Depends(get_db)):
    q = db.query(TimeLog).options(joinedload(TimeLog.task), joinedload(TimeLog.user))
    if user_id:
        q = q.filter(TimeLog.user_id == user_id)
    if task_id:
        q = q.filter(TimeLog.task_id == task_id)
    if start:
        q = q.filter(TimeLog.work_date >= start)
    if end:
        q = q.filter(TimeLog.work_date <= end)
    return [log_out(l) for l in q.order_by(TimeLog.work_date.desc(), TimeLog.id.desc()).limit(1000)]


def _add_log(db, user: User, task_id: int, work_date: date, hours: float, note, source,
             for_user=None, external_ref=None):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    if not 0 < hours <= 24:
        raise HTTPException(400, "Hours must be between 0 and 24")
    if work_date > date.today():
        raise HTTPException(400, "You cannot log hours for a future date")
    owner = for_user if (for_user and is_lead(user)) else user.id
    day_total = sum(l.hours for l in db.query(TimeLog).filter(
        TimeLog.user_id == owner, TimeLog.work_date == work_date))
    if day_total + hours > 24:
        raise HTTPException(400, f"That would put more than 24 hours on {work_date.strftime('%d %b')}")
    entry = TimeLog(task_id=task_id, user_id=owner, work_date=work_date, hours=round(hours, 2),
                    note=(note or "").strip()[:300] or None, source=source, external_ref=external_ref)
    db.add(entry)
    if task.status == "TODO" and not task.standing and task.assignee_id == owner:
        _set_status(db, task, "IN_PROGRESS", user)
    if task.assignee_id not in (None, owner):
        record(db, task, user, "HOURS", f"{user.name} helped: {hours:g} h on "
                                        f"{work_date.strftime('%d %b')}")
    db.commit()
    db.refresh(entry)
    return entry


@router.post("/timelogs")
def create_log(body: LogIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    return log_out(_add_log(db, user, body.task_id, body.work_date, body.hours, body.note,
                            "MANUAL", body.user_id))


@router.delete("/timelogs/{log_id}")
def delete_log(log_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    entry = db.get(TimeLog, log_id)
    if not entry:
        raise HTTPException(404, "Entry not found")
    if entry.user_id != user.id and not is_lead(user):
        raise HTTPException(403, "You can only remove your own entries")
    record(db, entry.task, user, "HOURS",
           f"Removed {entry.hours:g} h logged for {entry.work_date.strftime('%d %b')}")
    db.delete(entry)
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ timer
def _timer_out(t: Timer | None):
    if not t:
        return None
    return {"task_id": t.task_id, "task": t.task.title, "started_at": an.iso(t.started_at)}


@router.get("/timer")
def get_timer(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return {"timer": _timer_out(db.get(Timer, user.id))}


@router.post("/timer/start")
def start_timer(body: TimerStart, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if db.get(Timer, user.id):
        raise HTTPException(400, "Stop the running timer first")
    task = db.get(Task, body.task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    timer = Timer(user_id=user.id, task_id=task.id, started_at=utcnow())
    db.add(timer)
    if task.status == "TODO":
        _set_status(db, task, "IN_PROGRESS", user)
    db.commit()
    return {"timer": _timer_out(timer)}


@router.post("/timer/stop")
def stop_timer(body: TimerStop, user: User = Depends(current_user), db: Session = Depends(get_db)):
    timer = db.get(Timer, user.id)
    if not timer:
        raise HTTPException(400, "No timer is running")
    seconds = (utcnow() - timer.started_at).total_seconds()
    task_id = timer.task_id
    db.delete(timer)
    db.commit()
    if body.discard or seconds < 60:
        return {"logged": None, "message": "Timer discarded (under a minute)" if not body.discard else "Timer discarded"}
    hours = min(max(round(seconds / 3600, 2), 0.02), 24)
    entry = _add_log(db, user, task_id, date.today(), hours, body.note, "TIMER")
    return {"logged": log_out(entry)}


# --------------------------------------------------------------- meetings
def meetings_task(db: Session, user: User) -> Task:
    """Each person has one ongoing 'Meetings' task that meeting hours are logged against."""
    task = (db.query(Task).filter(Task.assignee_id == user.id, Task.standing.is_(True),
                                  Task.category == "MEETING").first())
    if not task:
        task = Task(title=MEETINGS_TITLE, category="MEETING", assignee_id=user.id, created_by=user.id,
                    status="IN_PROGRESS", standing=True, estimated_hours=0, priority=2,
                    description="Hours spent in meetings. Logged from your Outlook calendar or by hand.")
        db.add(task)
        db.commit()
        db.refresh(task)
    return task


@router.put("/me/calendar")
def save_calendar(body: CalendarIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    url = (body.url or "").strip()
    if url:
        if not (url.startswith("https://") or url.startswith("webcal://") or url.startswith("http://")):
            raise HTTPException(400, "Paste the ICS link that starts with https://")
        try:
            events_between(url, date.today() - timedelta(days=7), date.today(), fresh=True)
        except CalendarError as exc:
            raise HTTPException(400, str(exc))
    user.calendar_url = url or None
    db.merge(user)
    db.commit()
    return {"connected": bool(url)}


@router.get("/me/meetings")
def my_meetings(start: date, end: date, fresh: bool = False, user: User = Depends(current_user),
                db: Session = Depends(get_db)):
    if not user.calendar_url:
        return {"connected": False, "meetings": []}
    try:
        events = events_between(user.calendar_url, start, end, fresh)
    except CalendarError as exc:
        return {"connected": True, "error": str(exc), "meetings": []}
    refs = {r for (r,) in db.query(TimeLog.external_ref).filter(
        TimeLog.user_id == user.id, TimeLog.external_ref.isnot(None))}
    now = datetime.now()
    for e in events:
        e["logged"] = e["ref"] in refs
        e["finished"] = datetime.fromisoformat(e["end"]) <= now
    return {"connected": True, "meetings": events}


@router.post("/me/meetings/log")
def log_meetings(body: MeetingsIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    task = meetings_task(db, user)
    done = 0
    for m in body.meetings:
        if m.ref and db.query(TimeLog).filter(TimeLog.user_id == user.id, TimeLog.external_ref == m.ref).first():
            continue
        _add_log(db, user, task.id, m.date, m.hours, m.title, "CALENDAR" if m.ref else "MANUAL",
                 external_ref=m.ref)
        done += 1
    return {"logged": done}
