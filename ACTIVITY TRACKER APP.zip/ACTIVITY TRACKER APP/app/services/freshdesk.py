"""Freshdesk REST API v2 sync: pulls tickets, field choices and conversations
into the local database so the UI never waits on (or exhausts) the Helpdesk API."""
import json
import logging
import re
import threading
from datetime import datetime, timezone

import httpx
from sqlalchemy.orm import Session

from ..config import settings
from ..database import SessionLocal
from ..models import (RESOLVED_CODES, STATUS_MAP, UNRESOLVED_CODES, Conversation, Setting,
                      SyncLog, Task, TaskEvent, Ticket, User, utcnow)
from ..security import hash_password

log = logging.getLogger("freshdesk")
_lock = threading.Lock()

SEARCH_MAX_PAGES = 10      # Freshdesk search: 30 results per page, 10 pages max
LIST_MAX_PAGES = 5         # 5 x 100 = 500 most recently updated tickets


class RateLimited(Exception):
    def __init__(self, retry_after: str):
        super().__init__(f"Freshdesk rate limit reached; retry after {retry_after}s")
        self.retry_after = retry_after


def parse_dt(value):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return dt.astimezone(timezone.utc).replace(tzinfo=None) if dt.tzinfo else dt
    except ValueError:
        return None


def department_for(group_name: str | None) -> str:
    name = (group_name or "").upper()
    if "QAD" in name:
        return "QAD"
    if "EDI" in name:
        return "EDI"
    return "IT"


def get_setting(db: Session, key: str, default: str = "") -> str:
    row = db.get(Setting, key)
    return row.value if row and row.value else default


def set_setting(db: Session, key: str, value: str) -> None:
    db.merge(Setting(key=key, value=value))


class FreshdeskService:
    """Connection details come from Settings in the app (stored in the database)
    and fall back to the .env file."""

    def _load(self) -> None:
        with SessionLocal() as db:
            self.base = get_setting(db, "freshdesk_base_url", settings.freshdesk_base_url).rstrip("/")
            self.key = get_setting(db, "freshdesk_api_key", settings.freshdesk_api_key)
            self.location_field = get_setting(db, "freshdesk_location_field", settings.location_field)

    @property
    def is_configured(self) -> bool:
        self._load()
        return bool(self.base and self.key)

    def test_connection(self, base: str, key: str) -> dict:
        """Check a URL + key before saving them. Raises ValueError with a readable reason."""
        probe = FreshdeskService()
        probe.base = base.rstrip("/")
        try:
            with httpx.Client(auth=(key, "X"), timeout=20) as client:
                choices = probe._field_choices(client)
        except httpx.HTTPStatusError as exc:
            code = exc.response.status_code
            raise ValueError("Freshdesk rejected the API key" if code in (401, 403)
                             else f"Freshdesk answered with HTTP {code}; check the address")
        except RateLimited as exc:
            raise ValueError(str(exc))
        except httpx.HTTPError as exc:
            raise ValueError(f"Could not reach {base} ({type(exc).__name__})")
        return choices

    # ---- HTTP -------------------------------------------------------------
    def _get(self, client: httpx.Client, path: str, params: dict | None = None):
        resp = client.get(f"{self.base}{path}", params=params)
        remaining = resp.headers.get("X-RateLimit-Remaining")
        if remaining is not None and remaining.isdigit() and int(remaining) < 5:
            log.warning("Freshdesk API quota low: %s calls remaining", remaining)
        if resp.status_code == 429:
            raise RateLimited(resp.headers.get("Retry-After", "60"))
        resp.raise_for_status()
        return resp.json()

    def _field_choices(self, client: httpx.Client) -> dict:
        """Status labels, agent names and group names from /ticket_fields."""
        out = {"status": {}, "agents": {}, "groups": {}, "custom_fields": []}
        for field in self._get(client, "/api/v2/ticket_fields"):
            name, choices = field.get("name"), field.get("choices") or {}
            if name == "status" and isinstance(choices, dict):
                for code, labels in choices.items():
                    label = labels[0] if isinstance(labels, (list, tuple)) and labels else labels
                    out["status"][int(code)] = str(label)
            elif name in ("agent", "group") and isinstance(choices, dict):
                target = out["agents" if name == "agent" else "groups"]
                for label, ident in choices.items():
                    target[int(ident)] = str(label)
            if not field.get("default", True):
                out["custom_fields"].append({"name": name, "label": field.get("label")})
        return out

    def _fetch_agents(self, client: httpx.Client, choices: dict) -> list[dict]:
        """Agents with names and emails. The agents API needs an administrator's API key;
        without it we fall back to the agent names offered on the ticket form."""
        agents = []
        try:
            for page in range(1, 11):
                rows = self._get(client, "/api/v2/agents", {"per_page": 100, "page": page})
                for a in rows:
                    contact = a.get("contact") or {}
                    if contact.get("name"):
                        agents.append({"id": a["id"], "name": contact["name"].strip(),
                                       "email": (contact.get("email") or "").strip().lower()})
                if len(rows) < 100:
                    break
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code not in (401, 403):
                raise
            log.warning("API key cannot list agents (HTTP %s); using ticket form agent names",
                        exc.response.status_code)
            agents = [{"id": i, "name": n, "email": ""} for i, n in choices["agents"].items()]
        for a in agents:
            choices["agents"].setdefault(a["id"], a["name"])
        return agents

    def _fetch_tickets(self, client: httpx.Client) -> dict:
        """Unresolved tickets via search, then recent tickets with SLA stats."""
        found: dict[int, dict] = {}
        query = " OR ".join(f"status:{c}" for c in UNRESOLVED_CODES)
        for page in range(1, SEARCH_MAX_PAGES + 1):
            data = self._get(client, "/api/v2/search/tickets",
                             {"query": f'"{query}"', "page": page})
            results = data.get("results", [])
            for t in results:
                found[t["id"]] = t
            if len(results) < 30:
                break
        for page in range(1, LIST_MAX_PAGES + 1):
            rows = self._get(client, "/api/v2/tickets", {
                "page": page, "per_page": 100, "include": "stats",
                "order_by": "updated_at", "order_type": "desc"})
            for t in rows:
                found[t["id"]] = {**found.get(t["id"], {}), **t}
            if len(rows) < 100:
                break
        return found

    # ---- Normalise + store ------------------------------------------------
    def _upsert(self, db: Session, raw: dict, choices: dict) -> Ticket:
        ticket = db.get(Ticket, raw["id"]) or Ticket(id=raw["id"])
        db.add(ticket)
        code = raw.get("status")
        default_label, lifecycle = STATUS_MAP.get(code, (f"Status {code}", "Unresolved"))
        custom = raw.get("custom_fields") or {}
        group = choices["groups"].get(raw.get("group_id"))
        ticket.subject = (raw.get("subject") or "")[:500]
        if raw.get("description_text") is not None:
            ticket.description_text = raw.get("description_text")
        ticket.status = code
        ticket.status_label = choices["status"].get(code, default_label)
        ticket.lifecycle = lifecycle
        ticket.priority = raw.get("priority")
        ticket.type = raw.get("type")
        ticket.group_name = group
        ticket.department = department_for(group)
        if raw.get("custom_fields") is not None:
            ticket.custom_fields = json.dumps(custom, default=str)
        else:
            custom = json.loads(ticket.custom_fields or "{}")
        ticket.location = str(custom.get(self.location_field) or "") or None
        ticket.responder_id = raw.get("responder_id")
        ticket.agent_name = choices["agents"].get(raw.get("responder_id"))
        ticket.requester = str(raw.get("requester_id") or "")
        ticket.tags = ", ".join(raw.get("tags") or [])
        ticket.is_escalated = bool(raw.get("is_escalated"))
        ticket.created_at = parse_dt(raw.get("created_at"))
        ticket.updated_at = parse_dt(raw.get("updated_at"))
        ticket.due_by = parse_dt(raw.get("due_by"))
        ticket.fr_due_by = parse_dt(raw.get("fr_due_by"))
        stats = raw.get("stats")
        if stats:
            ticket.first_responded_at = parse_dt(stats.get("first_responded_at"))
            ticket.resolved_at = parse_dt(stats.get("resolved_at"))
            ticket.closed_at = parse_dt(stats.get("closed_at"))
        ticket.synced_at = utcnow()
        ticket.is_demo = False
        return ticket

    def _sync_conversations(self, db: Session, client: httpx.Client, choices: dict) -> int:
        """Fetch conversations for the tickets that changed most recently."""
        stale = [t for t in db.query(Ticket).filter(Ticket.is_demo.is_(False))
                 .order_by(Ticket.updated_at.desc()).limit(600)
                 if t.updated_at and (not t.conversations_synced_at
                                      or t.conversations_synced_at < t.updated_at)]
        count = 0
        for ticket in stale[:settings.conversation_sync_limit]:
            rows = self._get(client, f"/api/v2/tickets/{ticket.id}/conversations")
            for c in rows:
                conv = db.get(Conversation, c["id"]) or Conversation(id=c["id"], ticket_id=ticket.id)
                db.add(conv)
                conv.author = (choices["agents"].get(c.get("user_id"))
                               or c.get("from_email") or ("Requester" if c.get("incoming") else "Agent"))
                conv.body_text = c.get("body_text")
                conv.private = bool(c.get("private"))
                conv.incoming = bool(c.get("incoming"))
                conv.created_at = parse_dt(c.get("created_at"))
                count += 1
            ticket.conversations_synced_at = utcnow()
            db.commit()
        return count

    # ---- Public -----------------------------------------------------------
    def sync_tickets(self, trigger: str = "SCHEDULED") -> dict:
        if not self.is_configured:
            return {"status": "NOT_CONFIGURED", "tickets_processed": 0,
                    "error": "Set FRESHDESK_BASE_URL and FRESHDESK_API_KEY in .env"}
        if not _lock.acquire(blocking=False):
            return {"status": "ALREADY_RUNNING", "tickets_processed": 0, "error": None}
        db = SessionLocal()
        entry = SyncLog(trigger=trigger)
        db.add(entry)
        db.commit()
        processed = convs = agents = 0
        try:
            with httpx.Client(auth=(self.key, "X"), timeout=30) as client:
                choices = self._field_choices(client)
                set_setting(db, "freshdesk_custom_fields", json.dumps(choices["custom_fields"]))
                agents = import_agents(db, self._fetch_agents(client, choices))
                raws = self._fetch_tickets(client)
                for raw in raws.values():
                    self._upsert(db, raw, choices)
                    processed += 1
                db.commit()
                link_tickets_to_tasks(db)
                convs = self._sync_conversations(db, client, choices)
            entry.status = "SUCCESS"
        except RateLimited as exc:
            db.rollback()
            entry.status = "RATE_LIMITED"
            entry.error_summary = str(exc)
        except Exception as exc:  # network, auth, unexpected payloads
            db.rollback()
            log.exception("Freshdesk sync failed")
            entry.status = "FAILED"
            entry.error_summary = f"{type(exc).__name__}: {exc}"[:1000]
        finally:
            entry.completed_at = utcnow()
            entry.tickets_processed = processed
            entry.conversations_processed = convs
            entry.agents_imported = agents
            db.merge(entry)
            db.commit()
            result = {"status": entry.status, "tickets_processed": processed,
                      "conversations_processed": convs, "agents_imported": agents,
                      "error": entry.error_summary}
            db.close()
            _lock.release()
        return result


def ignored_agents(db: Session) -> set[int]:
    return set(json.loads(get_setting(db, "ignored_agents", "[]")))


def import_agents(db: Session, agents: list[dict]) -> int:
    """Create a team member for every Freshdesk agent that is not in the app yet.
    People an administrator removed are remembered and not re-created."""
    skip = ignored_agents(db)
    people = db.query(User).filter(User.deleted_at.is_(None)).all()
    by_id = {u.freshdesk_agent_id: u for u in people if u.freshdesk_agent_id}
    by_email = {u.email.lower(): u for u in people}
    by_name = {(u.freshdesk_agent_name or u.name).strip().lower(): u for u in people}
    taken = {e for (e,) in db.query(User.email)}
    password = None
    created = 0
    for a in agents:
        if a["id"] in skip:
            continue
        user = by_id.get(a["id"]) or (by_email.get(a["email"]) if a["email"] else None) \
            or by_name.get(a["name"].lower())
        if user:
            user.freshdesk_agent_id, user.freshdesk_agent_name = a["id"], a["name"]
            continue
        email = a["email"]
        if not email or email in taken:
            slug = re.sub(r"[^a-z0-9]+", ".", a["name"].lower()).strip(".") or "agent"
            email = f"{slug}@helpdesk.local"
            if email in taken:
                email = f"{slug}.{a['id']}@helpdesk.local"
        password = password or hash_password(settings.new_member_password)
        user = User(name=a["name"], email=email, role="MEMBER", password_hash=password,
                    must_change_password=True, freshdesk_agent_id=a["id"],
                    freshdesk_agent_name=a["name"], weekly_capacity_hours=40)
        db.add(user)
        taken.add(email)
        by_id[a["id"]] = user
        created += 1
    db.commit()
    return created


def link_tickets_to_tasks(db: Session) -> None:
    """Keep tracker tasks in step with tickets: create a task for each unresolved
    ticket owned by a team member, and close ticket tasks once the ticket is resolved."""
    users = db.query(User).filter(User.is_active.is_(True), User.deleted_at.is_(None)).all()
    by_id = {u.freshdesk_agent_id: u for u in users if u.freshdesk_agent_id}
    by_agent = {(u.freshdesk_agent_name or u.name).strip().lower(): u for u in users}
    if settings.auto_create_ticket_tasks:
        open_tickets = db.query(Ticket).filter(Ticket.status.notin_(RESOLVED_CODES)).all()
        have_task, auto_task = set(), {}
        for task in db.query(Task).filter(Task.ticket_id.isnot(None)):
            have_task.add(task.ticket_id)
            if task.auto_created and task.ticket_id not in auto_task:
                auto_task[task.ticket_id] = task
        for t in open_tickets:
            owner = by_id.get(t.responder_id) or by_agent.get((t.agent_name or "").strip().lower())
            if not owner:
                continue
            if t.id not in have_task:
                db.add(Task(title=f"#{t.id} {t.subject}"[:300], category="TICKET", ticket_id=t.id,
                            assignee_id=owner.id, priority=t.priority or 2, status="TODO",
                            due_date=t.due_by.date() if t.due_by else None, auto_created=True))
                continue
            # the ticket moved to another agent in Freshdesk: move the task with it
            task = auto_task.get(t.id)
            if task is not None and task.status != "DONE" and task.assignee_id != owner.id:
                task.assignee_id = owner.id
                db.add(TaskEvent(task_id=task.id, kind="ASSIGNEE",
                                 detail=f"Assigned to {owner.name} because ticket #{t.id} "
                                        "was reassigned in Freshdesk"))
    resolved = (db.query(Task).join(Ticket, Task.ticket_id == Ticket.id)
                .filter(Task.auto_created.is_(True), Task.status != "DONE",
                        Ticket.status.in_(RESOLVED_CODES)).all())
    for task in resolved:
        task.status = "DONE"
        task.completed_at = task.ticket.resolved_at or utcnow()
        db.add(TaskEvent(task_id=task.id, kind="STATUS",
                         detail=f"Marked done because ticket #{task.ticket_id} was resolved in Freshdesk"))
    db.commit()


freshdesk = FreshdeskService()
