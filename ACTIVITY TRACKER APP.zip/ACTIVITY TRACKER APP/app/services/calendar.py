"""Meetings from a person's published Outlook calendar (ICS link).

Outlook: Settings > Calendar > Shared calendars > Publish a calendar > copy the ICS link.
The link is fetched by this server, so it must be reachable from the PC running the app."""
import logging
import time
from datetime import date, datetime, timedelta

import httpx

log = logging.getLogger("calendar")
_cache: dict[str, tuple[float, bytes]] = {}
CACHE_SECONDS = 300


class CalendarError(Exception):
    pass


def _fetch(url: str, fresh: bool = False) -> bytes:
    hit = _cache.get(url)
    if hit and not fresh and time.time() - hit[0] < CACHE_SECONDS:
        return hit[1]
    if url.startswith("webcal://"):
        url_http = "https://" + url[len("webcal://"):]
    else:
        url_http = url
    try:
        resp = httpx.get(url_http, timeout=25, follow_redirects=True)
    except httpx.HTTPError as exc:
        raise CalendarError(f"Could not reach the calendar link ({type(exc).__name__}). "
                            "Check the link and that this PC can open it.")
    if resp.status_code != 200:
        raise CalendarError(f"The calendar link answered with HTTP {resp.status_code}. "
                            "It may have been unpublished; publish it again in Outlook.")
    if b"BEGIN:VCALENDAR" not in resp.content[:2000]:
        raise CalendarError("That link did not return a calendar. Use the ICS link, not the HTML link.")
    _cache[url] = (time.time(), resp.content)
    return resp.content


def _local(dt) -> datetime:
    """Event time as naive local time of the PC running the app."""
    if isinstance(dt, datetime):
        return (dt.astimezone() if dt.tzinfo else dt).replace(tzinfo=None)
    return datetime.combine(dt, datetime.min.time())


def events_between(url: str, start: date, end: date, fresh: bool = False) -> list[dict]:
    try:
        import icalendar
        import recurring_ical_events
    except ImportError:
        raise CalendarError("Calendar support is not installed yet. Close the app and start run.bat again.")
    raw = _fetch(url, fresh)
    try:
        cal = icalendar.Calendar.from_ical(raw)
        occurrences = recurring_ical_events.of(cal).between(
            datetime.combine(start, datetime.min.time()),
            datetime.combine(end + timedelta(days=1), datetime.min.time()))
    except Exception as exc:
        log.exception("Calendar parse failed")
        raise CalendarError(f"The calendar could not be read ({type(exc).__name__}).")
    out = []
    for ev in occurrences:
        dtstart = ev.get("DTSTART")
        if dtstart is None or not isinstance(dtstart.dt, datetime):
            continue  # all-day items (holidays, leave) are not meetings
        if str(ev.get("STATUS", "")).upper() == "CANCELLED" or str(ev.get("SUMMARY", "")).lower().startswith("canceled:"):
            continue
        if str(ev.get("TRANSP", "")).upper() == "TRANSPARENT":
            continue  # shown as free
        s = _local(dtstart.dt)
        dtend = ev.get("DTEND")
        e = _local(dtend.dt) if dtend is not None else s + (ev.get("DURATION").dt if ev.get("DURATION") else timedelta(minutes=30))
        hours = round((e - s).total_seconds() / 3600, 2)
        if hours <= 0 or hours > 12:
            continue
        uid = str(ev.get("UID", "")) or f"{ev.get('SUMMARY')}-{s.isoformat()}"
        out.append({"ref": f"{uid}|{s.isoformat()}"[:300], "title": str(ev.get("SUMMARY") or "Busy").strip()[:200],
                    "start": s.isoformat(), "end": e.isoformat(), "date": s.date().isoformat(),
                    "hours": hours, "location": str(ev.get("LOCATION") or "")[:200]})
    out.sort(key=lambda x: x["start"])
    return out
