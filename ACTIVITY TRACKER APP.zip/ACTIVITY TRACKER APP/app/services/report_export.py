"""Management report as an Excel workbook."""
from datetime import date
from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from sqlalchemy.orm import Session, joinedload

from ..models import TimeLog
from . import analytics as an

HEAD_FILL = PatternFill("solid", fgColor="1B2A49")
HEAD_FONT = Font(bold=True, color="FFFFFF")


def _sheet(wb: Workbook, title: str, headers: list[str], rows: list[list]):
    ws = wb.create_sheet(title)
    ws.append(headers)
    for cell in ws[1]:
        cell.fill, cell.font = HEAD_FILL, HEAD_FONT
        cell.alignment = Alignment(vertical="center")
    for row in rows:
        ws.append(row)
    ws.freeze_panes = "A2"
    for i, head in enumerate(headers, 1):
        width = max([len(str(head))] + [len(str(r[i - 1])) for r in rows if r[i - 1] is not None] or [10])
        ws.column_dimensions[get_column_letter(i)].width = min(max(width + 2, 10), 60)
    return ws


def build_report(db: Session, start: date, end: date) -> bytes:
    ov = an.overview(db, start, end)
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = "Team Activity Tracker — management report"
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = f"Period {start.isoformat()} to {end.isoformat()}; generated {date.today().isoformat()}"
    tk, eff, est, sla = ov["tickets"], ov["effort"], ov["estimates"], ov["sla"]
    lines = [
        ("Unresolved tickets", tk["unresolved_tickets"]), ("Overdue tickets", tk["overdue_tickets"]),
        ("Unassigned tickets", tk["unassigned_tickets"]), ("Open tasks", ov["open_tasks"]),
        ("Hours logged", eff["total_hours"]), ("Ticket hours", eff["ticket_hours"]),
        ("Non-ticket hours", eff["non_ticket_hours"]), ("Ticket share %", eff["ticket_pct"]),
        ("Completed tasks with estimate", est["completed_with_estimate"]),
        ("Finished within estimate %", est["within_pct"]),
        ("Estimated hours (completed)", est["estimated_hours"]),
        ("Actual hours (completed)", est["actual_hours"]),
        ("SLA resolution compliance %", sla["resolution_compliance_pct"]),
        ("First response compliance %", sla["first_response_compliance_pct"]),
        ("Average resolution hours", sla["avg_resolution_hours"]),
        ("Overloaded team members", ", ".join(ov["overloaded"]) or "None"),
    ]
    for i, (k, v) in enumerate(lines, 4):
        ws.cell(i, 1, k).font = Font(bold=True)
        ws.cell(i, 2, v)
    ws.column_dimensions["A"].width = 36
    ws.column_dimensions["B"].width = 30

    _sheet(wb, "Workload", ["Team member", "Status", "Open tasks", "Ticket tasks", "Non-ticket tasks",
                            "Unresolved tickets", "Estimated h", "Remaining h", "Capacity h/week",
                            "Load %", "Logged this week", "Utilization %", "Overdue tasks", "No estimate"],
           [[w["name"], w["state"], w["open_tasks"], w["ticket_tasks"], w["non_ticket_tasks"],
             w["open_tickets"], w["estimated_hours"], w["remaining_hours"], w["capacity_hours"],
             w["load_pct"], w["logged_this_week"], w["utilization_pct"], w["overdue_tasks"],
             w["unestimated_tasks"]] for w in ov["workload"]])
    _sheet(wb, "Effort by person", ["Team member", "Ticket h", "Non-ticket h", "Total h"],
           [[u["name"], u["ticket"], u["non_ticket"], u["total"]] for u in eff["by_user"]])
    _sheet(wb, "Effort by category", ["Category", "Hours", "Share %"],
           [[c["category"].replace("_", " ").title(), c["hours"], c["percentage"]] for c in eff["by_category"]])
    _sheet(wb, "Estimate accuracy", ["Team member", "Completed tasks", "Within estimate", "Within %",
                                     "Estimated h", "Actual h"],
           [[u["name"], u["tasks"], u["within"], u["within_pct"], u["estimated"], u["actual"]]
            for u in est["by_user"]])
    _sheet(wb, "Overruns", ["Task", "Ticket", "Assignee", "Category", "Estimated h", "Actual h", "Variance h", "Variance %"],
           [[r["title"], r["ticket_id"], r["assignee"], r["category"], r["estimated"], r["actual"],
             r["variance"], r["variance_pct"]] for r in est["overruns"]])
    _sheet(wb, "Top tickets", ["Ticket", "Subject", "Hours", "Estimated h", "People", "Status", "Agent", "Dept", "RCA category"],
           [[t["ticket_id"], t["subject"], t["hours"], t["estimated"], t["people"], t["status"],
             t["agent"], t["department"], t["rca_category"]] for t in an.top_tickets(db, start, end, 50)])
    _sheet(wb, "Root causes", ["Category", "Tickets", "Recurring", "Hours"],
           [[c["category"], c["tickets"], c["recurring"], c["hours"]] for c in ov["rca"]["by_category"]])
    _sheet(wb, "Recurring issues", ["Ticket", "Subject", "Category", "Root cause", "Preventive action", "Hours"],
           [[r["ticket_id"], r["subject"], r["category"], r["root_cause"], r["preventive_action"], r["hours"]]
            for r in ov["rca"]["recurring"]])
    _sheet(wb, "SLA by agent", ["Agent", "Resolved", "Within SLA", "Compliance %"],
           [[r["label"], r["resolved"], r["within_sla"], r["compliance_pct"]] for r in sla["by_agent"]])
    _sheet(wb, "Overdue tickets", ["Ticket", "Subject", "Agent", "Priority", "Status", "Days overdue"],
           [[t["ticket_id"], t["subject"], t["agent"], t["priority"], t["status"], t["days_overdue"]]
            for t in sla["overdue"]])
    logs = (db.query(TimeLog).options(joinedload(TimeLog.task), joinedload(TimeLog.user))
            .filter(TimeLog.work_date >= start, TimeLog.work_date <= end)
            .order_by(TimeLog.work_date, TimeLog.user_id).all())
    _sheet(wb, "Activity log", ["Date", "Team member", "Task", "Category", "Ticket", "Hours", "Entry", "Note"],
           [[l.work_date.isoformat(), l.user.name, l.task.title, l.task.category, l.task.ticket_id,
             l.hours, l.source, l.note] for l in logs])
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()
