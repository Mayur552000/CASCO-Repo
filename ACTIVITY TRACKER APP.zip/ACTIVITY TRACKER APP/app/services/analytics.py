"""All reporting maths in one place, shared by the dashboard, reports,
Excel export and the AI assistant."""
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta

from sqlalchemy import func
from sqlalchemy.orm import Session, joinedload

from ..config import settings
from ..models import (OPEN_TASK_STATUSES, PRIORITY_LABELS, RESOLVED_CODES, Task, Ticket,
                      TicketRCA, TimeLog, User, utcnow)


def r1(x) -> float:
    return round(float(x or 0), 1)


def pct(part, whole) -> float:
    return round(100.0 * part / whole, 1) if whole else 0.0


def iso(dt):
    if dt is None:
        return None
    return dt.isoformat() + ("Z" if isinstance(dt, datetime) else "")


def week_start(d: date | None = None) -> date:
    d = d or date.today()
    return d - timedelta(days=d.weekday())


def default_range(start: date | None, end: date | None) -> tuple[date, date]:
    end = end or date.today()
    start = start or (end - timedelta(days=29))
    return start, end


def logged_by_task(db: Session) -> dict[int, float]:
    return {tid: float(h or 0) for tid, h in
            db.query(TimeLog.task_id, func.sum(TimeLog.hours)).group_by(TimeLog.task_id)}


# ---------------------------------------------------------------- tickets
def team(db: Session):
    """Current team members (not removed, active)."""
    return db.query(User).filter(User.is_active.is_(True), User.deleted_at.is_(None))


def ticket_query(db: Session, group=None, location=None, agent=None, priority=None,
                 type=None, status_filter=None, only_managed_agents=False, search=None, flag=None):
    q = db.query(Ticket)
    if group and group.lower() not in ("all", "overall"):
        q = q.filter(Ticket.department == group.upper())
    if location:
        q = q.filter(Ticket.location == location)
    if agent:
        q = q.filter(Ticket.agent_name.is_(None)) if agent == "Unassigned" \
            else q.filter(Ticket.agent_name == agent)
    if priority:
        q = q.filter(Ticket.priority == priority)
    if type:
        q = q.filter(Ticket.type == type)
    sf = (status_filter or "").lower()
    if sf == "unresolved":
        q = q.filter(Ticket.status.notin_(RESOLVED_CODES))
    elif sf == "open":
        q = q.filter(Ticket.status == 2)
    elif sf == "assigned":
        q = q.filter(Ticket.status == 11)
    elif sf == "in_progress":
        q = q.filter(Ticket.status.in_((9, 9000)))
    elif sf == "pending":
        q = q.filter(Ticket.status.in_((3, 10, 14, 15, 9001, 9002, 9003)))
    elif sf == "resolved":
        q = q.filter(Ticket.status == 4)
    elif sf == "closed":
        q = q.filter(Ticket.status == 5)
    if only_managed_agents:
        names = [u.freshdesk_agent_name or u.name for u in team(db)]
        q = q.filter(Ticket.agent_name.in_(names))
    now = utcnow()
    if flag:
        q = q.filter(Ticket.status.notin_(RESOLVED_CODES))
    if flag == "overdue":
        q = q.filter(Ticket.due_by < now)
    elif flag == "urgent":
        q = q.filter(Ticket.priority >= 3)
    elif flag == "over30":
        q = q.filter(Ticket.created_at < now - timedelta(days=30))
    elif flag == "stale14":
        q = q.filter(Ticket.updated_at <= now - timedelta(days=14))
    elif flag == "unassigned":
        q = q.filter(Ticket.agent_name.is_(None))
    elif flag == "untracked":
        names = [u.freshdesk_agent_name or u.name for u in team(db)]
        q = q.filter(Ticket.agent_name.isnot(None), Ticket.agent_name.notin_(names))
    if search:
        like = f"%{search}%"
        cond = Ticket.subject.ilike(like)
        if search.lstrip("#").isdigit():
            cond = cond | (Ticket.id == int(search.lstrip("#")))
        q = q.filter(cond)
    return q


def _breakdown(values) -> list[dict]:
    counts = Counter(v or "Unassigned" for v in values)
    total = sum(counts.values())
    return [{"label": k, "count": c, "percentage": pct(c, total)}
            for k, c in counts.most_common()]


def _group_counts(db: Session, filters: dict) -> dict:
    rest = {k: v for k, v in filters.items() if k != "group"}
    deps = Counter(t.department for t in ticket_query(db, **rest, status_filter="unresolved"))
    return {"overall": sum(deps.values()), "QAD": deps.get("QAD", 0), "EDI": deps.get("EDI", 0),
            "IT": deps.get("IT", 0)}


def dashboard_stats(db: Session, **filters) -> dict:
    all_tickets = ticket_query(db, **filters).all()
    open_ = [t for t in all_tickets if t.status not in RESOLVED_CODES]
    now = utcnow()
    in_team = {(u.freshdesk_agent_name or u.name) for u in team(db)}
    today_end = datetime.combine(now.date() + timedelta(days=1), datetime.min.time())
    return {
        "total_tickets": len(all_tickets),
        "open_tickets": sum(t.status == 2 for t in open_),
        "unresolved_tickets": len(open_),
        "assigned_tickets": sum(bool(t.agent_name) for t in open_),
        "unassigned_tickets": sum(not t.agent_name for t in open_),
        "overdue_tickets": sum(bool(t.due_by and t.due_by < now) for t in open_),
        "due_today_tickets": sum(bool(t.due_by and now <= t.due_by < today_end) for t in open_),
        "urgent_tickets": sum(t.priority == 4 for t in open_),
        "high_urgent_tickets": sum((t.priority or 0) >= 3 for t in open_),
        "locations": len({t.location for t in open_ if t.location}),
        "agents": len({t.agent_name for t in open_ if t.agent_name}),
        "over_30_days_tickets": sum(bool(t.created_at and (now - t.created_at).days > 30) for t in open_),
        "no_update_14d_tickets": sum(bool(t.updated_at and (now - t.updated_at).days >= 14) for t in open_),
        "overall_count": len(open_),
        "qad_count": sum(t.department == "QAD" for t in open_),
        "edi_count": sum(t.department == "EDI" for t in open_),
        "it_count": sum(t.department == "IT" for t in open_),
        "by_type": _breakdown(t.type or "Not set" for t in open_),
        "group_counts": _group_counts(db, filters),
        "by_status": _breakdown(t.status_label for t in open_),
        "by_location": _breakdown(t.location or "Not set" for t in open_),
        "by_agent": [{**r, "in_team": r["label"] == "Unassigned" or r["label"] in in_team}
                     for r in _breakdown(t.agent_name for t in open_)],
        "untracked_tickets": sum(bool(t.agent_name and t.agent_name not in in_team) for t in open_),
        "by_priority": _breakdown(PRIORITY_LABELS.get(t.priority, "Not set") for t in open_),
    }


def agent_summary(db: Session) -> list[dict]:
    rows = defaultdict(lambda: dict(open=0, in_progress=0, pending=0, resolved=0, unresolved=0))
    for t in db.query(Ticket):
        row = rows[t.agent_name or "Unassigned"]
        if t.status in RESOLVED_CODES:
            row["resolved"] += 1
            continue
        row["unresolved"] += 1
        if t.status in (2, 11):
            row["open"] += 1
        elif t.status in (9, 9000):
            row["in_progress"] += 1
        else:
            row["pending"] += 1
    return sorted(({"agent": k, **v} for k, v in rows.items()),
                  key=lambda r: -r["unresolved"])


# --------------------------------------------------------------- workload
def workload(db: Session) -> list[dict]:
    """Per person: what is assigned, what is left to do, and how full the week is."""
    ws = week_start()
    logged = logged_by_task(db)
    week_hours = dict(db.query(TimeLog.user_id, func.sum(TimeLog.hours))
                      .filter(TimeLog.work_date >= ws).group_by(TimeLog.user_id).all())
    done_week = Counter(a for (a,) in db.query(Task.assignee_id).filter(
        Task.status == "DONE", Task.standing.isnot(True),
        Task.completed_at >= datetime.combine(ws, datetime.min.time())))
    open_tasks = db.query(Task).filter(Task.status.in_(OPEN_TASK_STATUSES), Task.standing.isnot(True)).all()
    tickets = Counter(t.agent_name for t in
                      db.query(Ticket).filter(Ticket.status.notin_(RESOLVED_CODES)))
    out = []
    for u in team(db).order_by(User.name):
        mine = [t for t in open_tasks if t.assignee_id == u.id]
        if u.role == "ADMIN" and not mine and not week_hours.get(u.id):
            continue  # an administrator account that does no tracked work
        est = sum(t.estimated_hours for t in mine)
        remaining = sum(max(t.estimated_hours - logged.get(t.id, 0), 0) for t in mine)
        cap = u.weekly_capacity_hours or 40
        load = pct(remaining, cap)
        state = ("Overloaded" if load > settings.overload_threshold_pct
                 else "Balanced" if load >= 60 else "Available")
        out.append({
            "user_id": u.id, "name": u.name, "role": u.role, "capacity_hours": cap,
            "open_tasks": len(mine),
            "ticket_tasks": sum(t.category == "TICKET" for t in mine),
            "non_ticket_tasks": sum(t.category != "TICKET" for t in mine),
            "unestimated_tasks": sum(t.estimated_hours <= 0 for t in mine),
            "overdue_tasks": sum(bool(t.due_date and t.due_date < date.today()) for t in mine),
            "open_tickets": tickets.get(u.freshdesk_agent_name or u.name, 0),
            "estimated_hours": r1(est), "remaining_hours": r1(remaining),
            "logged_this_week": r1(week_hours.get(u.id)),
            "done_this_week": done_week.get(u.id, 0),
            "utilization_pct": pct(week_hours.get(u.id) or 0, cap),
            "load_pct": load, "state": state,
        })
    orphans = [t for t in open_tasks if t.assignee_id is None]
    out.sort(key=lambda r: -r["load_pct"])
    if orphans:
        out.append({"user_id": 0, "name": "Unassigned", "role": "", "capacity_hours": 0,
                    "open_tasks": len(orphans), "ticket_tasks": sum(t.category == "TICKET" for t in orphans),
                    "non_ticket_tasks": sum(t.category != "TICKET" for t in orphans),
                    "unestimated_tasks": sum(t.estimated_hours <= 0 for t in orphans),
                    "overdue_tasks": sum(bool(t.due_date and t.due_date < date.today()) for t in orphans),
                    "open_tickets": 0, "estimated_hours": r1(sum(t.estimated_hours for t in orphans)),
                    "remaining_hours": r1(sum(max(t.estimated_hours - logged.get(t.id, 0), 0) for t in orphans)),
                    "logged_this_week": 0, "done_this_week": 0, "utilization_pct": 0, "load_pct": 0, "state": "Unassigned"})
    return out


# ----------------------------------------------------------------- effort
def effort(db: Session, start: date, end: date, user_id: int | None = None) -> dict:
    q = (db.query(TimeLog).options(joinedload(TimeLog.task), joinedload(TimeLog.user))
         .filter(TimeLog.work_date >= start, TimeLog.work_date <= end))
    if user_id:
        q = q.filter(TimeLog.user_id == user_id)
    logs = q.all()
    by_cat, by_user, by_day = Counter(), defaultdict(lambda: [0.0, 0.0]), defaultdict(lambda: [0.0, 0.0])
    for l in logs:
        is_ticket = l.task.category == "TICKET" or l.task.ticket_id is not None
        by_cat[l.task.category] += l.hours
        by_user[l.user.name][0 if is_ticket else 1] += l.hours
        by_day[l.work_date][0 if is_ticket else 1] += l.hours
    ticket_h = sum(v[0] for v in by_user.values())
    other_h = sum(v[1] for v in by_user.values())
    total = ticket_h + other_h
    days = []
    d = start
    while d <= end:
        days.append({"date": d.isoformat(), "ticket": r1(by_day[d][0]), "non_ticket": r1(by_day[d][1])})
        d += timedelta(days=1)
    return {
        "start": start.isoformat(), "end": end.isoformat(),
        "total_hours": r1(total), "ticket_hours": r1(ticket_h), "non_ticket_hours": r1(other_h),
        "ticket_pct": pct(ticket_h, total), "non_ticket_pct": pct(other_h, total),
        "by_category": [{"category": c, "hours": r1(h), "percentage": pct(h, total)}
                        for c, h in by_cat.most_common()],
        "by_user": sorted(({"name": n, "ticket": r1(v[0]), "non_ticket": r1(v[1]),
                            "total": r1(v[0] + v[1])} for n, v in by_user.items()),
                          key=lambda r: -r["total"]),
        "by_day": days,
    }


def estimate_accuracy(db: Session, start: date, end: date) -> dict:
    """Completed tasks in the period: did they finish within their estimate?"""
    logged = logged_by_task(db)
    lo = datetime.combine(start, datetime.min.time())
    hi = datetime.combine(end + timedelta(days=1), datetime.min.time())
    done = (db.query(Task).options(joinedload(Task.assignee))
            .filter(Task.status == "DONE", Task.completed_at >= lo, Task.completed_at < hi).all())
    rows, per_user = [], defaultdict(lambda: dict(tasks=0, within=0, est=0.0, actual=0.0))
    for t in done:
        actual = logged.get(t.id, 0.0)
        if t.estimated_hours <= 0:
            continue
        within = actual <= t.estimated_hours + 1e-9
        name = t.assignee.name if t.assignee else "Unassigned"
        u = per_user[name]
        u["tasks"] += 1; u["within"] += within; u["est"] += t.estimated_hours; u["actual"] += actual
        rows.append({"task_id": t.id, "title": t.title, "category": t.category, "assignee": name,
                     "ticket_id": t.ticket_id, "estimated": r1(t.estimated_hours), "actual": r1(actual),
                     "variance": r1(actual - t.estimated_hours),
                     "variance_pct": pct(actual - t.estimated_hours, t.estimated_hours),
                     "within": within})
    running = []
    for t in (db.query(Task).options(joinedload(Task.assignee))
              .filter(Task.status.in_(OPEN_TASK_STATUSES), Task.estimated_hours > 0)):
        actual = logged.get(t.id, 0.0)
        if actual > t.estimated_hours:
            running.append({"task_id": t.id, "title": t.title, "ticket_id": t.ticket_id,
                            "assignee": t.assignee.name if t.assignee else "Unassigned",
                            "estimated": r1(t.estimated_hours), "actual": r1(actual),
                            "variance": r1(actual - t.estimated_hours)})
    est, act = sum(r["estimated"] for r in rows), sum(r["actual"] for r in rows)
    return {
        "completed_with_estimate": len(rows),
        "completed_without_estimate": len(done) - len(rows),
        "within_estimate": sum(r["within"] for r in rows),
        "within_pct": pct(sum(r["within"] for r in rows), len(rows)),
        "estimated_hours": r1(est), "actual_hours": r1(act), "variance_hours": r1(act - est),
        "by_user": sorted(({"name": n, "tasks": v["tasks"], "within": v["within"],
                            "within_pct": pct(v["within"], v["tasks"]),
                            "estimated": r1(v["est"]), "actual": r1(v["actual"])}
                           for n, v in per_user.items()), key=lambda r: r["name"]),
        "overruns": sorted([r for r in rows if not r["within"]], key=lambda r: -r["variance"])[:25],
        "open_over_estimate": sorted(running, key=lambda r: -r["variance"])[:25],
    }


def top_tickets(db: Session, start: date | None = None, end: date | None = None, limit: int = 15) -> list[dict]:
    q = (db.query(Task.ticket_id, func.sum(TimeLog.hours), func.count(func.distinct(TimeLog.user_id)))
         .join(TimeLog, TimeLog.task_id == Task.id).filter(Task.ticket_id.isnot(None)))
    if start:
        q = q.filter(TimeLog.work_date >= start)
    if end:
        q = q.filter(TimeLog.work_date <= end)
    rows = q.group_by(Task.ticket_id).order_by(func.sum(TimeLog.hours).desc()).limit(limit).all()
    est = dict(db.query(Task.ticket_id, func.sum(Task.estimated_hours))
               .filter(Task.ticket_id.isnot(None)).group_by(Task.ticket_id).all())
    out = []
    for tid, hours, people in rows:
        t = db.get(Ticket, tid)
        out.append({"ticket_id": tid, "subject": t.subject if t else "", "hours": r1(hours),
                    "estimated": r1(est.get(tid)), "people": people,
                    "status": t.status_label if t else None, "agent": t.agent_name if t else None,
                    "department": t.department if t else None,
                    "rca_category": t.rca.category if t and t.rca else None})
    return out


def rca_summary(db: Session) -> dict:
    rcas = db.query(TicketRCA).options(joinedload(TicketRCA.ticket)).all()
    hours = dict(db.query(Task.ticket_id, func.sum(TimeLog.hours))
                 .join(TimeLog, TimeLog.task_id == Task.id)
                 .filter(Task.ticket_id.isnot(None)).group_by(Task.ticket_id).all())
    cats = defaultdict(lambda: dict(tickets=0, recurring=0, hours=0.0))
    for r in rcas:
        c = cats[r.category or "Other"]
        c["tickets"] += 1; c["recurring"] += bool(r.is_recurring); c["hours"] += hours.get(r.ticket_id) or 0
    resolved = db.query(Ticket).filter(Ticket.status.in_(RESOLVED_CODES)).count()
    return {
        "tickets_with_rca": len(rcas), "resolved_tickets": resolved,
        "rca_coverage_pct": pct(len(rcas), resolved),
        "by_category": sorted(({"category": k, "tickets": v["tickets"], "recurring": v["recurring"],
                                "hours": r1(v["hours"])} for k, v in cats.items()),
                              key=lambda r: -r["tickets"]),
        "recurring": [{"ticket_id": r.ticket_id, "subject": r.ticket.subject, "category": r.category,
                       "root_cause": r.root_cause, "preventive_action": r.preventive_action,
                       "hours": r1(hours.get(r.ticket_id))}
                      for r in rcas if r.is_recurring][:40],
    }


def sla_summary(db: Session, start: date, end: date) -> dict:
    now = utcnow()
    lo = datetime.combine(start, datetime.min.time())
    hi = datetime.combine(end + timedelta(days=1), datetime.min.time())
    resolved = [t for t in db.query(Ticket).filter(Ticket.status.in_(RESOLVED_CODES))
                if (t.resolved_at or t.closed_at) and lo <= (t.resolved_at or t.closed_at) < hi]
    open_ = db.query(Ticket).filter(Ticket.status.notin_(RESOLVED_CODES)).all()

    def met(t):
        return bool(t.due_by) and (t.resolved_at or t.closed_at) <= t.due_by

    with_due = [t for t in resolved if t.due_by]
    fr = [t for t in resolved if t.fr_due_by and t.first_responded_at]
    res_hours = [((t.resolved_at or t.closed_at) - t.created_at).total_seconds() / 3600
                 for t in resolved if t.created_at]

    def group(key):
        g = defaultdict(lambda: [0, 0])
        for t in with_due:
            g[key(t) or "Unassigned"][0] += 1
            g[key(t) or "Unassigned"][1] += met(t)
        return sorted(({"label": k, "resolved": v[0], "within_sla": v[1],
                        "compliance_pct": pct(v[1], v[0])} for k, v in g.items()),
                      key=lambda r: -r["resolved"])

    overdue = sorted((t for t in open_ if t.due_by and t.due_by < now), key=lambda t: t.due_by)
    return {
        "start": start.isoformat(), "end": end.isoformat(),
        "resolved_tickets": len(resolved),
        "resolution_compliance_pct": pct(sum(met(t) for t in with_due), len(with_due)),
        "first_response_compliance_pct": pct(sum(t.first_responded_at <= t.fr_due_by for t in fr), len(fr)),
        "avg_resolution_hours": r1(sum(res_hours) / len(res_hours)) if res_hours else 0,
        "overdue_open_tickets": len(overdue),
        "by_department": group(lambda t: t.department),
        "by_agent": group(lambda t: t.agent_name),
        "by_priority": group(lambda t: PRIORITY_LABELS.get(t.priority)),
        "overdue": [{"ticket_id": t.id, "subject": t.subject, "agent": t.agent_name,
                     "priority": PRIORITY_LABELS.get(t.priority), "due_by": iso(t.due_by),
                     "days_overdue": (now - t.due_by).days, "status": t.status_label}
                    for t in overdue[:30]],
    }


def overview(db: Session, start: date, end: date) -> dict:
    """Everything a manager needs on one page."""
    wl = workload(db)
    eff = effort(db, start, end)
    acc = estimate_accuracy(db, start, end)
    sla = sla_summary(db, start, end)
    open_tasks = db.query(Task).filter(Task.status.in_(OPEN_TASK_STATUSES), Task.standing.isnot(True)).count()
    return {
        "tickets": dashboard_stats(db), "workload": wl, "effort": eff, "estimates": acc, "sla": sla,
        "top_tickets": top_tickets(db, start, end, 8), "rca": rca_summary(db),
        "completed_weeks": completed_by_week(db),
        "open_tasks": open_tasks,
        "overloaded": [w["name"] for w in wl if w["state"] == "Overloaded"],
        "needs_estimate": sum(w["unestimated_tasks"] for w in wl),
    }


def completed_by_week(db: Session, weeks: int = 8, user_id: int | None = None) -> list[dict]:
    """Tasks completed per week, split by how they finished against their estimate."""
    first = week_start() - timedelta(weeks=weeks - 1)
    q = (db.query(Task).filter(Task.status == "DONE", Task.standing.isnot(True),
                               Task.completed_at >= datetime.combine(first, datetime.min.time())))
    if user_id:
        q = q.filter(Task.assignee_id == user_id)
    logged = logged_by_task(db)
    buckets = {first + timedelta(weeks=i): {"within": 0, "over": 0, "no_estimate": 0} for i in range(weeks)}
    for t in q:
        wk = week_start(t.completed_at.date())
        if wk not in buckets:
            continue
        if t.estimated_hours <= 0:
            buckets[wk]["no_estimate"] += 1
        elif logged.get(t.id, 0) <= t.estimated_hours + 1e-9:
            buckets[wk]["within"] += 1
        else:
            buckets[wk]["over"] += 1
    return [{"week": wk.isoformat(), **v, "total": sum(v.values())} for wk, v in buckets.items()]


def contributors_by_task(db: Session) -> dict[int, list[dict]]:
    """Who logged hours on each task, most hours first."""
    rows = (db.query(TimeLog.task_id, User.id, User.name, func.sum(TimeLog.hours))
            .join(User, TimeLog.user_id == User.id)
            .group_by(TimeLog.task_id, User.id, User.name).all())
    out: dict[int, list[dict]] = {}
    for task_id, uid, name, hours in rows:
        out.setdefault(task_id, []).append({"user_id": uid, "name": name, "hours": r1(hours)})
    for people in out.values():
        people.sort(key=lambda p: -p["hours"])
    return out


def shared_work(db: Session, start: date, end: date, limit: int = 20) -> list[dict]:
    """Tasks more than one person worked on in the period."""
    rows = (db.query(TimeLog.task_id, User.name, func.sum(TimeLog.hours))
            .join(User, TimeLog.user_id == User.id)
            .filter(TimeLog.work_date >= start, TimeLog.work_date <= end)
            .group_by(TimeLog.task_id, User.name).all())
    per_task: dict[int, list[tuple[str, float]]] = {}
    for task_id, name, hours in rows:
        per_task.setdefault(task_id, []).append((name, float(hours or 0)))
    out = []
    for task_id, people in per_task.items():
        if len(people) < 2:
            continue
        task = db.get(Task, task_id)
        if not task:
            continue
        people.sort(key=lambda p: -p[1])
        out.append({"task_id": task_id, "title": task.title, "ticket_id": task.ticket_id,
                    "owner": task.assignee.name if task.assignee else "Unassigned",
                    "status": task.status, "hours": r1(sum(h for _, h in people)),
                    "people": [{"name": n, "hours": r1(h)} for n, h in people]})
    return sorted(out, key=lambda r: -r["hours"])[:limit]
