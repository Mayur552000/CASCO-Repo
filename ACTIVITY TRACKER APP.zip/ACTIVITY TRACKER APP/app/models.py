"""Database tables. Datetimes are stored as naive UTC."""
from datetime import datetime, timezone

from sqlalchemy import (Boolean, Column, Date, DateTime, Float, ForeignKey, Index,
                        Integer, BigInteger, String, Text)
from sqlalchemy.orm import relationship

from .database import Base

ROLES = ("ADMIN", "TEAM_LEAD", "MEMBER")
TASK_STATUSES = ("TODO", "IN_PROGRESS", "ON_HOLD", "DONE")
OPEN_TASK_STATUSES = ("TODO", "IN_PROGRESS", "ON_HOLD")
CATEGORIES = ("TICKET", "DEVELOPMENT", "ENHANCEMENT", "IMPLEMENTATION", "TESTING",
              "DOCUMENTATION", "MEETING", "INTERNAL_SUPPORT", "OTHER")
RCA_CATEGORIES = ("Program bug", "Data issue", "Configuration", "User error / training",
                  "Master data", "Interface / EDI", "Infrastructure", "Access / security",
                  "Process gap", "Enhancement request", "Other")

# Freshdesk status code -> (label, lifecycle state), from the API documentation
STATUS_MAP = {
    2: ("Open", "Unresolved"), 3: ("Pending", "On Hold"), 4: ("Resolved", "Resolved"),
    5: ("Closed", "Closed"), 9: ("In Progress", "Unresolved"), 10: ("Hold", "On Hold"),
    11: ("Assigned", "Unresolved"), 14: ("AB Approval Pending", "Approval Pending"),
    15: ("CAB Approval Pending", "Approval Pending"), 9000: ("Assigned to AI Agent", "In Progress"),
    9001: ("Wait Customer", "On Hold"), 9002: ("Wait User", "On Hold"),
    9003: ("Pending Review", "Review"),
}
RESOLVED_CODES = (4, 5)
UNRESOLVED_CODES = tuple(c for c in STATUS_MAP if c not in RESOLVED_CODES)
PRIORITY_LABELS = {1: "Low", 2: "Medium", 3: "High", 4: "Urgent"}


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    email = Column(String(200), nullable=False, unique=True)
    password_hash = Column(String(300), nullable=False)
    role = Column(String(20), nullable=False, default="MEMBER")
    freshdesk_agent_name = Column(String(120))
    weekly_capacity_hours = Column(Float, nullable=False, default=40)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, default=utcnow)
    freshdesk_agent_id = Column(BigInteger)
    must_change_password = Column(Boolean, default=False)
    deleted_at = Column(DateTime)          # removed people keep their history
    calendar_url = Column(Text)            # published Outlook calendar (ICS link)
    is_demo = Column(Boolean, default=False)


class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(BigInteger, primary_key=True, autoincrement=False)  # Freshdesk ticket id
    subject = Column(String(500))
    description_text = Column(Text)
    status = Column(Integer, index=True)
    status_label = Column(String(80))
    lifecycle = Column(String(40))
    priority = Column(Integer)
    type = Column(String(80))
    group_name = Column(String(120))
    department = Column(String(20), index=True)  # QAD / EDI / IT
    location = Column(String(120))
    agent_name = Column(String(120), index=True)
    responder_id = Column(BigInteger)
    requester = Column(String(200))
    tags = Column(Text)
    is_escalated = Column(Boolean, default=False)
    created_at = Column(DateTime, index=True)
    updated_at = Column(DateTime)
    due_by = Column(DateTime)
    fr_due_by = Column(DateTime)
    first_responded_at = Column(DateTime)
    resolved_at = Column(DateTime)
    closed_at = Column(DateTime)
    synced_at = Column(DateTime)
    conversations_synced_at = Column(DateTime)
    custom_fields = Column(Text)
    is_demo = Column(Boolean, default=False)

    conversations = relationship("Conversation", back_populates="ticket",
                                 cascade="all, delete-orphan", order_by="Conversation.created_at")
    rca = relationship("TicketRCA", back_populates="ticket", uselist=False,
                       cascade="all, delete-orphan")
    tasks = relationship("Task", back_populates="ticket")


class Conversation(Base):
    __tablename__ = "ticket_conversations"
    id = Column(BigInteger, primary_key=True, autoincrement=False)
    ticket_id = Column(BigInteger, ForeignKey("tickets.id"), index=True, nullable=False)
    author = Column(String(200))
    body_text = Column(Text)
    private = Column(Boolean, default=False)
    incoming = Column(Boolean, default=False)
    created_at = Column(DateTime)
    ticket = relationship("Ticket", back_populates="conversations")


class TicketRCA(Base):
    __tablename__ = "ticket_rca"
    ticket_id = Column(BigInteger, ForeignKey("tickets.id"), primary_key=True)
    category = Column(String(80), index=True)
    root_cause = Column(Text)
    resolution = Column(Text)
    preventive_action = Column(Text)
    is_recurring = Column(Boolean, default=False)
    updated_by = Column(String(120))
    updated_at = Column(DateTime, default=utcnow)
    ticket = relationship("Ticket", back_populates="rca")


class Task(Base):
    __tablename__ = "tasks"
    id = Column(Integer, primary_key=True)
    title = Column(String(300), nullable=False)
    description = Column(Text)
    category = Column(String(30), nullable=False, default="OTHER", index=True)
    ticket_id = Column(BigInteger, ForeignKey("tickets.id"), index=True)
    assignee_id = Column(Integer, ForeignKey("users.id"), index=True)
    estimated_hours = Column(Float, nullable=False, default=0)
    status = Column(String(20), nullable=False, default="TODO", index=True)
    priority = Column(Integer, nullable=False, default=2)
    start_date = Column(Date)
    due_date = Column(Date)
    completed_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=utcnow)
    auto_created = Column(Boolean, default=False)
    standing = Column(Boolean, default=False)   # ongoing bucket, e.g. each person's meetings

    ticket = relationship("Ticket", back_populates="tasks")
    assignee = relationship("User", foreign_keys=[assignee_id])
    logs = relationship("TimeLog", back_populates="task", cascade="all, delete-orphan")


class TimeLog(Base):
    __tablename__ = "time_logs"
    id = Column(Integer, primary_key=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=False)
    work_date = Column(Date, index=True, nullable=False)
    hours = Column(Float, nullable=False)
    note = Column(Text)
    source = Column(String(10), default="MANUAL")  # MANUAL / TIMER / CALENDAR
    external_ref = Column(String(300), index=True)  # calendar event occurrence, prevents double logging
    created_at = Column(DateTime, default=utcnow)
    task = relationship("Task", back_populates="logs")
    user = relationship("User")


class Timer(Base):
    __tablename__ = "timers"
    user_id = Column(Integer, ForeignKey("users.id"), primary_key=True)  # one running timer per person
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=False)
    started_at = Column(DateTime, nullable=False, default=utcnow)
    task = relationship("Task")


class SyncLog(Base):
    __tablename__ = "sync_logs"
    id = Column(Integer, primary_key=True)
    started_at = Column(DateTime, default=utcnow)
    completed_at = Column(DateTime)
    status = Column(String(20), default="RUNNING")
    trigger = Column(String(20), default="SCHEDULED")
    tickets_processed = Column(Integer, default=0)
    conversations_processed = Column(Integer, default=0)
    agents_imported = Column(Integer, default=0)
    error_summary = Column(Text)


class Setting(Base):
    __tablename__ = "settings"
    key = Column(String(80), primary_key=True)
    value = Column(Text)


Index("ix_timelog_user_date", TimeLog.user_id, TimeLog.work_date)


class TaskEvent(Base):
    """What happened to a task and who did it."""
    __tablename__ = "task_events"
    id = Column(Integer, primary_key=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    at = Column(DateTime, default=utcnow, index=True)
    kind = Column(String(20), nullable=False)   # CREATED STATUS ESTIMATE ASSIGNEE HOURS DUE
    detail = Column(Text)
    user = relationship("User")


class ChecklistItem(Base):
    """A step inside a task (sub-task)."""
    __tablename__ = "task_checklist"
    id = Column(Integer, primary_key=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), index=True, nullable=False)
    title = Column(String(300), nullable=False)
    done = Column(Boolean, default=False)
    position = Column(Integer, default=0)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=utcnow)
    done_at = Column(DateTime)
