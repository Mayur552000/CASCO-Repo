"""Team Activity Tracker — FastAPI application."""
import logging
import re
from contextlib import asynccontextmanager

from apscheduler.schedulers.background import BackgroundScheduler
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from .config import BASE_DIR, settings
from .database import Base, SessionLocal, engine, ensure_columns
from .routers import auth, reports, tasks, tickets
from .seed import ensure_admin, mark_legacy_demo, seed_demo
from .services.freshdesk import freshdesk

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
scheduler = BackgroundScheduler(timezone="UTC")


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(engine)
    ensure_columns()
    with SessionLocal() as db:
        ensure_admin(db)
        mark_legacy_demo(db)
        seed_demo(db)
    # The job is always scheduled; it does nothing until Freshdesk is connected
    # (from .env or from Settings in the app).
    scheduler.add_job(freshdesk.sync_tickets, "interval", id="freshdesk-sync",
                      minutes=max(settings.sync_interval_minutes, 5),
                      max_instances=1, coalesce=True)
    scheduler.add_job(freshdesk.sync_tickets, id="freshdesk-sync-startup")
    scheduler.start()
    yield
    if scheduler.running:
        scheduler.shutdown(wait=False)


app = FastAPI(title="Team Activity Tracker", version="1.0.0", lifespan=lifespan)
for r in (auth.router, tasks.router, tickets.router, reports.router):
    app.include_router(r, prefix="/api/v1")

STATIC = BASE_DIR / "static"
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/", include_in_schema=False)
def index():
    """Serve the page with file versions in the asset links, so browsers fetch new
    styles and scripts straight after an update instead of using cached copies."""
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    for rel in ("css/app.css", "js/app.js"):
        version = int((STATIC / rel).stat().st_mtime)
        html = re.sub(rf"/static/{re.escape(rel)}(\?v=[^\"']*)?", f"/static/{rel}?v={version}", html)
    return HTMLResponse(html, headers={"Cache-Control": "no-cache"})
