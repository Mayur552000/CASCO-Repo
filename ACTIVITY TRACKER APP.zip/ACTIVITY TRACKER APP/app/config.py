"""Application settings, read from environment variables / .env."""
import os
import secrets
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, "") or default)
    except ValueError:
        return default


def _jwt_secret() -> str:
    value = os.getenv("JWT_SECRET", "").strip()
    if value:
        return value
    path = DATA_DIR / ".secret"
    if not path.exists():
        path.write_text(secrets.token_urlsafe(48))
    return path.read_text().strip()


class Settings:
    freshdesk_base_url = os.getenv("FRESHDESK_BASE_URL", "").strip().rstrip("/")
    freshdesk_api_key = os.getenv("FRESHDESK_API_KEY", "").strip()
    sync_interval_minutes = _int("SYNC_INTERVAL_MINUTES", 30)
    location_field = os.getenv("FRESHDESK_LOCATION_FIELD", "cf_location").strip()
    conversation_sync_limit = _int("CONVERSATION_SYNC_LIMIT", 40)
    auto_create_ticket_tasks = _bool("AUTO_CREATE_TICKET_TASKS", True)

    database_url = os.getenv("DATABASE_URL", "").strip() or "sqlite:///./data/tracker.db"
    seed_demo_data = _bool("SEED_DEMO_DATA", False)

    admin_email = os.getenv("ADMIN_EMAIL", "admin@casco.local").strip().lower()
    admin_password = os.getenv("ADMIN_PASSWORD", "ChangeMe!123")
    new_member_password = os.getenv("NEW_MEMBER_PASSWORD", "Welcome!123")

    overload_threshold_pct = _int("OVERLOAD_THRESHOLD_PCT", 100)

    ai_provider = os.getenv("AI_PROVIDER", "none").strip().lower()
    ai_api_key = os.getenv("AI_API_KEY", "").strip()
    ai_model = os.getenv("AI_MODEL", "").strip()
    openai_base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").strip().rstrip("/")

    jwt_secret = _jwt_secret()
    token_hours = _int("TOKEN_HOURS", 12)


settings = Settings()
