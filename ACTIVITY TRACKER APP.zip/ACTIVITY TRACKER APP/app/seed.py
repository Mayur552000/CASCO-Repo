"""First-run setup: the administrator account and (optionally) sample data."""
import random
from datetime import date, datetime, timedelta

from sqlalchemy.orm import Session

from .config import settings
from .models import (STATUS_MAP, Conversation, Task, Ticket, TicketRCA, TimeLog, Timer, User, utcnow)
from .security import hash_password

DEMO_PASSWORD = "Demo!1234"
PEOPLE = [("Priya Nair", "TEAM_LEAD"), ("Arjun Mehta", "MEMBER"), ("Sara Koch", "MEMBER"),
          ("Daniel Weber", "MEMBER"), ("Lakshmi Rao", "MEMBER"), ("Tomas Novak", "MEMBER")]
SUBJECTS = [
    ("Shipper confirmation fails with location error", "QAD Support", "Incident", "Program bug"),
    ("Picklist prints wrong box quantity for partial packs", "QAD Support", "Incident", "Program bug"),
    ("Intercompany PO price differs from price list", "QAD Support", "Incident", "Master data"),
    ("Supplier schedule release not sent to supplier", "EDI", "Incident", "Interface / EDI"),
    ("EDI 856 ASN rejected by customer portal", "EDI", "Incident", "Interface / EDI"),
    ("DESADV missing packaging segment", "EDI", "Incident", "Configuration"),
    ("New user needs warehouse scanning role", "IT Service Desk", "Service Request", "Access / security"),
    ("Label printer offline in shipping area", "IT Service Desk", "Incident", "Infrastructure"),
    ("Inventory mismatch after cycle count", "QAD Support", "Incident", "Data issue"),
    ("Add packaging weight field to item master report", "QAD Support", "Service Request", "Enhancement request"),
    ("Work order backflush posts to wrong site", "QAD Support", "Incident", "Configuration"),
    ("Scanner session freezes on container move", "QAD Support", "Incident", "Program bug"),
    ("Invoice print misses tax line for intercompany", "QAD Support", "Incident", "Program bug"),
    ("EDI 830 forecast buckets shifted by one week", "EDI", "Incident", "Interface / EDI"),
    ("User cannot post receipts after role change", "IT Service Desk", "Incident", "User error / training"),
    ("VPN drops for plant users every morning", "IT Service Desk", "Incident", "Infrastructure"),
    ("Request: monthly open PO report by buyer", "QAD Support", "Service Request", "Enhancement request"),
    ("Duplicate shipper numbers generated", "QAD Support", "Incident", "Process gap"),
]
LOCATIONS = ["CAS-GLOBAL", "Plant DE01", "Plant CZ02", "Plant MX03", "Plant TN04", "Plant IN05"]
PROJECTS = [
    ("EU packaging compliance report", "DEVELOPMENT", 40), ("Shipping location validation rollout", "IMPLEMENTATION", 24),
    ("Regression test pack for QAD patch", "TESTING", 16), ("Weekly CAB meeting", "MEETING", 4),
    ("Team stand-ups", "MEETING", 5), ("Runbook: intercompany supply chain jobs", "DOCUMENTATION", 12),
    ("Picklist layout enhancement", "ENHANCEMENT", 20), ("Month-end close support", "INTERNAL_SUPPORT", 10),
    ("Scanner program refactor", "DEVELOPMENT", 32), ("Onboarding new analyst", "INTERNAL_SUPPORT", 8),
    ("EDI partner onboarding: new customer", "IMPLEMENTATION", 30), ("User acceptance testing for label change", "TESTING", 12),
]
CAUSES = {
    "Program bug": ("Validation logic did not handle the partial-quantity case", "Corrected the condition and released a patch", "Add the scenario to the regression test pack"),
    "Master data": ("Price list record had an outdated effective date", "Corrected the price list and re-costed the receipt", "Monthly price list audit by purchasing"),
    "Interface / EDI": ("Partner mapping changed without notice", "Updated the map and resent the documents", "Agree a change notification process with the partner"),
    "Configuration": ("Site control setting pointed at the wrong default", "Corrected the control file setting", "Review control settings after each go-live"),
    "Access / security": ("Role was missing the menu permission", "Granted the role through the approval workflow", "Keep the role matrix current"),
    "Infrastructure": ("Network switch port flapping in the shipping area", "Replaced the patch cable and port", "Add the device to monitoring"),
    "Data issue": ("Transactions posted during the count freeze", "Adjusted inventory after recount", "Block transactions during the count window"),
    "Enhancement request": ("Standard report lacks the required field", "Delivered a custom report", "Collect similar requests into one release"),
    "User error / training": ("User followed the old procedure after the role change", "Walked the user through the new steps", "Update the work instruction"),
    "Process gap": ("Two sessions generated numbers at the same time", "Added a lock on the number sequence", "Review other sequences for the same gap"),
}


def mark_legacy_demo(db: Session) -> None:
    """Databases created by the first version did not flag the sample people."""
    emails = [n.lower().replace(" ", ".") + "@casco.local" for n, _ in PEOPLE]
    if db.query(Ticket).filter(Ticket.is_demo.is_(True)).count():
        db.query(User).filter(User.email.in_(emails), User.is_demo.isnot(True)).update(
            {User.is_demo: True}, synchronize_session=False)
        db.commit()


def ensure_admin(db: Session) -> None:
    if db.query(User).count() == 0:
        db.add(User(name="Administrator", email=settings.admin_email, role="ADMIN",
                    password_hash=hash_password(settings.admin_password)))
        db.commit()


def seed_demo(db: Session) -> None:
    if not settings.seed_demo_data or db.query(Ticket).count() or db.query(Task).count():
        return
    rnd = random.Random(7)
    now = utcnow()
    today = date.today()
    users = []
    pw = hash_password(DEMO_PASSWORD)
    for name, role in PEOPLE:
        u = User(name=name, email=name.lower().replace(" ", ".") + "@casco.local", role=role,
                 password_hash=pw, freshdesk_agent_name=name, weekly_capacity_hours=40, is_demo=True)
        db.add(u)
        users.append(u)
    db.flush()
    lead = users[0]
    # Skew assignment so the demo shows an overloaded and an available person
    weights = [1, 5, 3, 3, 2, 1]

    conv_id = 900000
    for i in range(70):
        subject, group, typ, cause = SUBJECTS[i % len(SUBJECTS)]
        created = now - timedelta(days=rnd.randint(0, 55), hours=rnd.randint(0, 23))
        resolved = i % 5 not in (0, 3) and (now - created).days > 2
        status = rnd.choice((4, 5)) if resolved else rnd.choice((2, 9, 9, 11, 3, 9002, 9003, 15))
        priority = rnd.choices((1, 2, 3, 4), weights=(2, 5, 3, 1))[0]
        sla_days = {1: 10, 2: 6, 3: 3, 4: 1}[priority]
        agent = rnd.choices(users, weights=weights)[0] if rnd.random() > 0.08 else None
        dept = "QAD" if "QAD" in group else "EDI" if "EDI" in group else "IT"
        t = Ticket(id=43000 + i * 13, subject=f"{subject} ({LOCATIONS[i % 6]})",
                   description_text=f"Reported by the plant: {subject.lower()}. Business impact: "
                                    f"{'shipments delayed' if priority >= 3 else 'workaround in place'}.",
                   status=status, status_label=STATUS_MAP[status][0], lifecycle=STATUS_MAP[status][1],
                   priority=priority, type=typ, group_name=group, department=dept,
                   location=LOCATIONS[i % 6], agent_name=agent.name if agent else None,
                   requester="plant.user@casco.example", created_at=created,
                   updated_at=min(now, created + timedelta(days=rnd.randint(0, 20))),
                   due_by=created + timedelta(days=sla_days),
                   fr_due_by=created + timedelta(hours=8),
                   first_responded_at=created + timedelta(hours=rnd.choice((1, 2, 3, 5, 7, 12))),
                   synced_at=now, is_demo=True)
        if resolved:
            t.resolved_at = min(now, created + timedelta(days=rnd.uniform(0.3, sla_days * 1.6)))
            t.closed_at = t.resolved_at if status == 5 else None
            t.updated_at = t.resolved_at
        db.add(t)
        for n in range(rnd.randint(1, 4)):
            conv_id += 1
            incoming = n % 2 == 1
            db.add(Conversation(
                id=conv_id, ticket_id=t.id, incoming=incoming, private=(not incoming and n == 2),
                author="Requester" if incoming else (agent.name if agent else "Service Desk"),
                body_text=("Still happening on the second shift, please prioritise." if incoming else
                           f"Investigated: {CAUSES[cause][0].lower()}. Next step: {CAUSES[cause][1].lower()}."),
                created_at=created + timedelta(hours=4 + 9 * n)))
        if resolved and rnd.random() < 0.7:
            c = CAUSES[cause]
            db.add(TicketRCA(ticket_id=t.id, category=cause, root_cause=c[0], resolution=c[1],
                             preventive_action=c[2], is_recurring=cause in ("Program bug", "Interface / EDI", "Master data") and rnd.random() < 0.6,
                             updated_by=agent.name if agent else lead.name, updated_at=t.resolved_at))
        if agent:
            est = rnd.choice((0, 2, 3, 4, 6, 8, 12, 16))
            task = Task(title=f"#{t.id} {t.subject}"[:300], category="TICKET", ticket_id=t.id,
                        assignee_id=agent.id, estimated_hours=est, priority=priority,
                        status="DONE" if resolved else rnd.choice(("TODO", "IN_PROGRESS", "IN_PROGRESS")),
                        start_date=created.date(), due_date=t.due_by.date(),
                        completed_at=t.resolved_at, created_by=lead.id, auto_created=True,
                        created_at=created)
            db.add(task)
            db.flush()
            target = (est or 3) * rnd.choice((0.6, 0.8, 0.9, 1.0, 1.1, 1.4, 1.9)) \
                if resolved else (est or 3) * rnd.uniform(0.0, 0.8)
            _log_hours(db, rnd, task, agent, created.date(),
                       (t.resolved_at or now).date(), target)

    for i, (title, cat, est) in enumerate(PROJECTS):
        owner = rnd.choices(users, weights=weights)[0]
        start = today - timedelta(days=rnd.randint(5, 35))
        done = i % 4 == 3
        task = Task(title=title, category=cat, assignee_id=owner.id, estimated_hours=est,
                    status="DONE" if done else "IN_PROGRESS", priority=rnd.choice((2, 2, 3)),
                    start_date=start, due_date=start + timedelta(days=rnd.randint(10, 40)),
                    completed_at=datetime.combine(today - timedelta(days=2), datetime.min.time()) if done else None,
                    created_by=lead.id, created_at=datetime.combine(start, datetime.min.time()))
        db.add(task)
        db.flush()
        _log_hours(db, rnd, task, owner, start, today,
                   est * (rnd.choice((0.9, 1.25)) if done else rnd.uniform(0.2, 0.7)))
    db.commit()


def _log_hours(db, rnd, task, user, start: date, end: date, total: float) -> None:
    days = [start + timedelta(days=n) for n in range((end - start).days + 1)]
    days = [d for d in days if d.weekday() < 5] or [end]
    left = round(total * 2) / 2
    while left > 0:
        h = min(left, rnd.choice((0.5, 1, 1.5, 2, 3, 4)))
        db.add(TimeLog(task_id=task.id, user_id=user.id, work_date=rnd.choice(days), hours=h,
                       note=rnd.choice(("Analysis", "Fix and unit test", "Call with plant user",
                                        "Testing in QA", "Documentation", "Deployment")),
                       source=rnd.choice(("MANUAL", "MANUAL", "TIMER"))))
        left -= h


def clear_demo(db: Session) -> int:
    """Remove the sample tickets, people and everything attached to them."""
    demo_users = [u.id for u in db.query(User).filter(User.is_demo.is_(True))]
    demo_tickets = [t.id for t in db.query(Ticket.id).filter(Ticket.is_demo.is_(True))]
    tasks = [t for t in db.query(Task) if t.ticket_id in set(demo_tickets) or t.assignee_id in set(demo_users)]
    task_ids = [t.id for t in tasks]
    if task_ids:
        db.query(Timer).filter(Timer.task_id.in_(task_ids)).delete(synchronize_session=False)
        db.query(TimeLog).filter(TimeLog.task_id.in_(task_ids)).delete(synchronize_session=False)
        db.query(Task).filter(Task.id.in_(task_ids)).delete(synchronize_session=False)
    if demo_users:
        db.query(Timer).filter(Timer.user_id.in_(demo_users)).delete(synchronize_session=False)
        db.query(TimeLog).filter(TimeLog.user_id.in_(demo_users)).delete(synchronize_session=False)
        db.query(User).filter(User.id.in_(demo_users)).delete(synchronize_session=False)
    if demo_tickets:
        db.query(Conversation).filter(Conversation.ticket_id.in_(demo_tickets)).delete(synchronize_session=False)
        db.query(TicketRCA).filter(TicketRCA.ticket_id.in_(demo_tickets)).delete(synchronize_session=False)
        db.query(Ticket).filter(Ticket.id.in_(demo_tickets)).delete(synchronize_session=False)
    db.commit()
    return len(demo_tickets) + len(demo_users)
