/* Team Activity Tracker — single-page UI (no build step) */
(() => {
'use strict';

// ------------------------------------------------------------------ helpers
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* private mode */ } },
  del(k) { try { localStorage.removeItem(k); } catch { /* private mode */ } },
};
let token = store.get('tat_token');

// ------------------------------------------------------------------- theme
const THEME_ICON = {
  light: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><circle cx="10" cy="10" r="3.6"/><path d="M9.2 1.5h1.6v2.6H9.2zM9.2 15.9h1.6v2.6H9.2zM1.5 9.2h2.6v1.6H1.5zM15.9 9.2h2.6v1.6h-2.6zM3.5 4.6l1.1-1.1 1.9 1.9-1.1 1.1zM13.5 14.6l1.1-1.1 1.9 1.9-1.1 1.1zM3.5 15.4l1.9-1.9 1.1 1.1-1.9 1.9zM13.5 5.4l1.9-1.9 1.1 1.1-1.9 1.9z"/></svg>',
  dark: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M16.8 12.6A7 7 0 017.4 3.2a7 7 0 109.4 9.4z"/></svg>',
  auto: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M2 3h16v11H2zm1.6 1.6v7.8h12.8V4.6zM7 15.5h6V17H7z"/><path d="M10 5.6v5.8a2.9 2.9 0 000-5.8z"/></svg>',
};
const THEMES = [['light', 'Light', ''], ['dark', 'Dark', ''], ['auto', 'Match Windows', 'Follows your Windows light or dark setting']];
const getTheme = () => { const t = store.get('tat_theme'); return t === 'light' || t === 'dark' ? t : 'auto'; };
function setTheme(t) {
  if (t === 'auto') { store.del('tat_theme'); delete document.documentElement.dataset.theme; }
  else { store.set('tat_theme', t); document.documentElement.dataset.theme = t; }
  document.querySelectorAll('.theme').forEach(el => { el.outerHTML = themeControl(); });
}
const themeControl = () => {
  const cur = getTheme(), name = THEMES.find(x => x[0] === cur)[1];
  return `<div class="theme"><button class="btn sm" data-act="theme-open" aria-haspopup="menu" aria-expanded="false" title="Appearance: ${name}" aria-label="Appearance: ${name}">${THEME_ICON[cur]}</button>
    <div class="theme-menu" role="menu" hidden>${THEMES.map(([k, t, sub]) => `<button role="menuitemradio" aria-checked="${k === cur}" data-act="theme-set" data-v="${k}">${THEME_ICON[k]}<span>${t}${sub ? `<small>${sub}</small>` : ''}</span></button>`).join('')}</div></div>`;
};
document.addEventListener('click', e => {
  const open = document.querySelector('.theme-menu:not([hidden])');
  if (open && !e.target.closest('.theme')) { open.hidden = true; open.previousElementSibling.setAttribute('aria-expanded', 'false'); }
});
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  const open = document.querySelector('.theme-menu:not([hidden])');
  if (open) { open.hidden = true; const b = open.previousElementSibling; b.setAttribute('aria-expanded', 'false'); b.focus(); }
});
let me = null, meta = null, users = [], timer = null;

async function api(path, opts = {}) {
  const res = await fetch('/api/v1' + path, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (res.status === 401 && path !== '/auth/login') { signOut(); throw new Error('Session expired. Sign in again'); }
  if (!res.ok) {
    let msg = 'Request failed (' + res.status + ')';
    try { const d = (await res.json()).detail; msg = typeof d === 'string' ? d : 'Check the values you entered'; } catch { /* keep default */ }
    throw new Error(msg);
  }
  return opts.blob ? res.blob() : res.json();
}
const qs = o => { const p = new URLSearchParams(); for (const [k, v] of Object.entries(o)) if (v !== '' && v != null && v !== false) p.set(k, v); const s = p.toString(); return s ? '?' + s : ''; };

const pad = n => String(n).padStart(2, '0');
const localISO = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const today = () => localISO(new Date());
const daysAgo = n => { const d = new Date(); d.setDate(d.getDate() - n); return localISO(d); };
const weekStart = () => { const d = new Date(); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d; };
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const fmtDate = iso => { if (!iso) return '—'; const d = iso.length === 10 ? new Date(iso + 'T00:00:00') : new Date(iso); return `${d.getDate()} ${MONTHS[d.getMonth()]}`; };
const fmtDT = iso => { if (!iso) return '—'; const d = new Date(iso); return `${d.getDate()} ${MONTHS[d.getMonth()]} ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const num = n => (Math.round((n || 0) * 100) / 100).toLocaleString('en-GB');
const hrs = n => num(n) + ' h';
const label = s => { const t = String(s || '').replace(/_/g, ' ').toLowerCase(); return t.charAt(0).toUpperCase() + t.slice(1); };
const TASK_CHIP = { TODO: ['', 'To do'], IN_PROGRESS: ['info', 'In progress'], ON_HOLD: ['warning', 'On hold'], DONE: ['good', 'Done'] };
const PRIO = { 1: ['', 'Low'], 2: ['info', 'Medium'], 3: ['serious', 'High'], 4: ['critical', 'Urgent'] };
const chip = (cls, text) => `<span class="chip ${cls}"><i></i>${esc(text)}</span>`;
const taskChip = s => chip(...(TASK_CHIP[s] || ['', s]));
const prioChip = p => chip(...(PRIO[p] || ['', 'Not set']));
const AV = ['#2a78d6', '#6250d6', '#1b8f66', '#b8572a', '#b0457a', '#4b6584', '#8a6d1f', '#3d7d8c'];
const initials = n => String(n || '?').trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();
const avatar = (n, cls = '') => { let h = 0; for (const c of String(n || '')) h = (h * 31 + c.charCodeAt(0)) >>> 0; return `<span class="av ${cls}" style="background:${n ? AV[h % AV.length] : 'var(--text-3)'}" aria-hidden="true">${esc(n ? initials(n) : '–')}</span>`; };
const person = n => `<span class="person">${avatar(n)}<span>${esc(n || 'Unassigned')}</span></span>`;
const ICO = {
  check: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M10 1.5a8.5 8.5 0 110 17 8.5 8.5 0 010-17zm3.6 5.3L8.9 11.5 6.6 9.2l-1.2 1.2 3.5 3.5 5.9-5.9z"/></svg>',
  cal: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M6 1.5h1.6V3h4.8V1.5H14V3h3v14.5H3V3h3zM4.6 7.5v8.4h10.8V7.5z"/></svg>',
  timer: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M8 1h4v1.6H8zM10 4a7 7 0 110 14 7 7 0 010-14zm-.8 3v4.3l3.3 2 .8-1.3-2.5-1.5V7z"/></svg>',
  lock: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M6 8V6a4 4 0 118 0v2h1.5v10h-11V8zm1.6 0h4.8V6a2.4 2.4 0 10-4.8 0z"/></svg>',
};
const tid = id => 'T' + String(id).padStart(3, '0');
function dueCell(t) {
  if (!t.due_date) return '<span class="muted">—</span>';
  const days = Math.round((new Date(t.due_date + 'T00:00:00') - new Date(today() + 'T00:00:00')) / 864e5);
  if (t.status === 'DONE') return `<span class="muted">${fmtDate(t.due_date)}</span>`;
  if (days < 0) return `<span class="late" title="${fmtDate(t.due_date)}">${-days}d overdue</span>`;
  if (days === 0) return '<span class="soon">Due today</span>';
  return `<span title="${fmtDate(t.due_date)}">${days <= 14 ? 'in ' + days + 'd' : fmtDate(t.due_date)}</span>`;
}
const isLead = () => me && (me.role === 'ADMIN' || me.role === 'TEAM_LEAD');
const opt = (v, t, sel) => `<option value="${esc(v)}"${String(v) === String(sel ?? '') ? ' selected' : ''}>${esc(t)}</option>`;

function toast(msg, action) {
  const el = $('#toast');
  el.innerHTML = `<span>${esc(msg)}</span>` + (action ? `<button type="button" class="toast-btn">${esc(action.label)}</button>` : '');
  if (action) $('.toast-btn', el).onclick = async () => { el.style.display = 'none'; try { await action.run(); } catch (e) { toast(e.message); } };
  el.style.display = 'flex';
  clearTimeout(toast.t); toast.t = setTimeout(() => { el.style.display = 'none'; }, action ? 8000 : 3200);
}

// hover tooltip for chart marks
document.addEventListener('mousemove', e => {
  const tip = $('#tip'), target = e.target.closest ? e.target.closest('[data-tip]') : null;
  if (!target) { tip.style.display = 'none'; return; }
  tip.textContent = target.dataset.tip; tip.style.display = 'block';
  const w = tip.offsetWidth, x = Math.min(e.clientX + 14, window.innerWidth - w - 8);
  tip.style.left = x + 'px'; tip.style.top = (e.clientY + 16) + 'px';
});

// ------------------------------------------------------------------- charts
function hbars(items, { unit = '', click } = {}) {
  if (!items.length) return '<div class="empty">Nothing to show for this period.</div>';
  const max = Math.max(...items.map(i => i.value), 0.0001);
  return items.map(i => `<div class="hbar"${i.act ? ` data-act="${i.act}" data-id="${esc(i.id)}" style="cursor:pointer"` : ''} data-tip="${esc(i.tip || `${i.label}: ${num(i.value)}${unit}`)}">
    <div class="lab">${esc(i.label)}</div><div><div class="bar" style="width:${(100 * i.value / max).toFixed(1)}%"></div></div>
    <div class="v">${num(i.value)}${unit}</div></div>`).join('');
}
function rails(rows) {
  if (!rows.length) return '<div class="empty">Add team members to see workload.</div>';
  const max = Math.max(150, ...rows.map(r => r.load_pct)) * 1.04;
  return rows.map(r => {
    const cls = r.state === 'Overloaded' ? 'critical' : r.state === 'Balanced' ? 'info' : 'good';
    return `<div class="rail-row" data-tip="${esc(`${r.name}\n${num(r.remaining_hours)} h of estimated work left\n${num(r.capacity_hours)} h weekly capacity (${num(r.load_pct)}%)\n${r.open_tasks} open tasks, ${r.unestimated_tasks} without an estimate`)}">
      <div class="name">${esc(r.name)}<small>${r.open_tasks} open tasks, ${r.open_tickets} tickets</small></div>
      <div class="rail"><div class="fill ${r.state === 'Overloaded' ? 'over' : ''}" style="width:${Math.min(100, 100 * r.load_pct / max).toFixed(1)}%"></div><div class="cap" style="left:${(10000 / max).toFixed(1)}%"></div></div>
      <div class="val"><span>${num(r.remaining_hours)} h of ${num(r.capacity_hours)} h</span>${chip(cls, r.state)}</div></div>`;
  }).join('') + `<div class="rail-legend"><span><b></b>Weekly capacity</span><span>Bar: estimated hours still to do on open tasks</span></div>`;
}
function splitBar(e) {
  if (!e.total_hours) return '<div class="empty">No hours logged in this period.</div>';
  return `<div class="split"><div class="a" style="flex:${e.ticket_hours}" data-tip="Ticket work: ${hrs(e.ticket_hours)} (${e.ticket_pct}%)"></div><div class="b" style="flex:${e.non_ticket_hours}" data-tip="Non-ticket work: ${hrs(e.non_ticket_hours)} (${e.non_ticket_pct}%)"></div></div>
  <div class="legend"><span><i style="background:var(--series-1)"></i>Ticket work <b>${hrs(e.ticket_hours)}</b> (${e.ticket_pct}%)</span><span><i style="background:var(--series-2)"></i>Non-ticket work <b>${hrs(e.non_ticket_hours)}</b> (${e.non_ticket_pct}%)</span></div>`;
}
function dayColumns(days) {
  const max = Math.max(...days.map(d => d.ticket + d.non_ticket), 1);
  const cols = days.map(d => {
    const a = 100 * d.ticket / max, b = 100 * d.non_ticket / max;
    return `<div class="col" data-tip="${esc(`${fmtDate(d.date)}\nTicket work: ${hrs(d.ticket)}\nNon-ticket work: ${hrs(d.non_ticket)}`)}">
      ${d.ticket ? `<div class="seg a ${d.non_ticket ? '' : 'top'}" style="height:${a.toFixed(1)}%"></div>` : ''}
      ${d.non_ticket ? `<div class="seg b top" style="height:${b.toFixed(1)}%"></div>` : ''}</div>`;
  }).join('');
  return `<div class="cols"><span class="ymax">${num(max)} h</span>${cols}</div>
    <div class="axis"><span>${fmtDate(days[0].date)}</span><span>Hours logged per day</span><span>${fmtDate(days[days.length - 1].date)}</span></div>`;
}
function stackRows(rows) {
  if (!rows.length) return '<div class="empty">No hours logged in this period.</div>';
  const max = Math.max(...rows.map(r => r.total), 0.0001);
  return rows.map(r => `<div class="hbar" data-tip="${esc(`${r.name}\nTicket work: ${hrs(r.ticket)}\nNon-ticket work: ${hrs(r.non_ticket)}`)}"><div class="lab">${esc(r.name)}</div>
    <div><div class="stackbar" style="width:${(100 * r.total / max).toFixed(1)}%">${r.ticket ? `<div class="a" style="flex:${r.ticket}"></div>` : ''}${r.non_ticket ? `<div class="b" style="flex:${r.non_ticket}"></div>` : ''}</div></div>
    <div class="v">${hrs(r.total)}</div></div>`).join('')
    + `<div class="legend" style="margin-top:8px"><span><i style="background:var(--series-1)"></i>Ticket work</span><span><i style="background:var(--series-2)"></i>Non-ticket work</span></div>`;
}
function pairRows(rows) {
  if (!rows.length) return '<div class="empty">No completed tasks with an estimate in this period.</div>';
  const max = Math.max(...rows.map(r => Math.max(r.estimated, r.actual)), 0.0001);
  return rows.map(r => `<div class="pair" data-tip="${esc(`${r.name}\nEstimated: ${hrs(r.estimated)}\nActual: ${hrs(r.actual)}\n${r.within} of ${r.tasks} tasks within estimate`)}"><div>${esc(r.name)}</div>
    <div class="bars"><div class="est" style="width:${(100 * r.estimated / max).toFixed(1)}%"></div><div class="act ${r.actual > r.estimated ? 'over' : ''}" style="width:${(100 * r.actual / max).toFixed(1)}%"></div></div>
    <div class="v">${num(r.actual)} / ${num(r.estimated)} h<br>${r.within_pct}% within</div></div>`).join('')
    + `<div class="legend" style="margin-top:8px"><span><i style="background:var(--text-3)"></i>Estimated</span><span><i style="background:var(--series-1)"></i>Actual</span><span><i style="background:var(--critical)"></i>Actual, over estimate</span></div>`;
}
const table = (heads, rows, empty = 'Nothing to show.') => rows.length
  ? `<div class="table-wrap"><table><thead><tr>${heads.map(h => `<th${h.startsWith('#') ? ' class="num"' : ''}>${esc(h.replace(/^#/, ''))}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`
  : `<div class="empty">${esc(empty)}</div>`;
const card = (title, sub, body, extra = '') => `<section class="card"><header><div><h2>${esc(title)}</h2>${sub ? `<p>${esc(sub)}</p>` : ''}</div>${extra}</header>${body}</section>`;
const rangeSelect = v => `<select data-change="range" aria-label="Period">${[[7, 'Last 7 days'], [30, 'Last 30 days'], [90, 'Last 90 days']].map(([d, t]) => opt(d, t, v)).join('')}</select>`;
const ticketLink = id => id ? `<a href="#" data-act="ticket" data-id="${id}">#${id}</a>` : '';

// --------------------------------------------------------------- modal form
function modal(title, bodyHTML, { onSave, saveLabel = 'Save changes', onDelete, deleteLabel = 'Delete' } = {}) {
  const root = $('#modal-root');
  root.innerHTML = `<div class="scrim modal-scrim"></div><form class="modal" novalidate><h2>${esc(title)}</h2>${bodyHTML}
    <div class="err" role="alert"></div><div class="foot"><div>${onDelete ? `<button type="button" class="btn danger" data-x="del">${esc(deleteLabel)}</button>` : ''}</div>
    <div class="actions"><button type="button" class="btn" data-x="close">Cancel</button>${onSave ? `<button class="btn primary">${esc(saveLabel)}</button>` : ''}</div></div></form>`;
  const form = $('form', root), close = () => { root.innerHTML = ''; };
  const run = async fn => { try { await fn(Object.fromEntries(new FormData(form))); close(); } catch (e) { $('.err', form).textContent = e.message; } };
  $('.scrim', root).onclick = close;
  $('[data-x=close]', form).onclick = close;
  if (onDelete) $('[data-x=del]', form).onclick = () => run(onDelete);
  form.onsubmit = e => { e.preventDefault(); if (onSave) run(onSave); };
  const first = form.querySelector('input,select,textarea'); if (first) first.focus();
  return close;
}
const field = (name, text, html, wide) => `<label class="f${wide ? ' wide' : ''}">${esc(text)}${html}</label>`;
const input = (name, val, type = 'text', attrs = '') => `<input name="${name}" type="${type}" value="${esc(val ?? '')}" ${attrs}>`;

function taskModal(task = {}, done) {
  const t = { category: 'DEVELOPMENT', status: 'TODO', priority: 2, estimated_hours: '', assignee_id: me.id, ...task };
  const lead = isLead();
  const people = lead ? users : users.filter(u => u.id === me.id);
  const estField = lead
    ? field('estimated_hours', 'Estimated hours', input('estimated_hours', t.estimated_hours || '', 'number', 'min="0" step="0.5"'))
    : `<label class="f">Estimated hours <span class="locked">${ICO.lock}${t.estimated_hours ? hrs(t.estimated_hours) : 'Not set yet'}<small>Set by your team lead</small></span></label>`;
  const body = `<div class="form-grid">
    ${field('title', 'Title', input('title', t.title, 'text', 'required maxlength="300"'), true)}
    ${field('category', 'Type of work', `<select name="category">${meta.categories.map(c => opt(c, label(c), t.category)).join('')}</select>`)}
    ${field('ticket_id', 'Freshdesk ticket number (optional)', input('ticket_id', t.ticket_id, 'number', 'min="1"'))}
    ${field('assignee_id', 'Assigned to', `<select name="assignee_id">${people.map(u => opt(u.id, u.name, t.assignee_id)).join('')}${t.assignee_id && !people.some(u => u.id === t.assignee_id) ? opt(t.assignee_id, t.assignee || 'Current assignee', t.assignee_id) : ''}</select>`)}
    ${estField}
    ${field('status', 'Status', `<select name="status">${meta.task_statuses.map(s => opt(s, TASK_CHIP[s][1], t.status)).join('')}</select>`)}
    ${field('priority', 'Priority', `<select name="priority">${[1, 2, 3, 4].map(p => opt(p, PRIO[p][1], t.priority)).join('')}</select>`)}
    ${field('start_date', 'Start date', input('start_date', t.start_date, 'date'))}
    ${field('due_date', 'Due date', input('due_date', t.due_date, 'date'))}
    ${field('description', 'Notes', `<textarea name="description">${esc(t.description || '')}</textarea>`, true)}</div>
    ${t.id ? `<section class="history"><h3>History</h3><div id="task-history" class="muted small">Loading…</div></section>` : ''}`;
  modal(t.id ? `Edit task ${tid(t.id)}` : 'New task', body, {
    saveLabel: t.id ? 'Save changes' : 'Create task',
    onSave: async f => {
      const payload = { ...f, ticket_id: f.ticket_id ? +f.ticket_id : null, assignee_id: +f.assignee_id,
        estimated_hours: lead ? (+f.estimated_hours || 0) : (t.id ? (+t.estimated_hours || 0) : 0),
        priority: +f.priority, start_date: f.start_date || null, due_date: f.due_date || null };
      await api(t.id ? '/tasks/' + t.id : '/tasks', { method: t.id ? 'PUT' : 'POST', body: payload });
      toast(t.id ? 'Task saved' : (lead || payload.estimated_hours ? 'Task created' : 'Task created. Your team lead will add the estimate')); done && done();
    },
    onDelete: t.id ? async () => { await api('/tasks/' + t.id, { method: 'DELETE' }); toast('Task deleted'); done && done(); } : null,
    deleteLabel: 'Delete task',
  });
  if (t.id) api(`/tasks/${t.id}/history`).then(h => {
    const box = $('#task-history'); if (!box) return;
    box.classList.remove('muted', 'small');
    box.innerHTML = `<ol class="timeline">${h.map(e => `<li class="k-${e.kind.toLowerCase()}"><i></i><div><b>${esc(e.detail)}</b><span>${esc(e.who)}, ${fmtDT(e.at)}</span></div></li>`).join('')}</ol>`;
  }).catch(() => { const box = $('#task-history'); if (box) box.textContent = 'History could not be loaded.'; });
}
function logModal(task, done) {
  const body = `<p class="muted" style="margin:-6px 0 12px">${esc(task.title)}</p><div class="form-grid">
    ${field('work_date', 'Date', input('work_date', today(), 'date', `max="${today()}" required`))}
    ${field('hours', 'Hours', input('hours', '', 'number', 'min="0.25" max="24" step="0.25" required'))}
    ${field('note', 'What did you do?', input('note', '', 'text', 'maxlength="300"'), true)}</div>`;
  modal('Log hours', body, {
    saveLabel: 'Log hours',
    onSave: async f => { await api('/timelogs', { method: 'POST', body: { task_id: task.id, work_date: f.work_date, hours: +f.hours, note: f.note } }); toast('Hours logged'); done && done(); },
  });
}

// -------------------------------------------------------------------- timer
async function loadTimer() { timer = (await api('/timer')).timer; drawTimer(); }
function drawTimer() {
  const box = $('#timerbox'); if (!box) return;
  if (!timer) { box.innerHTML = ''; return; }
  const s = Math.max(0, Math.floor((Date.now() - new Date(timer.started_at)) / 1000));
  box.innerHTML = `<div class="timerbox"><div class="clock">${pad(Math.floor(s / 3600))}:${pad(Math.floor(s / 60) % 60)}:${pad(s % 60)}</div>
    <div class="t-task" title="${esc(timer.task)}">${esc(timer.task)}</div><button class="btn sm" data-act="timer-stop">Stop</button></div>`;
}
setInterval(() => { if (timer) { const c = $('#timerbox .clock'); if (c) { const s = Math.floor((Date.now() - new Date(timer.started_at)) / 1000); c.textContent = `${pad(Math.floor(s / 3600))}:${pad(Math.floor(s / 60) % 60)}:${pad(s % 60)}`; } } }, 1000);

// ------------------------------------------------------------------- views
const state = { range: 30, dash: 'tickets', dashF: {}, tv: { member: 'all', chip: 'open', search: '', category: '', group: 'status', closed: {}, open: {} }, tickets: { status_filter: 'unresolved' }, chat: [] };
const views = {};
const head = (title, sub, actions = '') => `<div class="page-head"><div><h1>${esc(title)}</h1>${sub ? `<p>${esc(sub)}</p>` : ''}</div><div class="actions">${actions}</div></div>`;

const seg = (key, items, cur) => `<div class="seg" role="tablist">${items.map(([v, t, n]) => `<button role="tab" aria-selected="${String(v) === String(cur)}" class="${String(v) === String(cur) ? 'on' : ''}" data-act="${key}" data-v="${esc(v)}">${esc(t)}${n != null ? `<b>${n}</b>` : ''}</button>`).join('')}</div>`;
const dashTabs = () => seg('dash-tab', [['tickets', 'Helpdesk tickets'], ['team', 'Team effort']], state.dash);
function breakdown(title, sub, rows, key) {
  const max = Math.max(...rows.map(r => r.count), 1);
  const body = rows.length ? rows.map(r => `<div class="brow${key ? ' click' : ''}"${key ? ` data-act="tickets-by" data-key="${key}" data-v="${esc(r.label)}"` : ''} data-tip="${esc(`${r.label}: ${r.count} tickets (${r.percentage}%)${r.in_team === false ? '\nThis owner is not a team member in the tracker' : ''}${key ? '\nSelect to list them' : ''}`)}">
    <div class="lab">${esc(r.label)}${r.in_team === false ? '<em class="nt">not in the team</em>' : ''}</div><div class="track"><div class="bar" style="width:${(100 * r.count / max).toFixed(1)}%"></div></div><div class="v">${r.count}</div><div class="p">${r.percentage}%</div></div>`).join('')
    : '<div class="empty">No unresolved tickets match.</div>';
  return card(title, sub, `<div class="brows">${body}</div>`);
}
views.dashboard = async el => {
  if (state.dash === 'team') return teamDash(el);
  const f = state.dashF;
  const [s, fl, sync] = await Promise.all([api('/dashboard/stats' + qs(f)), views.tickets.fl || api('/tickets/filters'), api('/sync/status')]);
  views.tickets.fl = fl;
  const open = s.unresolved_tickets, pc = n => open ? Math.round(1000 * n / open) / 10 + '% of open' : 'none open';
  const sel = (key, options, all) => `<label class="fsel"><span>${all[0]}</span><select data-change="dash-filter" data-key="${key}" aria-label="${all[0]}">${opt('', all[1], f[key])}${options.map(([v, t]) => opt(v, t, f[key])).join('')}</select></label>`;
  const g = s.group_counts, last = sync.last_sync;
  const tile = (cls, lab, val, sub, flag, bad) => `<button class="tile ${cls}${bad && val ? ' bad' : ''}" data-act="tickets-flag" data-v="${flag}"><span class="t-lab">${lab}</span><span class="t-val">${val}</span><span class="t-sub">${sub}</span></button>`;
  const scope = f.group || 'all groups';
  el.innerHTML = head('Dashboard', sync.is_configured ? `Unresolved Freshdesk tickets. ${last ? 'Last synchronised ' + fmtDT(last.started_at) + '.' : 'Waiting for the first sync.'}` : 'Showing sample data. Connect Freshdesk under Settings to see your own tickets.', dashTabs()) + `
  <div class="filterbar">${seg('dash-group', [['', 'Overall', g.overall], ['QAD', 'QAD', g.QAD], ['EDI', 'EDI', g.EDI], ['IT', 'IT', g.IT]], f.group || '')}
    ${sel('location', fl.locations.map(a => [a, a]), ['Location', 'All locations'])}${sel('agent', [['Unassigned', 'Unassigned'], ...fl.agents.map(a => [a, a])], ['Owner', 'All owners'])}
    ${sel('priority', [1, 2, 3, 4].map(p => [p, PRIO[p][1]]), ['Priority', 'All priorities'])}${sel('type', fl.types.map(a => [a, a]), ['Type', 'All types'])}
    <span class="grow"></span>${Object.values(f).some(Boolean) ? '<a href="#" data-act="dash-reset">Reset filters</a>' : ''}${isLead() && sync.is_configured ? '<button class="btn" data-act="sync">Sync now</button>' : ''}</div>
  <div class="tiles">
    ${tile('lead', `Open tickets, ${esc(scope)}`, open, `${s.locations} locations, ${s.agents} owners`, '')}
    ${tile('', 'High or urgent', s.high_urgent_tickets, pc(s.high_urgent_tickets), 'urgent', true)}
    ${tile('', 'Past due date', s.overdue_tickets, s.overdue_tickets ? pc(s.overdue_tickets) : 'all within SLA', 'overdue', true)}
    ${tile('', 'Older than 30 days', s.over_30_days_tickets, pc(s.over_30_days_tickets), 'over30', true)}
    ${tile('', 'No update in 14 days', s.no_update_14d_tickets, pc(s.no_update_14d_tickets), 'stale14', true)}
    ${tile('', 'Unassigned', s.unassigned_tickets, s.unassigned_tickets ? pc(s.unassigned_tickets) : 'all assigned', 'unassigned', true)}
  </div>
  <div class="grid g4">
    ${breakdown('By type', 'Kind of request', s.by_type, 'type')}
    ${breakdown('By status', 'Where tickets are waiting', s.by_status, '')}
    ${breakdown('By location', 'Plant or site on the ticket', s.by_location, 'location')}
    ${breakdown('By owner', s.untracked_tickets ? `${s.untracked_tickets} belong to agents who are not team members here` : 'Tickets per agent', s.by_agent, 'agent')}
  </div>`;
};
async function teamDash(el) {
  const o = await api('/reports/overview' + qs({ start: daysAgo(state.range - 1), end: today() }));
  const tk = o.tickets, e = o.effort, es = o.estimates, sla = o.sla;
  el.innerHTML = head('Dashboard', 'Workload, hours and estimates for the team.', rangeSelect(state.range) + dashTabs()) + `
  <div class="kpis">
    <div class="kpi"><div class="k-label">Open tasks</div><div class="k-value">${o.open_tasks}</div><div class="k-sub">${o.needs_estimate} without an estimate</div></div>
    <div class="kpi"><div class="k-label">Overloaded people</div><div class="k-value">${o.overloaded.length}</div><div class="k-sub">${o.overloaded.length ? esc(o.overloaded.slice(0, 3).join(', ')) + (o.overloaded.length > 3 ? ' and others' : '') : 'Nobody over capacity'}</div></div>
    <div class="kpi"><div class="k-label">Hours logged</div><div class="k-value">${num(e.total_hours)}</div><div class="k-sub">${e.ticket_pct}% tickets, ${e.non_ticket_pct}% other work</div></div>
    <div class="kpi"><div class="k-label">Finished within estimate</div><div class="k-value">${es.within_pct}%</div><div class="k-sub">${es.within_estimate} of ${es.completed_with_estimate} completed tasks</div></div>
    <div class="kpi"><div class="k-label">Resolved within SLA</div><div class="k-value">${sla.resolution_compliance_pct}%</div><div class="k-sub">${sla.resolved_tickets} resolved, avg ${num(sla.avg_resolution_hours)} h</div></div>
  </div>
  <div class="grid g3" style="margin-bottom:16px">
    ${card('Who is overloaded?', 'Estimated hours left on open tasks against weekly capacity', `<div class="scrolly">${rails(o.workload.filter(w => w.user_id))}</div>`, '<a href="#/workload">Details</a>')}
    ${card('Ticket versus non-ticket work', `Hours logged in the last ${state.range} days`, splitBar(e) + (e.total_hours ? dayColumns(e.by_day) : ''))}
  </div>
  <div class="grid g2">
    ${card('Tickets consuming the most effort', 'Hours logged in the period; select a ticket to open it', hbars(o.top_tickets.map(t => ({ label: `#${t.ticket_id} ${t.subject}`, value: t.hours, act: 'ticket', id: t.ticket_id, tip: `#${t.ticket_id} ${t.subject}\n${hrs(t.hours)} logged, ${hrs(t.estimated)} estimated\n${t.agent || 'Unassigned'}` })), { unit: ' h' }))}
    ${card('Root causes', `${o.rca.tickets_with_rca} tickets have a root cause recorded (${o.rca.rca_coverage_pct}% of resolved)`, hbars(o.rca.by_category.map(c => ({ label: c.category, value: c.tickets, tip: `${c.category}\n${c.tickets} tickets, ${c.recurring} recurring\n${hrs(c.hours)} logged` }))))}
  </div>`;
}

const LOG_ICON = l => l.source === 'TIMER' ? `<span class="src" title="Logged with the timer">${ICO.timer}</span>` : l.source === 'CALENDAR' ? `<span class="src" title="Logged from Outlook">${ICO.cal}</span>` : '';
function greeting() { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; }
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const LONG_DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const LONG_MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
function verdict(t) {
  if (!t.estimated_hours) return chip('', `${num(t.actual_hours)} h, no estimate`);
  if (t.over_estimate) return chip('critical', `Over by ${num(t.actual_hours - t.estimated_hours)} h`);
  return chip('good', `Within estimate, ${num(t.actual_hours)} of ${num(t.estimated_hours)} h`);
}
function weekColumns(weeks, { compact } = {}) {
  const max = Math.max(...weeks.map(w => w.total), 1);
  return `<div class="wcols${compact ? ' compact' : ''}">${weeks.map((w, i) => {
    const seg = (n, cls) => n ? `<div class="${cls}" style="height:${(100 * n / max).toFixed(1)}%"></div>` : '';
    const d = new Date(w.week + 'T00:00:00');
    return `<div class="wcol" data-tip="${esc(`Week of ${fmtDate(w.week)}\n${w.total} completed\n${w.within} within estimate\n${w.over} over estimate\n${w.no_estimate} without an estimate`)}">
      <span class="wv">${w.total || ''}</span><div class="wstack">${seg(w.no_estimate, 'n')}${seg(w.over, 'o')}${seg(w.within, 'w')}</div><span class="wl">${i === weeks.length - 1 ? 'This week' : d.getDate() + ' ' + MONTHS[d.getMonth()]}</span></div>`;
  }).join('')}</div><div class="legend" style="margin-top:10px"><span><i style="background:var(--good)"></i>Within estimate</span><span><i style="background:var(--critical)"></i>Over estimate</span><span><i style="background:var(--text-3)"></i>No estimate</span></div>`;
}
views.my = async el => {
  const off = state.myWeek || 0, tab = state.myTab || 'open';
  const ws = weekStart(); ws.setDate(ws.getDate() + 7 * off);
  const we = new Date(ws); we.setDate(we.getDate() + 6);
  const since = new Date(); since.setDate(since.getDate() - 30);
  const [open, done, helping, logs, weeks, cal] = await Promise.all([
    api('/tasks' + qs({ assignee_id: me.id, status: 'OPEN' })),
    api('/tasks' + qs({ assignee_id: me.id, status: 'DONE', completed_since: localISO(since) })),
    api('/tasks' + qs({ helped_by: me.id, status: 'OPEN' })),
    api('/timelogs' + qs({ user_id: me.id, start: localISO(ws), end: localISO(we) })),
    api('/reports/completed' + qs({ user_id: me.id, weeks: 8 })),
    me.calendar_connected ? api('/me/meetings' + qs({ start: localISO(ws), end: localISO(we) })).catch(e => ({ connected: true, error: e.message, meetings: [] })) : Promise.resolve({ connected: false, meetings: [] }),
  ]);
  views.my.tasks = open.concat(done, helping);
  views.my.meetings = cal.meetings;
  const byDay = {}; logs.forEach(l => { byDay[l.work_date] = (byDay[l.work_date] || 0) + l.hours; });
  const total = logs.reduce((s, l) => s + l.hours, 0);
  const dayTarget = (me.weekly_capacity_hours || 40) / 5;
  const strip = [...Array(7)].map((_, i) => {
    const d = new Date(ws); d.setDate(d.getDate() + i); const k = localISO(d), h = byDay[k] || 0;
    const gap = i < 5 && k < today() && h === 0;
    return `<div class="day${k === today() ? ' today' : ''}${i > 4 ? ' wknd' : ''}" data-tip="${esc(`${LONG_DAYS[d.getDay()]} ${fmtDate(k)}\n${num(h)} h logged${gap ? '\nNothing logged on this working day' : ''}`)}">
      <span class="dn">${DAYS[i]} <small>${d.getDate()}</small></span><div class="dbar"><i style="height:${Math.min(100, 100 * h / dayTarget).toFixed(0)}%"></i></div><b>${num(h)}</b>${gap ? '<em class="gapdot" aria-label="Nothing logged"></em>' : ''}</div>`;
  }).join('');
  const now = new Date();
  const dueSoon = open.filter(t => t.due_date && t.due_date >= today() && t.due_date <= localISO(new Date(now.getFullYear(), now.getMonth(), now.getDate() + 7))).length;
  const overdue = open.filter(t => t.overdue).length;
  const doneThisWeek = done.filter(t => t.completed_at && new Date(t.completed_at) >= weekStart()).length;
  const todayH = (logs.filter(l => l.work_date === today()).reduce((s, l) => s + l.hours, 0));
  const openRows = open.map(t => {
    const running = timer && timer.task_id === t.id;
    const tone = t.overdue ? 'st-late' : t.status === 'IN_PROGRESS' ? 'st-prog' : t.status === 'ON_HOLD' ? 'st-hold' : 'st-todo';
    return `<div class="trow ${tone}" data-row="${t.id}"><div class="tmain"><div class="ttl"><a href="#" data-act="task-edit" data-id="${t.id}">${esc(t.title)}</a></div><div class="meta">${taskChip(t.status)}<span>${esc(label(t.category))}</span>${t.ticket_id ? ticketLink(t.ticket_id) : ''}
      ${t.due_date ? (t.overdue ? `<span class="late">${ICO.cal} Overdue since ${fmtDate(t.due_date)}</span>` : `<span>${ICO.cal} Due ${fmtDate(t.due_date)}</span>`) : ''}</div></div>
      <div class="tside">${t.estimated_hours ? `<div class="small ${t.over_estimate ? 'late' : 'muted'}">${num(t.actual_hours)} of ${num(t.estimated_hours)} h${t.over_estimate ? ', over estimate' : ''}</div><div class="prog"><div class="${t.over_estimate ? 'over' : ''}" style="width:${Math.min(100, t.progress_pct)}%"></div></div>`
        : `<div class="small muted">${num(t.actual_hours)} h logged. ${isLead() ? `<a href="#" data-act="task-edit" data-id="${t.id}">Add an estimate</a>` : 'Waiting for an estimate'}</div>`}
      <div class="actions">${running ? `<button class="btn sm" data-act="timer-stop">Stop timer</button>` : `<button class="btn sm" data-act="timer-start" data-id="${t.id}"${timer ? ' disabled' : ''}>${ICO.timer} Start</button>`}
        <button class="btn sm" data-act="log" data-id="${t.id}">Log hours</button><button class="btn sm done-btn" data-act="task-done" data-id="${t.id}">${ICO.check} Done</button></div></div></div>`;
  }).join('');
  const doneRows = done.map(t => `<div class="trow done" data-row="${t.id}"><div class="tmain"><div class="ttl"><span class="okic">${ICO.check}</span><a href="#" data-act="task-edit" data-id="${t.id}">${esc(t.title)}</a></div>
      <div class="meta"><span>Completed ${fmtDate(t.completed_at)}</span><span>${esc(label(t.category))}</span>${t.ticket_id ? ticketLink(t.ticket_id) : ''}</div></div>
      <div class="tside">${verdict(t)}<div class="actions"><button class="btn sm" data-act="task-reopen" data-id="${t.id}">Reopen</button></div></div></div>`).join('');
  const helpRows = helping.map(t => `<div class="trow st-help" data-row="${t.id}"><div class="tmain"><div class="ttl"><a href="#" data-act="task-edit" data-id="${t.id}">${esc(t.title)}</a></div>
      <div class="meta"><span>${esc(t.assignee || 'Unassigned')}'s task</span>${taskChip(t.status)}${t.ticket_id ? ticketLink(t.ticket_id) : ''}<span>You logged ${num((t.contributors || []).filter(c => c.user_id === me.id).reduce((a, c) => a + c.hours, 0))} h</span></div></div>
      <div class="tside"><div class="small muted">${num(t.actual_hours)} h on this task in total</div><div class="actions"><button class="btn sm" data-act="log" data-id="${t.id}" data-title="${esc(t.title)}">Log hours</button></div></div></div>`).join('');
  const tabs = seg('my-tab', [['open', 'Open', open.length], ['helping', 'Helping', helping.length], ['done', 'Completed', done.length]], tab);
  const logRows = logs.map(l => `<li><span class="ld">${DAYS[(new Date(l.work_date + 'T00:00:00').getDay() + 6) % 7]} ${new Date(l.work_date + 'T00:00:00').getDate()}</span>
      <div class="lt">${l.standing ? `<b>${LOG_ICON(l)}${esc(l.note || 'Meeting')}</b><span>Meeting</span>` : `<b>${LOG_ICON(l)}${esc(l.task)}</b>${l.note && l.note !== l.task ? `<span>${esc(l.note)}</span>` : ''}`}</div><span class="lh">${num(l.hours)} h</span>
      <button class="btn sm ghost" data-act="log-del" data-id="${l.id}" aria-label="Remove ${num(l.hours)} h on ${esc(l.task)}" title="Remove entry">×</button></li>`).join('');
  const weekLabel = off === 0 ? 'This week' : off === -1 ? 'Last week' : `Week of ${fmtDate(localISO(ws))}`;
  const d0 = new Date();
  el.innerHTML = `<div class="hello"><div><h1>${greeting()}, ${esc(me.name.split(' ')[0])}</h1>
      <p>${LONG_DAYS[d0.getDay()]} ${d0.getDate()} ${LONG_MONTHS[d0.getMonth()]}. ${open.length ? `You have ${open.length} open task${open.length > 1 ? 's' : ''}` : 'You have no open tasks'}${overdue ? `, ${overdue} overdue` : ''}${dueSoon ? `, ${dueSoon} due in the next 7 days` : ''}.</p></div>
      <div class="actions"><button class="btn" data-act="meeting-manual">${ICO.cal} Log a meeting</button><button class="btn primary" data-act="task-new">New task</button></div></div>
    <div class="glance">
      <div><span>Logged today</span><b>${num(todayH)} h</b><em>${todayH >= dayTarget ? 'Full day logged' : `${num(Math.max(0, dayTarget - todayH))} h to a full day`}</em></div>
      <div><span>Logged this week</span><b>${num(off === 0 ? total : 0) || (off === 0 ? '0' : '—')}${off === 0 ? ' h' : ''}</b><em>of ${num(me.weekly_capacity_hours)} h capacity</em></div>
      <div class="good"><span>Completed this week</span><b>${doneThisWeek}</b><em>${done.length} in the last 30 days</em></div>
      <div class="${overdue ? 'bad' : ''}"><span>Overdue</span><b>${overdue}</b><em>${overdue ? 'Needs attention' : 'Nothing overdue'}</em></div>
    </div>
    <div class="grid mywork">
      <section class="card"><header><div><h2>${tab === 'open' ? 'My tasks' : tab === 'helping' ? 'Work I am helping with' : 'Completed in the last 30 days'}</h2>
        <p>${tab === 'open' ? 'Start the timer while you work, or log hours afterwards' : tab === 'helping' ? 'Open tasks that belong to someone else, where you have logged hours' : 'Reopen a task if it was closed by mistake'}</p></div>${tabs}</header>
        ${tab === 'open' ? (openRows || '<div class="empty">No open tasks. Create one for work that is not on a ticket.</div>')
          : tab === 'helping' ? (helpRows || '<div class="empty">Nothing here yet. If you help a colleague, log your hours on their task from the Tasks tab and it appears here.</div>')
          : (doneRows ? `<div class="donechart">${weekColumns(weeks, { compact: true })}</div>${doneRows}` : '<div class="empty">Tasks you complete appear here, with how they finished against their estimate.</div>')}</section>
      <div class="stack">
        <section class="card"><header><div><h2>${weekLabel}</h2><p>${fmtDate(localISO(ws))} to ${fmtDate(localISO(we))}: ${hrs(total)} logged</p></div>
          <div class="pager"><button class="btn sm" data-act="my-week" data-v="-1" aria-label="Previous week">‹</button>${off ? '<button class="btn sm" data-act="my-week" data-v="0">Today</button>' : ''}<button class="btn sm" data-act="my-week" data-v="1" aria-label="Next week"${off >= 0 ? ' disabled' : ''}>›</button></div></header>
          <div class="strip">${strip}</div>
          ${logRows ? `<ul class="loglist">${logRows}</ul>` : '<div class="empty">No hours logged in this week.</div>'}</section>
        ${meetingsCard(cal)}
      </div>
    </div>`;
};
function meetingsCard(cal) {
  if (!cal.connected) return card('Meetings from Outlook', 'Log the time you spend in meetings with one click', `<div class="cal-empty">${ICO.cal}<p>Connect your Outlook calendar to see this week's meetings here and log them as meeting hours without typing.</p><button class="btn primary" data-act="cal-connect">Connect Outlook calendar</button></div>`);
  if (cal.error) return card('Meetings from Outlook', '', `<p class="late">${esc(cal.error)}</p><button class="btn sm" data-act="cal-connect">Change calendar link</button>`);
  const ms = cal.meetings, open = ms.filter(m => m.finished && !m.logged);
  const hm = iso => { const d = new Date(iso); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };
  const rows = ms.map(m => `<li class="${m.logged ? 'logged' : ''}"><span class="mt">${DAYS[(new Date(m.date + 'T00:00:00').getDay() + 6) % 7]} ${hm(m.start)}</span><div class="lt"><b>${esc(m.title)}</b><span>${hm(m.start)} to ${hm(m.end)}${m.location ? ', ' + esc(m.location) : ''}</span></div><span class="lh">${num(m.hours)} h</span>
    ${m.logged ? `<span class="okic" title="Logged">${ICO.check}</span>` : m.finished ? `<button class="btn sm" data-act="meeting-log" data-ref="${esc(m.ref)}">Log</button>` : '<span class="muted small">Upcoming</span>'}</li>`).join('');
  return card('Meetings from Outlook', `${ms.length} meetings this week, ${num(ms.reduce((s, m) => s + m.hours, 0))} h`, rows ? `<ul class="loglist meet">${rows}</ul>` : '<div class="empty">No meetings in this week.</div>',
    `<div class="actions">${open.length ? `<button class="btn sm primary" data-act="meeting-log-all">Log ${open.length} finished</button>` : ''}<button class="btn sm ghost" data-act="cal-refresh" title="Fetch the latest from Outlook">Refresh</button></div>`);
}
function calendarModal() {
  modal('Connect your Outlook calendar', `<ol class="steps"><li>Open Outlook on the web, then <b>Settings</b>, <b>Calendar</b>, <b>Shared calendars</b>.</li><li>Under <b>Publish a calendar</b>, choose your calendar and <b>Can view all details</b> (or <b>Can view titles and locations</b>), then <b>Publish</b>.</li><li>Copy the <b>ICS</b> link and paste it here.</li></ol>
    ${field('url', 'Calendar ICS link', input('url', '', 'url', 'placeholder="https://outlook.office365.com/owa/calendar/…/calendar.ics" required'))}
    <p class="small muted" style="margin-top:10px">Anyone who has this link can see the calendar details you publish, so keep it private. If publishing is turned off in your company, ask IT; the app can be connected through Microsoft 365 instead.</p>`, {
    saveLabel: 'Connect calendar',
    onSave: async f => { await api('/me/calendar', { method: 'PUT', body: { url: f.url } }); me = await api('/auth/me'); toast('Outlook calendar connected'); route(); },
    onDelete: me.calendar_connected ? async () => { await api('/me/calendar', { method: 'PUT', body: { url: '' } }); me = await api('/auth/me'); toast('Calendar disconnected'); route(); } : null,
    deleteLabel: 'Disconnect calendar',
  });
}
function meetingModal() {
  modal('Log a meeting', `<div class="form-grid">${field('title', 'Meeting', input('title', '', 'text', 'required maxlength="200" placeholder="For example: weekly change review"'), true)}
    ${field('date', 'Date', input('date', today(), 'date', `max="${today()}" required`))}${field('hours', 'Hours', input('hours', '1', 'number', 'min="0.25" max="12" step="0.25" required'))}</div>`, {
    saveLabel: 'Log meeting',
    onSave: async f => { await api('/me/meetings/log', { method: 'POST', body: { meetings: [{ title: f.title, date: f.date, hours: +f.hours }] } }); toast('Meeting logged'); route(); },
  });
}

const TASK_CHIPS = [['open', 'Open', t => t.status !== 'DONE'], ['overdue', 'Overdue', t => t.overdue], ['progress', 'In progress', t => t.status === 'IN_PROGRESS'],
  ['noest', 'No estimate', t => t.status !== 'DONE' && !t.estimated_hours], ['done', 'Done', t => t.status === 'DONE'], ['all', 'All tasks', () => true]];
const CHIP_DOT = { open: 'info', overdue: 'critical', progress: 'info', noest: 'warning', done: 'good', all: '' };
function stack(people, own) {
  const extra = people.filter(p => p.name !== own);
  if (!extra.length) return '';
  return `<span class="stack" data-tip="${esc('Helped: ' + extra.map(p => `${p.name} ${num(p.hours)} h`).join('\n'))}">${extra.slice(0, 3).map(p => avatar(p.name, 'xs')).join('')}${extra.length > 3 ? `<span class="av xs more">+${extra.length - 3}</span>` : ''}</span>`;
}
function taskRow(t) {
  const pct = t.estimated_hours ? Math.round(t.progress_pct) : null, isDone = t.status === 'DONE';
  const open = !!state.tv.open[t.id];
  const est = isLead() && !isDone
    ? `<input class="est-in" type="number" min="0" step="0.5" value="${t.estimated_hours || ''}" placeholder="Add" data-id="${t.id}" aria-label="Estimated hours for ${esc(t.title)}" title="Estimated hours">`
    : (t.estimated_hours ? num(t.estimated_hours) : '<span class="muted">?</span>');
  const orphan = !t.assignee && t.ticket_agent;
  return `<tr class="click${isDone ? ' is-done' : ''}${open ? ' open' : ''}" data-act="task-edit" data-id="${t.id}">
    <td class="tid"><button class="caret-btn" data-act="task-expand" data-id="${t.id}" aria-expanded="${open}" aria-label="Steps and hours for ${esc(t.title)}" title="Steps and hours"><span class="caret">${open ? '▾' : '▸'}</span></button>${tid(t.id)}</td>
    <td><div class="t-line"><div class="t-title" title="${esc(t.title)}">${isDone ? `<span class="okic">${ICO.check}</span>` : ''}${esc(t.title)}</div>${t.steps_total ? `<span class="steps-badge" data-tip="${t.steps_done} of ${t.steps_total} steps done">${ICO.check}${t.steps_done}/${t.steps_total}</span>` : ''}</div>
      <div class="t-sub">${esc(label(t.category))}${t.ticket_id ? ` <span class="sep"></span> ${ticketLink(t.ticket_id)}` : ''}${t.auto_created ? ' <span class="sep"></span> from Freshdesk' : ''}${orphan ? ` <span class="sep"></span> <span class="orphan">Freshdesk owner: ${esc(t.ticket_agent)}</span>` : ''}</div></td>
    <td>${taskChip(t.status)}</td><td><span class="who-cell">${person(t.assignee)}${stack(t.contributors || [], t.assignee)}</span></td>
    <td><div class="pcell" data-tip="${pct == null ? 'No estimate yet' : `${num(t.actual_hours)} of ${num(t.estimated_hours)} h used`}"><div class="prog"><div class="${t.over_estimate ? 'over' : isDone ? 'done' : ''}" style="width:${Math.min(100, pct || 0)}%"></div></div><span>${pct == null ? '—' : pct + '%'}</span></div></td>
    <td class="num nowrap">${num(t.actual_hours)} / ${est} h</td>
    <td class="nowrap">${isDone ? `<span class="okt">Done ${fmtDate(t.completed_at)}</span>` : dueCell(t)}</td>
    <td class="right">${isDone ? `<button class="btn sm" data-act="task-reopen" data-id="${t.id}">Reopen</button>` : `<button class="btn sm" data-act="log" data-id="${t.id}" data-title="${esc(t.title)}">Log hours</button>`}</td></tr>`;
}

// ---- expandable detail: steps (sub-tasks) and every hour logged on the task
function detailBox(id, d) {
  const t = (views.tasks.rows || []).find(x => x.id === id) || {};
  const steps = d.checklist, doneN = steps.filter(x => x.done).length;
  const total = d.logs.reduce((a, l) => a + l.hours, 0);
  const mine = l => l.user_id === me.id || isLead();
  return `<div class="dbox">
    <section>
      <h4>Steps${steps.length ? ` <span class="g-n">${doneN} of ${steps.length}</span>` : ''}</h4>
      ${steps.length ? `<ul class="chk">${steps.map(x => `<li class="${x.done ? 'on' : ''}"><label><input type="checkbox" class="chk-item" data-id="${x.id}" data-task="${id}"${x.done ? ' checked' : ''}${d.can_edit ? '' : ' disabled'}><span>${esc(x.title)}</span></label>${d.can_edit ? `<button class="btn sm ghost" data-act="step-del" data-id="${x.id}" data-task="${id}" title="Remove step" aria-label="Remove step ${esc(x.title)}">×</button>` : ''}</li>`).join('')}</ul>`
        : '<p class="muted small">No steps yet. Break the task into the pieces it takes to finish.</p>'}
      ${d.can_edit ? `<form class="chk-add" data-task="${id}"><input name="title" placeholder="Add a step" maxlength="300" aria-label="New step for this task"><button class="btn sm">Add</button></form>`
        : '<p class="muted small">Only the person this task belongs to, or a team lead, can change the steps.</p>'}
    </section>
    <section>
      <h4>Hours logged <span class="g-n">${num(total)} h${t.estimated_hours ? ` of ${num(t.estimated_hours)} h estimated` : ''}</span></h4>
      ${d.contributors.length > 1 ? `<div class="whoby">${d.contributors.map(c => `<span class="chip">${avatar(c.name, 'xs')}${esc(c.name)} ${num(c.hours)} h</span>`).join('')}</div>` : ''}
      ${d.logs.length ? `<ul class="loglist dlog">${d.logs.map(l => `<li><span class="ld">${fmtDate(l.work_date)}</span><div class="lt"><b>${LOG_ICON(l)}${esc(l.user)}</b>${l.note ? `<span>${esc(l.note)}</span>` : ''}</div><span class="lh">${num(l.hours)} h</span>
        ${mine(l) ? `<button class="btn sm ghost" data-act="log-del" data-id="${l.id}" data-task="${id}" title="Remove entry" aria-label="Remove ${num(l.hours)} h logged by ${esc(l.user)}">×</button>` : '<span></span>'}</li>`).join('')}</ul>`
        : '<p class="muted small">No hours logged on this task yet.</p>'}
      <div class="actions"><button class="btn sm" data-act="log" data-id="${id}" data-title="${esc(t.title || '')}">Log my hours</button><button class="btn sm ghost" data-act="task-edit" data-id="${id}">Open task</button></div>
    </section></div>`;
}
const detailBusy = new Set();
async function insertDetail(id, root) {
  const row = (root || document).querySelector(`tr[data-act="task-edit"][data-id="${id}"]`);
  if (!row || document.getElementById('detail-' + id) || detailBusy.has(id)) return;
  detailBusy.add(id);
  const tr = document.createElement('tr');
  tr.id = 'detail-' + id; tr.className = 'detail';
  tr.innerHTML = '<td colspan="8"><div class="dbox"><p class="muted small">Loading…</p></div></td>';
  row.after(tr);
  try {
    const d = views.tasks.detail[id] || await api(`/tasks/${id}/detail`);
    views.tasks.detail[id] = d;
    tr.firstElementChild.innerHTML = detailBox(id, d);
  } catch (e) { tr.firstElementChild.innerHTML = `<div class="dbox"><p class="late small">${esc(e.message)}</p></div>`; }
  finally { detailBusy.delete(id); }
}
async function repaintDetail(id) {
  delete views.tasks.detail[id];
  const old = document.getElementById('detail-' + id); if (old) old.remove();
  await insertDetail(id);
  const d = views.tasks.detail[id]; if (!d) return;
  const done = d.checklist.filter(x => x.done).length, total = d.checklist.length;
  const title = document.querySelector(`tr[data-id="${id}"] .t-line`);
  let badge = title && title.querySelector('.steps-badge');
  if (title && total && !badge) {
    badge = document.createElement('span');
    badge.className = 'steps-badge';
    badge.dataset.tip = '';
    title.append(badge);
  }
  if (badge && !total) badge.remove();
  else if (badge) { badge.innerHTML = ICO.check + `${done}/${total}`; badge.dataset.tip = `${done} of ${total} steps done`; }
  const row = (views.tasks.rows || []).find(x => x.id === id);
  if (row) { row.steps_done = done; row.steps_total = d.checklist.length; }
}
views.tasks = async el => {
  const v = state.tv;
  views.tasks.detail = views.tasks.detail || {};
  const [wl, tasks] = await Promise.all([api('/reports/workload'), api('/tasks' + qs(v.member === 'all' ? {} : { assignee_id: String(v.member) }))]);
  views.tasks.rows = tasks;
  const members = wl.rows;
  const sel = members.find(m => String(m.user_id) === String(v.member));
  const totals = members.reduce((a, m) => ({ open: a.open + m.open_tasks, over: a.over + m.overdue_tasks, done: a.done + (m.done_this_week || 0) }), { open: 0, over: 0, done: 0 });
  const mcard = (id, name, open, over, sub, load, state_, done) => `<button class="mcard${String(v.member) === String(id) ? ' on' : ''}" data-act="member" data-v="${id}" aria-pressed="${String(v.member) === String(id)}">
    ${id === 'all' ? '<span class="av all" aria-hidden="true">All</span>' : avatar(id ? name : '')}<span class="m-main"><b>${esc(name)}</b><span>${open} open${over ? `, <em>${over} overdue</em>` : ''}${done ? `<strong>${done} done this week</strong>` : ''}</span></span>
    ${load != null ? `<span class="m-load" data-tip="${esc(`${sub}\n${state_}`)}"><i class="${state_ === 'Overloaded' ? 'over' : ''}" style="width:${Math.min(100, load)}%"></i></span>` : ''}</button>`;
  const cards = mcard('all', 'Whole team', totals.open, totals.over, '', null, '', totals.done) + members.map(m => mcard(m.user_id, m.name, m.open_tasks, m.overdue_tasks, `${num(m.remaining_hours)} h of estimated work left, ${num(m.capacity_hours)} h weekly capacity`, m.user_id ? m.load_pct : null, m.state, m.done_this_week)).join('');
  const scoped = tasks.filter(t => (!v.search || t.title.toLowerCase().includes(v.search.toLowerCase())) && (!v.category || t.category === v.category));
  const chipFn = TASK_CHIPS.find(c => c[0] === v.chip)[2];
  const rows = scoped.filter(chipFn);
  views.tasks.visible = rows;
  const GROUPS = { status: t => TASK_CHIP[t.status][1], category: t => label(t.category), assignee: t => t.assignee || 'Unassigned', none: () => '' };
  const order = { status: ['In progress', 'To do', 'On hold', 'Done'] }[v.group];
  const groups = new Map();
  rows.forEach(t => { const k = GROUPS[v.group](t); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(t); });
  let keys = [...groups.keys()]; keys = order ? keys.sort((a, b) => order.indexOf(a) - order.indexOf(b)) : keys.sort();
  const body = keys.map(k => {
    const list = groups.get(k), est = list.reduce((s, t) => s + t.estimated_hours, 0), act = list.reduce((s, t) => s + (t.estimated_hours ? Math.min(t.actual_hours, t.estimated_hours) : 0), 0);
    const closed = v.closed[v.group + k];
    const headRow = v.group === 'none' ? '' : `<tr class="grp" data-act="grp" data-v="${esc(v.group + k)}"><td colspan="8"><span class="caret">${closed ? '▸' : '▾'}</span><b>${esc(k)}</b><span class="g-n">${list.length}</span>${est ? `<span class="g-bar"><i style="width:${Math.round(100 * act / est)}%"></i></span><span class="muted small">${Math.round(100 * act / est)}% of ${num(est)} estimated hours used</span>` : ''}</td></tr>`;
    return headRow + (closed ? '' : list.map(taskRow).join(''));
  }).join('');
  const unassigned = String(v.member) === '0';
  el.innerHTML = head('Tasks', 'Select a team member to see their tasks. Open a row for its steps and the hours logged on it.',
    `${isLead() && unassigned && rows.length ? `<button class="btn" data-act="hand-over-all">Hand these over…</button>` : ''}<button class="btn" data-act="tasks-csv">Export list</button><button class="btn primary" data-act="task-new">New task</button>`) + `
  <div class="mgrid">${cards}</div>
  <div class="chips">${sel ? `<span class="whose">${avatar(sel.user_id ? sel.name : '', 'lg')}<b>${esc(sel.name)}</b></span>` : ''}${TASK_CHIPS.map(([k, t, fn]) => `<button class="statchip${v.chip === k ? ' on' : ''}" data-act="task-chip" data-v="${k}" aria-pressed="${v.chip === k}"><i class="${CHIP_DOT[k]}"></i><b>${scoped.filter(fn).length}</b><span>${t}</span></button>`).join('')}</div>
  ${unassigned ? `<p class="note">These tasks have no owner in the tracker. Tasks that came from Freshdesk still show the agent the ticket belongs to there.</p>` : ''}
  <div class="toolbar"><input type="search" placeholder="Search tasks" value="${esc(v.search)}" data-change="tv" data-key="search" aria-label="Search tasks">
    <select data-change="tv" data-key="category" aria-label="Type of work">${opt('', 'Any type of work', v.category)}${meta.categories.map(c => opt(c, label(c), v.category)).join('')}</select>
    <span class="grow"></span><span class="muted small">${rows.length} of ${tasks.length}</span>
    <label class="fsel inline"><span>Group by</span><select data-change="tv" data-key="group">${[['status', 'Status'], ['category', 'Type of work'], ['assignee', 'Assignee'], ['none', 'No grouping']].map(([a, b]) => opt(a, b, v.group)).join('')}</select></label></div>
  <section class="card flush">${rows.length ? `<div class="table-wrap"><table class="tasks"><thead><tr><th>ID</th><th>Task</th><th>Status</th><th>Assignee</th><th>Progress</th><th class="num">Actual / estimate</th><th>Due</th><th></th></tr></thead><tbody>${body}</tbody></table></div>`
    : `<div class="empty">${tasks.length ? 'No tasks match this view. Try another filter above.' : 'No tasks here yet. Create one, or run a Freshdesk sync to bring in assigned tickets.'}</div>`}</section>`;
  document.querySelectorAll('tr.detail').forEach(x => x.remove());
  Object.keys(state.tv.open).forEach(id => { if (rows.some(t => t.id === +id)) insertDetail(+id, el); else delete state.tv.open[id]; });
};

views.tickets = async el => {
  const f = state.tickets;
  const [rows, fl] = await Promise.all([api('/tickets' + qs(f)), views.tickets.fl || api('/tickets/filters')]);
  views.tickets.fl = fl;
  const sel = (key, options, all) => `<select data-change="ticket-filter" data-key="${key}" aria-label="${all}">${opt('', all, f[key])}${options.map(([v, t]) => opt(v, t, f[key])).join('')}</select>`;
  el.innerHTML = head('Freshdesk tickets', 'Synchronised from Freshdesk. Open a ticket to see its conversation, hours and root cause.', isLead() ? `<button class="btn" data-act="sync">Sync now</button>` : '') + `
  <div class="filters"><input type="search" placeholder="Search subject or number" value="${esc(f.search || '')}" data-change="ticket-filter" data-key="search" aria-label="Search tickets">
    ${sel('group', [['QAD', 'QAD'], ['EDI', 'EDI'], ['IT', 'IT']], 'All groups')}
    ${sel('status_filter', [['unresolved', 'Unresolved'], ['open', 'Open'], ['assigned', 'Assigned'], ['in_progress', 'In progress'], ['pending', 'Pending / on hold'], ['resolved', 'Resolved'], ['closed', 'Closed']], 'Any status')}
    ${sel('agent', [['Unassigned', 'Unassigned'], ...fl.agents.map(a => [a, a])], 'Any owner')}
    ${sel('priority', [1, 2, 3, 4].map(p => [p, PRIO[p][1]]), 'Any priority')}
    ${sel('type', fl.types.map(a => [a, a]), 'Any type')}
    ${sel('flag', [['overdue', 'Past due date'], ['urgent', 'High or urgent'], ['over30', 'Older than 30 days'], ['stale14', 'No update in 14 days'], ['unassigned', 'Unassigned'], ['untracked', 'Owner not in the team']], 'Any condition')}
    ${fl.locations.length ? sel('location', fl.locations.map(a => [a, a]), 'Any location') : ''}
    <label class="check small"><input type="checkbox" data-change="ticket-filter" data-key="only_managed_agents"${f.only_managed_agents ? ' checked' : ''}>My team only</label>
    <span class="muted small">${rows.length} tickets</span></div>
  <section class="card">${table(['Ticket', 'Subject', 'Status', 'Priority', 'Owner', 'Group', '#Age', 'Due', '#Hours'], rows.map(t => `<tr class="click" data-act="ticket" data-id="${t.id}">
    <td>#${t.id}</td><td><div class="t-title" title="${esc(t.subject)}">${esc(t.subject)}</div></td><td>${chip(t.unresolved ? 'info' : 'good', t.status_label)}</td><td>${prioChip(t.priority)}</td>
    <td>${person(t.agent_name)}</td><td>${esc(t.department || '')}</td><td class="num">${t.age_days ?? ''} d</td>
    <td class="nowrap">${t.overdue ? chip('critical', 'Overdue ' + fmtDate(t.due_by)) : fmtDate(t.due_by)}</td><td class="num">${t.hours_logged ? num(t.hours_logged) : ''}</td></tr>`),
    'No tickets match these filters. If Freshdesk is connected, run a sync from Settings.')}</section>`;
};

async function openTicket(id) {
  const root = $('#drawer-root');
  const t = await api('/tickets/' + id);
  const r = t.rca || {};
  const est = t.tasks.reduce((s, x) => s + x.estimated_hours, 0);
  root.innerHTML = `<div class="scrim" data-act="drawer-close"></div><aside class="drawer" role="dialog" aria-label="Ticket ${t.id}">
    <div class="actions" style="justify-content:space-between"><span class="muted">Ticket #${t.id}</span><button class="btn sm" data-act="drawer-close">Close</button></div>
    <h2>${esc(t.subject)}</h2>
    <div class="actions">${chip(t.unresolved ? 'info' : 'good', t.status_label)}${prioChip(t.priority)}${t.overdue ? chip('critical', 'Overdue') : ''}</div>
    <section class="kv"><div><span>Owner</span>${esc(t.agent_name || 'Unassigned')}</div><div><span>Group</span>${esc(t.group_name || t.department || '—')}</div><div><span>Location</span>${esc(t.location || '—')}</div>
      <div><span>Created</span>${fmtDT(t.created_at)}</div><div><span>Due</span>${fmtDT(t.due_by)}</div><div><span>Resolved</span>${fmtDT(t.resolved_at)}</div>
      <div><span>Type</span>${esc(t.type || '—')}</div><div><span>Hours logged</span>${hrs(t.hours_logged)}</div><div><span>Estimated</span>${hrs(est)}</div></section>
    ${t.description ? `<section><h3>Description</h3><div class="c-body" style="white-space:pre-wrap">${esc(t.description)}</div></section>` : ''}
    <section><h3>Work on this ticket</h3>${t.tasks.map(x => `<div class="task-row" style="grid-template-columns:minmax(0,1fr) auto"><div><div class="ttl">${esc(x.title)}</div><div class="meta">${taskChip(x.status)}<span>${esc(x.assignee || '')}</span><span>${num(x.actual_hours)} of ${num(x.estimated_hours)} h</span></div></div>
      <div class="actions"><button class="btn sm" data-act="log" data-id="${x.id}" data-title="${esc(x.title)}">Log hours</button><button class="btn sm" data-act="task-edit" data-id="${x.id}">Edit</button></div></div>`).join('') || '<p class="muted">No task tracks this ticket yet.</p>'}
      <button class="btn sm" data-act="task-for-ticket" data-id="${t.id}" data-title="${esc(t.subject)}" style="margin-top:8px">Add a task for this ticket</button></section>
    <section><h3>Root cause analysis</h3><form id="rca-form" class="form-grid" data-id="${t.id}">
      ${field('category', 'Category', `<select name="category">${opt('', 'Choose a category', r.category)}${meta.rca_categories.map(c => opt(c, c, r.category)).join('')}</select>`)}
      <label class="check" style="align-self:end;padding-bottom:8px"><input type="checkbox" name="is_recurring"${r.is_recurring ? ' checked' : ''}>This issue keeps coming back</label>
      ${field('root_cause', 'Root cause', `<textarea name="root_cause">${esc(r.root_cause || '')}</textarea>`, true)}
      ${field('resolution', 'How it was resolved', `<textarea name="resolution">${esc(r.resolution || '')}</textarea>`, true)}
      ${field('preventive_action', 'Action to prevent it happening again', `<textarea name="preventive_action">${esc(r.preventive_action || '')}</textarea>`, true)}
      <div class="wide actions"><button class="btn primary">Save root cause</button>${r.updated_by ? `<span class="muted small">Last saved by ${esc(r.updated_by)}, ${fmtDT(r.updated_at)}</span>` : ''}</div></form></section>
    <section><h3>Conversation (${t.conversations.length})</h3>${t.conversations.map(c => `<div class="conv ${c.private ? 'note' : c.incoming ? 'in' : ''}"><div class="c-head">${esc(c.author || '')}, ${fmtDT(c.created_at)}${c.private ? ' — private note' : c.incoming ? ' — from requester' : ''}</div><div class="c-body">${esc(c.body || '')}</div></div>`).join('') || '<p class="muted">No conversation has been synchronised for this ticket yet.</p>'}</section>
  </aside>`;
  $('#rca-form').onsubmit = async e => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    try { await api(`/tickets/${id}/rca`, { method: 'PUT', body: { ...f, is_recurring: !!f.is_recurring } }); toast('Root cause saved'); openTicket(id); }
    catch (err) { toast(err.message); }
  };
}

views.workload = async el => {
  const w = await api('/reports/workload');
  el.innerHTML = head('Workload', `A person is flagged overloaded when the estimated hours left on their open tasks exceed ${w.threshold_pct}% of their weekly capacity.`) + `
  <div class="stack">${card('Load against capacity', '', rails(w.rows))}
  ${card('Details by team member', 'Utilisation is hours logged this week divided by weekly capacity', table(['Team member', 'Status', '#Open tasks', '#Ticket', '#Non-ticket', '#Unresolved tickets', '#Estimated h', '#Left h', '#Capacity h', '#Load', '#Logged this week', '#Utilisation', '#Overdue', '#No estimate'],
    w.rows.map(r => `<tr><td><b>${esc(r.name)}</b></td><td>${chip(r.state === 'Overloaded' ? 'critical' : r.state === 'Balanced' ? 'info' : 'good', r.state)}</td><td class="num">${r.open_tasks}</td><td class="num">${r.ticket_tasks}</td><td class="num">${r.non_ticket_tasks}</td><td class="num">${r.open_tickets}</td>
    <td class="num">${num(r.estimated_hours)}</td><td class="num">${num(r.remaining_hours)}</td><td class="num">${num(r.capacity_hours)}</td><td class="num">${num(r.load_pct)}%</td><td class="num">${num(r.logged_this_week)}</td><td class="num">${num(r.utilization_pct)}%</td><td class="num">${r.overdue_tasks}</td><td class="num">${r.unestimated_tasks}</td></tr>`)))}</div>`;
};

views.reports = async el => {
  const start = daysAgo(state.range - 1), end = today();
  const [o, shared] = await Promise.all([api('/reports/overview' + qs({ start, end })), api('/reports/shared-work' + qs({ start, end }))]);
  o.shared = shared;
  const es = o.estimates, sla = o.sla, e = o.effort;
  const overruns = [...es.open_over_estimate.map(r => ({ ...r, open: true })), ...es.overruns];
  el.innerHTML = head('Management reports', `${fmtDate(start)} to ${fmtDate(end)}. Export gives the same figures as an Excel workbook.`, rangeSelect(state.range) + `<button class="btn primary" data-act="export">Export to Excel</button>`) + `
  ${card('Tasks completed per week', 'Last 8 weeks, by how each task finished against its estimate', weekColumns(o.completed_weeks))}
  <div class="grid g2" style="margin:16px 0">
    ${card('Estimated versus actual hours', `${es.within_estimate} of ${es.completed_with_estimate} completed tasks finished within estimate (${es.within_pct}%). ${es.completed_without_estimate} completed tasks had no estimate.`, pairRows(es.by_user))}
    ${card('Hours by team member', `${hrs(e.total_hours)} logged: ${e.ticket_pct}% ticket work, ${e.non_ticket_pct}% other`, stackRows(e.by_user))}
  </div>
  <div class="grid g2" style="margin-bottom:16px">
    ${card('Tasks over their estimate', 'Still open first, then completed in the period', table(['Task', 'Assigned to', '#Estimate', '#Actual', '#Over by'], overruns.map(r => `<tr><td><div class="t-title" style="max-width:24ch" title="${esc(r.title)}">${esc(r.title)}</div>${r.open ? '<div class="small muted">Still open</div>' : ''}</td><td>${esc(r.assignee)}</td><td class="num">${num(r.estimated)}</td><td class="num">${num(r.actual)}</td><td class="num">${num(r.variance)} h</td></tr>`), 'No task has gone over its estimate.'))}
    ${card('Hours by type of work', '', hbars(e.by_category.map(c => ({ label: label(c.category), value: c.hours, tip: `${label(c.category)}: ${hrs(c.hours)} (${c.percentage}%)` })), { unit: ' h' }))}
  </div>
  <div class="grid g2" style="margin-bottom:16px">
    ${card('SLA by owner', `${sla.resolution_compliance_pct}% resolved within SLA; ${sla.first_response_compliance_pct}% of first responses on time`, table(['Owner', '#Resolved', '#Within SLA', '#Compliance'], sla.by_agent.map(r => `<tr><td>${esc(r.label)}</td><td class="num">${r.resolved}</td><td class="num">${r.within_sla}</td><td class="num">${r.compliance_pct}%</td></tr>`), 'No tickets were resolved in this period.'))}
    ${card('Overdue tickets', `${sla.overdue_open_tickets} unresolved tickets are past their due date`, table(['Ticket', 'Subject', 'Owner', '#Days overdue'], sla.overdue.slice(0, 12).map(t => `<tr class="click" data-act="ticket" data-id="${t.ticket_id}"><td>#${t.ticket_id}</td><td><div class="t-title" style="max-width:20ch" title="${esc(t.subject)}">${esc(t.subject)}</div></td><td>${esc(t.agent || 'Unassigned')}</td><td class="num">${t.days_overdue}</td></tr>`), 'No overdue tickets.'))}
  </div>
  ${card('Work more than one person touched', 'Tasks several people logged hours on in this period', table(['Task', 'Owner', 'Who worked on it', '#Hours'], (o.shared || []).map(r => `<tr class="click" data-act="task-open" data-id="${r.task_id}"><td><div class="t-title" style="max-width:34ch" title="${esc(r.title)}">${esc(r.title)}</div></td><td>${esc(r.owner)}</td>
    <td>${r.people.map(x => `<span class="chip">${avatar(x.name, 'xs')}${esc(x.name)} ${num(x.hours)} h</span>`).join(' ')}</td><td class="num">${num(r.hours)}</td></tr>`), 'Nobody logged hours on someone else\'s task in this period.'))}
  <div style="height:16px"></div>
  ${card('Recurring issues and their root causes', 'Tickets where the root cause was marked as recurring', table(['Ticket', 'Subject', 'Category', 'Root cause', 'Preventive action', '#Hours'], o.rca.recurring.map(r => `<tr class="click" data-act="ticket" data-id="${r.ticket_id}"><td>#${r.ticket_id}</td><td><div class="t-title" style="max-width:28ch" title="${esc(r.subject)}">${esc(r.subject)}</div></td><td>${esc(r.category)}</td><td>${esc(r.root_cause)}</td><td>${esc(r.preventive_action || '')}</td><td class="num">${num(r.hours)}</td></tr>`), 'No recurring issues recorded yet. Record root causes from a ticket.'))}`;
};

function md(text) {
  const inline = s => esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/(^|[\s(])_(.+?)_(?=[\s).,]|$)/g, '$1<i>$2</i>').replace(/#(\d{2,9})\b/g, '<a href="#" data-act="ticket" data-id="$1">#$1</a>');
  const out = []; let list = [], rows = [];
  const flush = () => {
    if (list.length) { out.push('<ul>' + list.map(l => `<li>${inline(l)}</li>`).join('') + '</ul>'); list = []; }
    if (rows.length) { out.push('<table>' + rows.filter(r => !/^[\s|:-]+$/.test(r)).map((r, i) => '<tr>' + r.replace(/^\||\|$/g, '').split('|').map(c => i ? `<td>${inline(c.trim())}</td>` : `<th>${inline(c.trim())}</th>`).join('') + '</tr>').join('') + '</table>'); rows = []; }
  };
  for (const line of String(text).split('\n')) {
    const t = line.trim();
    if (/^[-*•]\s+/.test(t)) { if (rows.length) flush(); list.push(t.replace(/^[-*•]\s+/, '')); }
    else if (t.startsWith('|')) { if (list.length) flush(); rows.push(t); }
    else { flush(); if (t) out.push(`<p>${inline(t.replace(/^#+\s*/, ''))}</p>`); }
  }
  flush();
  return out.join('');
}
views.assistant = async el => {
  const st = await api('/chat/status');
  const suggestions = ['Who is overloaded this week?', 'Are tasks finishing within their estimates?', 'How much time goes to ticket versus non-ticket work?', 'Which tickets consume the most effort?', 'What are the recurring issues and their root causes?', 'How is our SLA performance?'];
  el.innerHTML = head('Reporting assistant', st.mode === 'built-in'
    ? 'Answers come from built-in reports over your synchronised data. Add an AI key in .env for free-form analysis of ticket conversations.'
    : `Answers are written by ${st.model} from your synchronised tickets, conversations, root causes and activity logs.`) + `
  <section class="card chat"><div class="chat-log" id="chat-log"></div><div class="suggest" id="suggest">${suggestions.map(s => `<button class="btn sm" data-act="ask" data-q="${esc(s)}">${esc(s)}</button>`).join('')}</div>
    <form class="chat-form" id="chat-form"><input name="q" placeholder="Ask about workload, hours, SLA, a person or a ticket number" autocomplete="off" aria-label="Question"><button class="btn primary">Ask</button></form></section>`;
  const logEl = $('#chat-log', el);
  const draw = () => {
    logEl.innerHTML = state.chat.map(m => `<div class="msg ${m.role === 'user' ? 'user' : 'bot'}">${m.role === 'user' ? esc(m.content) : md(m.content)}${m.sources && m.sources.length ? `<div class="src">Tickets used: ${m.sources.map(s => ticketLink(s.ticket_id)).join(', ')}</div>` : ''}</div>`).join('')
      || '<div class="empty">Ask a question, or pick one below.</div>';
    logEl.scrollTop = logEl.scrollHeight;
  };
  views.assistant.ask = async q => {
    if (!q.trim()) return;
    const history = state.chat.map(m => ({ role: m.role, content: m.content }));
    state.chat.push({ role: 'user', content: q }, { role: 'assistant', content: 'Looking at the data…', pending: true });
    draw();
    try { const r = await api('/chat', { method: 'POST', body: { question: q, history } }); state.chat[state.chat.length - 1] = { role: 'assistant', content: r.answer, sources: r.sources }; }
    catch (e) { state.chat[state.chat.length - 1] = { role: 'assistant', content: 'The question could not be answered: ' + e.message }; }
    draw();
  };
  $('#chat-form', el).onsubmit = e => { e.preventDefault(); const i = e.target.q; const q = i.value; i.value = ''; views.assistant.ask(q); };
  draw();
};

views.settings = async el => {
  const [sync, all] = await Promise.all([api('/sync/status'), api('/users?include_inactive=true')]);
  views.settings.users = all;
  const last = sync.last_sync, admin = me.role === 'ADMIN';
  const cf = sync.custom_fields || [];
  const locField = cf.length ? `<select name="location_field">${opt('', 'Not used', sync.location_field)}${cf.map(c => opt(c.name, `${c.label} (${c.name})`, sync.location_field)).join('')}${cf.some(c => c.name === sync.location_field) || !sync.location_field ? '' : opt(sync.location_field, sync.location_field, sync.location_field)}</select>` : input('location_field', sync.location_field);
  el.innerHTML = head('Settings', 'Team members, Freshdesk connection and your password.') + `<div class="stack">
  ${card('Freshdesk connection', sync.is_configured ? `Connected to ${sync.base_url}. Tickets and agents are synchronised every ${sync.interval_minutes} minutes.` : 'Not connected yet. Enter your Freshdesk address and API key to load your real tickets and agents.',
    `${admin ? `<form id="fd-form" class="form-grid three">${field('base_url', 'Freshdesk address', input('base_url', sync.base_url || '', 'text', 'placeholder="https://yourcompany.freshdesk.com" required'))}
      ${field('api_key', sync.api_key_hint ? `API key (saved, ${sync.api_key_hint}; leave empty to keep)` : 'API key', input('api_key', '', 'password', 'autocomplete="off"'))}
      ${field('location_field', 'Ticket field that holds the location', locField)}
      <div class="wide actions"><button class="btn primary">${sync.is_configured ? 'Save and sync' : 'Connect and sync'}</button>${sync.has_sample_data ? '<button type="button" class="btn danger" data-act="clear-sample">Remove sample data</button>' : ''}
      <span class="muted small">${sync.has_sample_data ? 'Connecting removes the sample data. ' : ''}Use an administrator\'s API key so agent names and emails can be imported.</span></div></form>` : ''}
    <p style="margin-top:14px">${last ? `Last sync ${fmtDT(last.started_at)}: ${chip(last.status === 'SUCCESS' ? 'good' : last.status === 'RUNNING' ? 'info' : 'critical', label(last.status))} ${last.tickets_processed} tickets, ${last.conversations_processed} conversation entries, ${last.agents_imported} new agents${last.error_summary ? `<br><span class="muted">${esc(last.error_summary)}</span>` : ''}` : 'No sync has run yet.'}</p>
    ${table(['Started', 'Trigger', 'Status', '#Tickets', '#Conversations', '#New agents', 'Message'], sync.recent_logs.map(l => `<tr><td class="nowrap">${fmtDT(l.started_at)}</td><td>${esc(label(l.trigger))}</td><td>${esc(label(l.status))}</td><td class="num">${l.tickets_processed}</td><td class="num">${l.conversations_processed}</td><td class="num">${l.agents_imported}</td><td class="small">${esc(l.error_summary || '')}</td></tr>`), 'Sync history appears here.')}`,
    isLead() ? `<button class="btn" data-act="sync"${sync.is_configured ? '' : ' disabled'}>Sync now</button>` : '')}
  ${card('Team members', `Freshdesk agents are added automatically at each sync. They sign in with their email and the starting password ${admin ? '“' + sync.new_member_password + '”' : 'given by the administrator'}, and must choose their own at first sign-in.`, table(['Name', 'Email', 'Role', 'Source', '#Capacity h/week', 'Status', ''], all.map(u => `<tr><td>${person(u.name)}</td><td>${esc(u.email)}</td><td>${esc(label(u.role))}</td><td>${u.from_freshdesk ? 'Freshdesk agent' : 'Added here'}</td><td class="num">${num(u.weekly_capacity_hours)}</td><td>${chip(u.is_active ? 'good' : '', u.is_active ? 'Active' : 'Inactive')}</td>
    <td class="right nowrap">${admin ? `<button class="btn sm" data-act="user-edit" data-id="${u.id}">Edit</button> ${u.id !== me.id ? `<button class="btn sm danger" data-act="user-del" data-id="${u.id}">Remove</button>` : ''}` : ''}</td></tr>`)), admin ? `<button class="btn primary" data-act="user-new">Add team member</button>` : '')}
  ${card('Your Outlook calendar', me.calendar_connected ? 'Connected. Your meetings appear on My work, ready to log.' : 'Not connected. Connect it to log meetings from your calendar with one click.', '', `<button class="btn${me.calendar_connected ? '' : ' primary'}" data-act="cal-connect">${me.calendar_connected ? 'Change or disconnect' : 'Connect Outlook calendar'}</button>`)}
  ${card('Your password', '', `<form id="pw-form" class="form-grid" style="max-width:520px">${field('current_password', 'Current password', input('current_password', '', 'password', 'required autocomplete="current-password"'))}${field('new_password', 'New password (8 characters or more)', input('new_password', '', 'password', 'required minlength="8" autocomplete="new-password"'))}<div class="wide"><button class="btn">Change password</button></div></form>`)}</div>`;
  $('#pw-form', el).onsubmit = async e => { e.preventDefault(); try { await api('/auth/change-password', { method: 'POST', body: Object.fromEntries(new FormData(e.target)) }); e.target.reset(); toast('Password changed'); } catch (err) { toast(err.message); } };
  const fd = $('#fd-form', el);
  if (fd) fd.onsubmit = async e => {
    e.preventDefault(); const btn = $('button', fd); btn.disabled = true; btn.textContent = 'Checking the connection…';
    try { await api('/sync/config', { method: 'PUT', body: Object.fromEntries(new FormData(fd)) }); toast('Connected. The first sync is running; this page refreshes when it finishes.'); views.tickets.fl = null; pollSync(0); }
    catch (err) { toast(err.message); btn.disabled = false; btn.textContent = 'Connect and sync'; }
  };
};
async function pollSync(n) {
  users = await api('/users'); meta = await api('/meta'); drawBadges();
  if (location.hash.includes('settings')) route();
  const s = await api('/sync/status');
  if (n < 40 && (!s.last_sync || s.last_sync.status === 'RUNNING')) setTimeout(() => pollSync(n + 1), 3000);
}
function userModal(u = {}) {
  const v = { role: 'MEMBER', weekly_capacity_hours: 40, is_active: true, ...u };
  modal(v.id ? 'Edit team member' : 'Add team member', `<div class="form-grid">
    ${field('name', 'Name', input('name', v.name, 'text', 'required'))}${field('email', 'Email (used to sign in)', input('email', v.email, 'email', 'required'))}
    ${field('role', 'Role', `<select name="role">${['MEMBER', 'TEAM_LEAD', 'ADMIN'].map(r => opt(r, label(r), v.role)).join('')}</select>`)}
    ${field('weekly_capacity_hours', 'Capacity, hours per week', input('weekly_capacity_hours', v.weekly_capacity_hours, 'number', 'min="1" max="80" step="0.5"'))}
    ${field('freshdesk_agent_name', 'Freshdesk agent name (links this person to their tickets)', input('freshdesk_agent_name', v.freshdesk_agent_name), true)}
    ${field('password', v.id ? 'New password (leave empty to keep)' : 'Initial password', input('password', '', 'password', 'autocomplete="new-password"'))}
    <label class="check" style="align-self:end;padding-bottom:8px"><input type="checkbox" name="is_active"${v.is_active ? ' checked' : ''}>Active</label></div>`, {
    saveLabel: v.id ? 'Save changes' : 'Add team member',
    onSave: async f => {
      await api(v.id ? '/users/' + v.id : '/users', { method: v.id ? 'PUT' : 'POST', body: { ...f, weekly_capacity_hours: +f.weekly_capacity_hours || 40, is_active: !!f.is_active, password: f.password || null } });
      users = await api('/users'); toast('Team member saved'); route();
    },
  });
}

// ------------------------------------------------------------------ actions
const findTask = async id => (views.tasks.rows || []).concat(views.my.tasks || []).find(t => t.id === id) || api('/tasks/' + id);
const refresh = () => { route(); api('/meta').then(m => { meta = m; drawBadges(); }); const d = $('#drawer-root .drawer'); if (d) openTicket(+$('#rca-form').dataset.id); };
const acts = {
  'ticket': d => openTicket(+d.id),
  'drawer-close': () => { $('#drawer-root').innerHTML = ''; },
  'task-new': () => taskModal(location.hash.includes('tasks') && typeof state.tv.member === 'number' && state.tv.member && isLead() ? { assignee_id: state.tv.member } : {}, refresh),
  'task-edit': async d => { const t = await findTask(+d.id); if (t) taskModal(t, () => { if (state.tv.open[t.id]) delete views.tasks.detail[t.id]; refresh(); }); },
  'task-for-ticket': d => taskModal({ title: `#${d.id} ${d.title}`.slice(0, 300), category: 'TICKET', ticket_id: +d.id }, refresh),
  'task-done': async d => {
    const t = await findTask(+d.id), row = document.querySelector(`[data-row="${t.id}"]`);
    await api(`/tasks/${t.id}/status`, { method: 'PUT', body: { status: 'DONE' } });
    if (row && !matchMedia('(prefers-reduced-motion: reduce)').matches) { row.classList.add('just-done'); await new Promise(r => setTimeout(r, 650)); }
    refresh();
    toast(`Done: ${t.title.length > 48 ? t.title.slice(0, 47) + '…' : t.title}`, { label: 'Undo', run: async () => { await api(`/tasks/${t.id}/status`, { method: 'PUT', body: { status: t.status } }); toast('Task reopened'); refresh(); } });
  },
  'task-reopen': async d => { await api(`/tasks/${d.id}/status`, { method: 'PUT', body: { status: 'IN_PROGRESS' } }); toast('Task reopened and set to in progress'); refresh(); },
  'my-tab': d => { state.myTab = d.v; route(); },
  'task-expand': async (d, el) => {
    const id = +d.id, row = el.closest('tr');
    const shown = document.getElementById('detail-' + id);
    if (shown) { shown.remove(); delete state.tv.open[id]; el.setAttribute('aria-expanded', 'false'); $('.caret', el).textContent = '▸'; row.classList.remove('open'); return; }
    state.tv.open[id] = true; el.setAttribute('aria-expanded', 'true'); $('.caret', el).textContent = '▾'; row.classList.add('open');
    await insertDetail(id);
  },
  'step-del': async d => { await api('/checklist/' + d.id, { method: 'DELETE' }); await repaintDetail(+d.task); },
  'log-del': async d => {
    await api('/timelogs/' + d.id, { method: 'DELETE' }); toast('Entry removed');
    if (d.task) { await repaintDetail(+d.task); const t = await api('/tasks/' + d.task); const row = (views.tasks.rows || []).find(x => x.id === +d.task); if (row) Object.assign(row, t); route(); }
    else refresh();
  },
  'task-open': d => { location.hash = '#/tasks'; setTimeout(() => { state.tv.open[+d.id] = true; insertDetail(+d.id); }, 400); },
  'hand-over-all': () => {
    const rows = views.tasks.visible || [];
    modal(`Hand over ${rows.length} task${rows.length > 1 ? 's' : ''}`, `<p>Give every task shown in this list to one team member. Logged hours stay with the people who logged them.</p>
      ${field('assignee_id', 'Give the tasks to', `<select name="assignee_id" required>${users.filter(u => u.is_active).map(u => opt(u.id, u.name)).join('')}</select>`)}`, {
      saveLabel: 'Hand over', onSave: async f => { const r = await api('/tasks/bulk-assign', { method: 'PUT', body: { task_ids: rows.map(t => t.id), assignee_id: +f.assignee_id } }); toast(`${r.assigned} tasks given to ${r.to}`); route(); } });
  },
  'tasks-csv': () => {
    const rows = views.tasks.visible || [];
    const head = ['ID', 'Task', 'Type', 'Status', 'Assignee', 'Helpers', 'Estimated hours', 'Actual hours', 'Steps done', 'Steps total', 'Ticket', 'Due', 'Completed'];
    const cell = x => `"${String(x ?? '').replace(/"/g, '""')}"`;
    const csv = [head.map(cell).join(',')].concat(rows.map(t => [tid(t.id), t.title, label(t.category), TASK_CHIP[t.status][1], t.assignee || 'Unassigned',
      (t.helpers || []).map(h => `${h.name} ${h.hours} h`).join('; '), t.estimated_hours || '', t.actual_hours, t.steps_done, t.steps_total,
      t.ticket_id || '', t.due_date || '', t.completed_at ? t.completed_at.slice(0, 10) : ''].map(cell).join(','))).join('\r\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' }));
    a.download = `tasks-${today()}.csv`; a.click(); URL.revokeObjectURL(a.href);
    toast(`${rows.length} tasks exported`);
  },
  'my-week': d => { state.myWeek = d.v === '0' ? 0 : (state.myWeek || 0) + +d.v; route(); },
  'cal-connect': () => calendarModal(),
  'cal-refresh': async () => { await api('/me/meetings' + qs({ start: today(), end: today(), fresh: true })); route(); toast('Meetings refreshed'); },
  'meeting-manual': () => meetingModal(),
  'meeting-log': async d => { const m = views.my.meetings.find(x => x.ref === d.ref); await api('/me/meetings/log', { method: 'POST', body: { meetings: [m] } }); toast(`${num(m.hours)} h logged for ${m.title}`); route(); },
  'meeting-log-all': async () => { const ms = views.my.meetings.filter(m => m.finished && !m.logged); const r = await api('/me/meetings/log', { method: 'POST', body: { meetings: ms } }); toast(`${r.logged} meetings logged, ${num(ms.reduce((s, m) => s + m.hours, 0))} h`); route(); },
  'log': async d => { const t = d.title ? { id: +d.id, title: d.title } : await findTask(+d.id); logModal(t, () => { delete views.tasks.detail[t.id]; refresh(); }); },
  'timer-start': async d => { timer = (await api('/timer/start', { method: 'POST', body: { task_id: +d.id } })).timer; drawTimer(); toast('Timer started'); route(); },
  'timer-stop': () => {
    modal('Stop timer', `<p class="muted" style="margin:-6px 0 12px">${esc(timer.task)}</p>${field('note', 'What did you do?', input('note', '', 'text', 'maxlength="300"'))}`, {
      saveLabel: 'Stop and log hours',
      onSave: async f => { const r = await api('/timer/stop', { method: 'POST', body: { note: f.note } }); timer = null; drawTimer(); toast(r.logged ? `${num(r.logged.hours)} h logged` : r.message); refresh(); },
      onDelete: async () => { await api('/timer/stop', { method: 'POST', body: { discard: true } }); timer = null; drawTimer(); toast('Timer discarded'); refresh(); },
      deleteLabel: 'Discard timer',
    });
  },
  'sync': async (d, el) => { el.disabled = true; el.textContent = 'Syncing…'; try { const r = await api('/sync/run', { method: 'POST' }); toast(r.status === 'SUCCESS' ? `Synchronised ${r.tickets_processed} tickets` : (r.error || label(r.status))); } catch (e) { toast(e.message); } views.tickets.fl = null; route(); },
  'export': async (d, el) => {
    el.disabled = true;
    try { const blob = await api('/reports/export.xlsx' + qs({ start: daysAgo(state.range - 1), end: today() }), { blob: true }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `activity-report-${today()}.xlsx`; a.click(); URL.revokeObjectURL(a.href); }
    catch (e) { toast(e.message); } el.disabled = false;
  },
  'ask': d => views.assistant.ask(d.q),
  'theme-open': (d, el) => { const m = el.nextElementSibling; m.hidden = !m.hidden; el.setAttribute('aria-expanded', String(!m.hidden)); if (!m.hidden) m.querySelector('[aria-checked=true]').focus(); },
  'theme-set': d => { setTheme(d.v); toast(`Appearance: ${THEMES.find(x => x[0] === d.v)[1]}`); },
  'user-new': () => userModal(),
  'user-del': d => {
    const u = views.settings.users.find(x => x.id === +d.id);
    const others = users.filter(x => x.is_active && x.id !== u.id);
    modal(`Remove ${u.name}?`, `<p>${esc(u.name)} will no longer be able to sign in and disappears from the team lists. Hours they logged stay in the reports.</p>
      ${field('handover_to', 'Their open tasks', `<select name="handover_to">${opt('', 'Leave them without an owner')}${others.map(x => opt(x.id, 'Hand over to ' + x.name)).join('')}</select>`)}
      <p class="small muted" style="margin-top:10px">Left without an owner, tasks that only mirror a Freshdesk ticket and hold no hours are removed, so they do not sit in the unassigned list. In Freshdesk the tickets stay with ${esc(u.name)} until someone reassigns them there.${u.from_freshdesk ? ' The sync will not add this agent back.' : ''}</p>`, {
      saveLabel: 'Remove team member',
      onSave: async f => {
        const r = await api(`/users/${u.id}` + qs({ handover_to: f.handover_to || '' }), { method: 'DELETE' });
        users = await api('/users');
        const what = r.successor ? `${r.handed_over} tasks given to ${r.successor}`
          : [r.tasks_unassigned && `${r.tasks_unassigned} tasks left without an owner`, r.tasks_dropped && `${r.tasks_dropped} ticket tasks removed`].filter(Boolean).join(', ');
        toast(`${u.name} removed${what ? '; ' + what : ''}`); route();
      } });
  },
  'clear-sample': () => modal('Remove sample data?', '<p>This deletes the sample tickets, sample people and their tasks and hours. Your own team members and tasks are kept.</p>', { saveLabel: 'Remove sample data', onSave: async () => { await api('/sync/clear-sample-data', { method: 'POST' }); users = await api('/users'); views.tickets.fl = null; toast('Sample data removed'); route(); } }),
  'dash-tab': d => { state.dash = d.v; route(); },
  'dash-group': d => { state.dashF.group = d.v; route(); },
  'dash-reset': () => { state.dashF = {}; route(); },
  'tickets-flag': d => { state.tickets = { ...state.dashF, status_filter: 'unresolved', flag: d.v }; location.hash = '#/tickets'; },
  'tickets-by': d => { state.tickets = { ...state.dashF, status_filter: 'unresolved', [d.key]: d.v }; location.hash = '#/tickets'; },
  'member': d => { state.tv.member = d.v === 'all' ? 'all' : +d.v; state.tv.chip = 'open'; route(); },
  'task-chip': d => { state.tv.chip = d.v; route(); },
  'grp': d => { state.tv.closed[d.v] = !state.tv.closed[d.v]; route(); },
  'user-edit': d => userModal(views.settings.users.find(u => u.id === +d.id)),
  'signout': () => signOut(),
};
document.addEventListener('click', async e => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  if (el.tagName === 'A') e.preventDefault();
  const inner = e.target.closest('button,a,input,select'); if (inner && inner !== el && el.contains(inner)) return;
  try { await acts[el.dataset.act](el.dataset, el); } catch (err) { toast(err.message); }
});
document.addEventListener('change', async e => {
  const step = e.target.closest('.chk-item');
  if (step) {
    step.disabled = true;
    try { await api('/checklist/' + step.dataset.id, { method: 'PUT', body: { done: step.checked } }); await repaintDetail(+step.dataset.task); }
    catch (err) { toast(err.message); step.checked = !step.checked; step.disabled = false; }
    return;
  }
  const el = e.target.closest('.est-in'); if (!el) return;
  const v = el.value === '' ? 0 : +el.value;
  if (!(v >= 0)) { toast('Enter a number of hours'); return; }
  el.disabled = true;
  try { const t = await api(`/tasks/${el.dataset.id}/estimate`, { method: 'PUT', body: { estimated_hours: v } }); toast(v ? `Estimate set to ${num(v)} h` : 'Estimate removed'); refresh(); }
  catch (err) { toast(err.message); el.disabled = false; }
});
document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.closest && e.target.closest('.est-in')) e.target.blur(); });
document.addEventListener('submit', async e => {
  const form = e.target.closest('.chk-add'); if (!form) return;
  e.preventDefault();
  const input = form.querySelector('input'), title = input.value.trim(); if (!title) return;
  input.disabled = true;
  try { await api(`/tasks/${form.dataset.task}/checklist`, { method: 'POST', body: { title } }); await repaintDetail(+form.dataset.task);
    const next = document.querySelector(`#detail-${form.dataset.task} .chk-add input`); if (next) next.focus(); }
  catch (err) { toast(err.message); input.disabled = false; }
});
let debounce;
document.addEventListener('input', e => {
  const el = e.target.closest('[data-change]'); if (!el) return;
  const kind = el.dataset.change;
  const apply = () => {
    if (kind === 'range') state.range = +el.value;
    else { const bag = kind === 'tv' ? state.tv : kind === 'dash-filter' ? state.dashF : state.tickets; bag[el.dataset.key] = el.type === 'checkbox' ? el.checked : el.value; }
    route(el.type === 'search' ? el.dataset.key : null);
  };
  clearTimeout(debounce);
  if (el.type === 'search') debounce = setTimeout(apply, 350); else apply();
});

// ---------------------------------------------------------- shell + routing
const ICON = {
  dashboard: '<path d="M3 3h6v8H3zM11 3h6v5h-6zM11 10h6v7h-6zM3 13h6v4H3z"/>', my: '<circle cx="10" cy="6.5" r="3.5"/><path d="M3 17c.6-3.4 3.4-5 7-5s6.400 1.600 7 5z"/>',
  tasks: '<path d="M3 4h2v2H3zM7 4h10v2H7zM3 9h2v2H3zM7 9h10v2H7zM3 14h2v2H3zM7 14h10v2H7z"/>', tickets: '<path d="M2 5h16v3.500a1.500 1.500 0 000 3V15H2v-3.500a1.500 1.500 0 000-3z"/>',
  workload: '<path d="M3 16V9h3v7zM8.500 16V4h3v12zM14 16v-5h3v5z"/>', reports: '<path d="M4 2h8l4 4v12H4zM7 10h6v1.500H7zM7 13h6v1.500H7z"/>',
  assistant: '<path d="M3 4h14v10H9l-4 3v-3H3z"/>', settings: '<path d="M10 6.500a3.500 3.500 0 100 7 3.500 3.500 0 000-7zM9 1h2l.500 2.500 2 1 2.200-1.300 1.400 1.400L15.800 7l.900 2L19 9.500v2l-2.300.500-.900 2 1.300 2.200-1.400 1.400-2.200-1.300-2 .900L11 19H9l-.500-2.300-2-.900-2.200 1.300-1.400-1.400L4.200 13.500l-.900-2L1 11V9l2.300-.500.900-2L2.900 4.300l1.400-1.400L6.500 4.200l2-.900z" fill-rule="evenodd"/>',
};
const NAV = [['dashboard', 'Dashboard'], ['my', 'My work'], ['tasks', 'Tasks'], ['tickets', 'Tickets'], ['workload', 'Workload'], ['reports', 'Reports'], ['assistant', 'Assistant'], ['settings', 'Settings']];
function drawBadges() {
  const set = (k, n) => { const b = document.querySelector(`[data-nav="${k}"] .badge`); if (b) { b.textContent = n; b.hidden = !n; } };
  set('tasks', meta.open_tasks); set('tickets', meta.unresolved_tickets);
}
function shell() {
  $('#app').innerHTML = `<div class="shell"><header class="top"><a class="brand" href="#/dashboard">Team Activity Tracker</a>
    <nav class="tabs" aria-label="Main">${NAV.map(([k, t]) => `<a href="#/${k}" data-nav="${k}"><svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">${ICON[k]}</svg>${t}<span class="badge" hidden></span></a>`).join('')}</nav>
    <div class="top-right"><div id="timerbox"></div>${themeControl()}<span class="me" title="${esc(me.name)}, ${esc(label(me.role))}">${avatar(me.name)}<span>${esc(me.name)}</span></span><button class="btn sm" data-act="signout">Sign out</button></div></header>
    <main class="main" id="main"></main></div>`;
  drawBadges();
}
let routeSeq = 0;
async function route(keepFocusKey) {
  if (!me) return;
  const key = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('?')[0];
  const view = views[key] || views.dashboard;
  document.querySelectorAll('[data-nav]').forEach(a => a.classList.toggle('on', a.dataset.nav === (views[key] ? key : 'dashboard')));
  const main = $('#main'), seq = ++routeSeq;
  if (!main.innerHTML) main.innerHTML = '<div class="empty">Loading…</div>';
  try {
    const holder = document.createElement('div');
    await view(holder);
    if (seq !== routeSeq) return;
    main.replaceChildren(...holder.childNodes);
    if (keepFocusKey) { const i = main.querySelector(`input[type=search][data-key="${keepFocusKey}"]`); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }
  } catch (e) { if (seq === routeSeq) main.innerHTML = `<div class="empty">This page could not be loaded: ${esc(e.message)}</div>`; }
}
window.addEventListener('hashchange', () => { $('#drawer-root').innerHTML = ''; route(); });

function signOut() { token = null; me = null; store.del('tat_token'); loginView(); }
const LINES = [
  ['Small steps, logged every day, add up to work you can be proud of.', 'Plan your day, track your progress and see what the team achieved together.'],
  ['Every ticket you close makes someone’s day run a little smoother.', 'Your work keeps the plants running. Here is where it gets seen.'],
  ['Know where the time goes, and you can give it to what matters most.', 'Clear priorities, honest estimates and fewer surprises for everyone.'],
  ['Good work deserves to be seen.', 'Log it, finish it and let the numbers tell the story of what this team delivers.'],
  ['Today is a good day to finish something.', 'Pick one task, see it through and celebrate the tick.'],
];
function loginView(msg = '') {
  $('#drawer-root').innerHTML = ''; $('#modal-root').innerHTML = '';
  const n = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0)) / 864e5) % LINES.length, [h, sub] = LINES[n];
  const d = new Date();
  $('#app').innerHTML = `<div class="login">${themeControl()}<div class="pitch"><span class="today-tag">${LONG_DAYS[d.getDay()]} ${d.getDate()} ${LONG_MONTHS[d.getMonth()]}</span><h1>${esc(h)}</h1><p>${esc(sub)}</p>
    <ul><li>${ICO.check}<span>See your day at a glance and what is due next</span></li><li>${ICO.timer}<span>Log hours in seconds, or let the timer do it</span></li><li>${ICO.cal}<span>Bring in meetings straight from Outlook</span></li></ul></div>
    <form id="login"><h2>Sign in to Team Activity Tracker</h2>${field('email', 'Email', input('email', '', 'email', 'required autocomplete="username"'))}${field('password', 'Password', input('password', '', 'password', 'required autocomplete="current-password"'))}
    <div class="err" role="alert">${esc(msg)}</div><button class="btn primary">Sign in</button></form></div>`;
  $('#login').onsubmit = async e => {
    e.preventDefault();
    try { const f = Object.fromEntries(new FormData(e.target)); const r = await api('/auth/login', { method: 'POST', body: f }); token = r.access_token; store.set('tat_token', token); start(f.password); }
    catch (err) { $('#login .err').textContent = err.message; }
  };
}
function firstPassword(current) {
  $('#app').innerHTML = `<div class="login">${themeControl()}<div class="pitch"><h1>Make it yours.</h1><p>You signed in with a starting password. Choose your own before you continue.</p></div>
    <form id="first-pw"><h2>Welcome, ${esc(me.name)}</h2>${current ? '' : field('current_password', 'Current password', input('current_password', '', 'password', 'required'))}${field('new_password', 'New password (8 characters or more)', input('new_password', '', 'password', 'required minlength="8" autocomplete="new-password"'))}
    <div class="err" role="alert"></div><button class="btn primary">Save password and continue</button><button type="button" class="btn" data-act="signout">Sign out</button></form></div>`;
  $('#first-pw').onsubmit = async e => {
    e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
    try { await api('/auth/change-password', { method: 'POST', body: { current_password: current || f.current_password, new_password: f.new_password } }); start(); }
    catch (err) { $('#first-pw .err').textContent = err.message; }
  };
}
async function start(passwordJustUsed) {
  if (!token) return loginView();
  try { [me, meta, users] = await Promise.all([api('/auth/me'), api('/meta'), api('/users')]); }
  catch { return; }
  if (me.must_change_password) return firstPassword(passwordJustUsed);
  shell(); await loadTimer(); route();
}
start();
})();
